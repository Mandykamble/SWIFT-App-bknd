package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import java.util.List;

/**
 * A ProductWorkflowDefinitions.
 */
@Entity
@Table(name = "product_workflow_definitions")
@RegisterForReflection
public class ProductWorkflowDefinitions extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @Size(max = 255)
    @Column(name = "approved_by", length = 255)
    public String approvedBy;

    @Column(name = "approved_dt")
    public Instant approvedDt;

    @NotNull
    @Column(name = "is_draft", nullable = false)
    public Boolean isDraft;

    @Column(name = "original_record_id")
    public Long originalRecordId;

    @NotNull
    @Column(name = "pending_approval", nullable = false)
    public Boolean pendingApproval;

    @NotNull
    @Column(name = "blocking", nullable = false)
    public Boolean blocking;

    @NotNull
    @Column(name = "enabled", nullable = false)
    public Boolean enabled;

    @NotNull
    @Size(max = 30)
    @Column(name = "product_id", length = 30, nullable = false)
    public String productId;

    @NotNull
    @Column(name = "sequence_id", nullable = false)
    public Integer sequenceId;

    @NotNull
    @Size(max = 150)
    @Column(name = "stage_id", length = 150, nullable = false)
    public String stageId;

       // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProductWorkflowDefinitions)) {
            return false;
        }
        return id != null && id.equals(((ProductWorkflowDefinitions) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ProductWorkflowDefinitions{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", approvedBy='" + approvedBy + "'" +
            ", approvedDt='" + approvedDt + "'" +
            ", isDraft='" + isDraft + "'" +
            ", originalRecordId=" + originalRecordId +
            ", pendingApproval='" + pendingApproval + "'" +
            ", blocking='" + blocking + "'" +
            ", enabled='" + enabled + "'" +
            ", productId='" + productId + "'" +
            ", sequenceId=" + sequenceId +
            ", stageId='" + stageId + "'" +
            "}";
    }

    public ProductWorkflowDefinitions update() {
        return update(this);
    }

    public ProductWorkflowDefinitions persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static ProductWorkflowDefinitions update(ProductWorkflowDefinitions productWorkflowDefinitions) {
        if (productWorkflowDefinitions == null) {
            throw new IllegalArgumentException("productWorkflowDefinitions can't be null");
        }
        var entity = ProductWorkflowDefinitions.<ProductWorkflowDefinitions>findById(productWorkflowDefinitions.id);
        if (entity != null) {
            entity.recordId = productWorkflowDefinitions.recordId;
            entity.createdBy = productWorkflowDefinitions.createdBy;
            entity.createdDt = productWorkflowDefinitions.createdDt;
            entity.lastUpdatedBy = productWorkflowDefinitions.lastUpdatedBy;
            entity.lastUpdatedDt = productWorkflowDefinitions.lastUpdatedDt;
            entity.lockFlag = productWorkflowDefinitions.lockFlag;
            entity.approvedBy = productWorkflowDefinitions.approvedBy;
            entity.approvedDt = productWorkflowDefinitions.approvedDt;
            entity.isDraft = productWorkflowDefinitions.isDraft;
            entity.originalRecordId = productWorkflowDefinitions.originalRecordId;
            entity.pendingApproval = productWorkflowDefinitions.pendingApproval;
            entity.blocking = productWorkflowDefinitions.blocking;
            entity.enabled = productWorkflowDefinitions.enabled;
            entity.productId = productWorkflowDefinitions.productId;
            entity.sequenceId = productWorkflowDefinitions.sequenceId;
            entity.stageId = productWorkflowDefinitions.stageId;
        }
        return entity;
    }

    public static ProductWorkflowDefinitions persistOrUpdate(ProductWorkflowDefinitions productWorkflowDefinitions) {
        if (productWorkflowDefinitions == null) {
            throw new IllegalArgumentException("productWorkflowDefinitions can't be null");
        }
        if (productWorkflowDefinitions.id == null) {
            persist(productWorkflowDefinitions);
            return productWorkflowDefinitions;
        } else {
            return update(productWorkflowDefinitions);
        }
    }

    public static List<ProductWorkflowDefinitions> findByProductId(String productId) {
        return ProductWorkflowDefinitions.find("productId", productId).list();
    }

    public static ProductWorkflowDefinitions findByProductIdAndWorkflowStageId(String productId, String stageId) {
        return find("productId = ?1 and stageId = ?2", productId, stageId).firstResult();
    }
}
