package com.ncs.pay.config;

import com.ncs.pay.config.params.RouteThreadPoolSetup;
import io.smallrye.config.ConfigMapping;
import lombok.Data;



@ConfigMapping(prefix = "payhub.capacity")
public interface CapacityProperties {
    RouteThreadPoolSetup RouteThreadPools();
}
