package com.ncs.pay.domain.repo;

import com.ncs.pay.domain.*;
import com.ncs.pay.service.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@ApplicationScoped
@Slf4j
public class QueryRepo {

    @Inject
    EntityManager entityManager;

    public List<PayhubTxnMaster> findByCriteria(PayhubTxnMasterDTO payhubTxnMasterDTO, String page, String limit) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayhubTxnMaster> query = cb.createQuery(PayhubTxnMaster.class);
        Root<PayhubTxnMaster> payhubTxnMasterRoot = query.from(PayhubTxnMaster.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("payhubTxnRef"), payhubTxnMasterDTO.getPayhubTxnRef()));
        }

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getInterfaceRefNo())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("interfaceRefNo"), payhubTxnMasterDTO.getInterfaceRefNo()));
        }

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getSourceId())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("sourceId"), payhubTxnMasterDTO.getSourceId()));
        }

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getStatusCd())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("statusCd"), payhubTxnMasterDTO.getStatusCd()));
        }

        if (payhubTxnMasterDTO.getMessageInfoId() != null && StringUtils.isNotBlank(String.valueOf(payhubTxnMasterDTO.getMessageInfoId()))) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("messageInfoId"), payhubTxnMasterDTO.getMessageInfoId()));
        }

        if (payhubTxnMasterDTO.getSettlmAmt() != null && StringUtils.isNotBlank(String.valueOf(payhubTxnMasterDTO.getSettlmAmt()))) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("settlmAmt"), payhubTxnMasterDTO.getSettlmAmt()));
        }

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getDebitAcct())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("debitAcct"), payhubTxnMasterDTO.getDebitAcct()));
        }
        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getDebtrAcctNm())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("debtrAcctNm"), payhubTxnMasterDTO.getDebtrAcctNm()));
        }

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getCreditAcct())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("creditAcct"), payhubTxnMasterDTO.getCreditAcct()));
        }

        if (StringUtils.isNotBlank(payhubTxnMasterDTO.getCreditAcctNm())) {
            predicates.add(cb.equal(payhubTxnMasterRoot.get("creditAcctNm"), payhubTxnMasterDTO.getCreditAcctNm()));
        }


        query.where(predicates.toArray(new Predicate[0]));
        // apply pagination
        TypedQuery<PayhubTxnMaster> typedQuery = entityManager.createQuery(query);

        // Only set pagination if page and limit are not blank
        if (StringUtils.isNotBlank(page) && StringUtils.isNotBlank(limit)) {
            // parse page and limit as integers
            int pageInt = Integer.parseInt(page);
            int limitInt = Integer.parseInt(limit);

            // apply pagination
            typedQuery.setFirstResult((pageInt - 1) * limitInt);
            typedQuery.setMaxResults(limitInt);
        }

        return typedQuery.getResultList();
    }

    public Collection<TransactionDetails> findByCriteria(TransactionDetailsDTO transactionDetailsDTO) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TransactionDetails> query = cb.createQuery(TransactionDetails.class);
        Root<TransactionDetails> transactionDetailsRoot = query.from(TransactionDetails.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(transactionDetailsDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionDetailsRoot.get("payhubTxnRef"), transactionDetailsDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public Collection<TxnProcessLog> findByCriteria(TxnProcessLogDTO txnProcessLogDTO) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TxnProcessLog> query = cb.createQuery(TxnProcessLog.class);
        Root<TxnProcessLog> transactionDetailsRoot = query.from(TxnProcessLog.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(txnProcessLogDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionDetailsRoot.get("payhubTxnRef"), txnProcessLogDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public Collection<UserDefinedFields> findByCriteria(UserDefinedFieldsDTO userDefinedFieldsDTO) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UserDefinedFields> query = cb.createQuery(UserDefinedFields.class);
        Root<UserDefinedFields> userDefinedFieldsRoot = query.from(UserDefinedFields.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(userDefinedFieldsDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(userDefinedFieldsRoot.get("payhubTxnRef"), userDefinedFieldsDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public Collection<TxnWorkflowTracker> findByCriteria(TxnWorkflowTrackerDTO txnWorkflowTrackerDTO) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TxnWorkflowTracker> query = cb.createQuery(TxnWorkflowTracker.class);
        Root<TxnWorkflowTracker> transactionDetailsRoot = query.from(TxnWorkflowTracker.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(txnWorkflowTrackerDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionDetailsRoot.get("payhubTxnRef"), txnWorkflowTrackerDTO.getPayhubTxnRef()));
        }


        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public Collection<MessageInfo> findByCriteria(MessageInfoDTO inboundMessagesDTO, Tenant tenant) {


       // log.info("inboundMessagesDTO : {}",inboundMessagesDTO.toString());
      //  log.info("tenant : {}",tenant.toString());
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MessageInfo> query = cb.createQuery(MessageInfo.class);
        Root<MessageInfo> msgDetailsRoot = query.from(MessageInfo.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(inboundMessagesDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(msgDetailsRoot.get("payhubTxnRef"), inboundMessagesDTO.getPayhubTxnRef()));
        }

        if (StringUtils.isNotBlank(inboundMessagesDTO.getMsgUid())) {
            predicates.add(cb.equal(msgDetailsRoot.get("msgUid"), inboundMessagesDTO.getMsgUid()));
        }

        if (StringUtils.isNotBlank(inboundMessagesDTO.getMessageDirection())) {
            predicates.add(cb.equal(msgDetailsRoot.get("messageDirection"), inboundMessagesDTO.getMessageDirection()));
        } else {
            CriteriaBuilder.In<String> inClause = cb.in(msgDetailsRoot.get("messageDirection"));
            inClause.value("I").value("O");
            predicates.add(inClause);

        }

        if (StringUtils.isNotBlank(inboundMessagesDTO.getMessageType())) {
            predicates.add(cb.equal(msgDetailsRoot.get("messageType"), inboundMessagesDTO.getMessageType()));
        }

        if (StringUtils.isNotBlank(inboundMessagesDTO.getSourceId())) {
            predicates.add(cb.equal(msgDetailsRoot.get("sourceId"), inboundMessagesDTO.getSourceId()));
        }
/*
        if (tenant != null && !tenant.isRegional()) {
            predicates.add(cb.equal(msgDetailsRoot.get("countryCd"), tenant.getCountryCode()));
        }*/

      //  log.info("tenant getName : {}",tenant.getName());

        if (tenant != null && !tenant.isRegional()) {
            predicates.add(cb.equal(msgDetailsRoot.get("tenantId"), tenant.getName()));
        }

        query.orderBy(cb.asc(msgDetailsRoot.get("createdDt")));

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public List<InstructionLevel> findByCriteria(InstructionLevelDTO instructionLevelDTO) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<InstructionLevel> query = cb.createQuery(InstructionLevel.class);
        Root<InstructionLevel> instructionLevelRoot = query.from(InstructionLevel.class);

        List<Predicate> predicates = new ArrayList<>();


        if (instructionLevelDTO.getMessageInfoId() != null && StringUtils.isNotBlank(String.valueOf(instructionLevelDTO.getMessageInfoId()))) {
            predicates.add(cb.equal(instructionLevelRoot.get("messageInfoId"), instructionLevelDTO.getMessageInfoId()));
        }


        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public List<TransactionGlInfo> findByCriteria(TransactionGlInfoDTO transactionGlInfoDTO) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TransactionGlInfo> query = cb.createQuery(TransactionGlInfo.class);
        Root<TransactionGlInfo> transactionGlInfoRoot = query.from(TransactionGlInfo.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(transactionGlInfoDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionGlInfoRoot.get("payhubTxnRef"), transactionGlInfoDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }


    public List<TransactionCharges> findByCriteria(TransactionChargesDTO transactionChargesDTO) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TransactionCharges> query = cb.createQuery(TransactionCharges.class);
        Root<TransactionCharges> transactionChargesRoot = query.from(TransactionCharges.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(transactionChargesDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionChargesRoot.get("payhubTxnRef"), transactionChargesDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public List<TransactionForexInfo> findByCriteria(TransactionForexInfoDTO transactionForexInfoDTO) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TransactionForexInfo> query = cb.createQuery(TransactionForexInfo.class);
        Root<TransactionForexInfo> transactionGlInfoRoot = query.from(TransactionForexInfo.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(transactionForexInfoDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionGlInfoRoot.get("payhubTxnRef"), transactionForexInfoDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }

    public List<TransactionAccountPosting> findByCriteria(TransactionAccountPostingDTO accountPostingDTO) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TransactionAccountPosting> query = cb.createQuery(TransactionAccountPosting.class);
        Root<TransactionAccountPosting> transactionAccPostingInfoRoot = query.from(TransactionAccountPosting.class);

        List<Predicate> predicates = new ArrayList<>();

        if (StringUtils.isNotBlank(accountPostingDTO.getPayhubTxnRef())) {
            predicates.add(cb.equal(transactionAccPostingInfoRoot.get("payhubTxnRef"), accountPostingDTO.getPayhubTxnRef()));
        }

        query.where(predicates.toArray(new Predicate[0]));
        return entityManager.createQuery(query).getResultList();
    }
}
