package com.ncs.pay.model.constants;

public enum EventProcessingStatusCodes {

    RECEIVED,ROUTING_INITATED,ROUTING_SUCCESS,ROUTING_FAILED;
}
