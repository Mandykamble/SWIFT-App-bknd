package com.ncs.pay.model.constants;

public enum MessageDirection {
    INBOUND("I"), OUTBOUND("O"), CLEARING("CLR"), ACK("ACK");

    private String code;
    MessageDirection(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
