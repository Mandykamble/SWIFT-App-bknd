package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.runtime.annotations.RegisterForReflection;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.*;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A FIMessageInfo.
 */
@Entity
@Table(name = "fi_message_info")
@Cacheable
@RegisterForReflection
@Data
public class FIMessageInfo extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 100)
    @Column(name = "event_id", length = 100, nullable = false, unique = true)
    public String eventId;

    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, unique = true)
    public String payhubTxnRef;

    @Column(name = "aging")
    public Boolean aging;

    @Size(max = 50)
    @Column(name = "correlation_id", length = 50)
    public String correlationId;

    @NotNull
    @Size(max = 100)
    @Column(name = "country_cd", length = 100, nullable = false)
    public String countryCd;

    @NotNull
    @Size(max = 50)
    @Column(name = "msg_uid", length = 50, nullable = false)
    public String msgUid;

    @Size(max = 100)
    @Column(name = "reply_to_address", length = 100)
    public String replyToAddress;

    @Lob
    @Column(name = "req_msg_content")
    public byte[] reqMsgContent;

    @Column(name = "req_msg_content_content_type")
    public String reqMsgContentContentType;

    @Lob
    @Column(name = "res_msg_content")
    public byte[] resMsgContent;

    @Column(name = "res_msg_content_content_type")
    public String resMsgContentContentType;

    @Size(max = 255)
    @Column(name = "routing_status", length = 255)
    public String routingStatus;

    @NotNull
    @Size(max = 20)
    @Column(name = "source_id", length = 20, nullable = false)
    public String sourceId;

    @Size(max = 10)
    @Column(name = "message_direction", length = 10)
    public String messageDirection;

    @Size(max = 10)
    @Column(name = "message_type", length = 10)
    public String messageType;

    @Size(max = 50)
    @Column(name = "validation_status", length = 50)
    public String validationStatus;

    @Size(max = 50)
    @Column(name = "validation_remarks", length = 50)
    public String validationRemarks;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof FIMessageInfo)) {
            return false;
        }
        return id != null && id.equals(((FIMessageInfo) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return (
            "FIMessageInfo{" +
            "id=" +
            id +
            ", recordId=" +
            recordId +
            ", createdBy='" +
            createdBy +
            "'" +
            ", createdDt='" +
            createdDt +
            "'" +
            ", lastUpdatedBy='" +
            lastUpdatedBy +
            "'" +
            ", lastUpdatedDt='" +
            lastUpdatedDt +
            "'" +
            ", lockFlag=" +
            lockFlag +
            ", eventId='" +
            eventId +
            "'" +
            ", payhubTxnRef='" +
            payhubTxnRef +
            "'" +
            ", aging='" +
            aging +
            "'" +
            ", correlationId='" +
            correlationId +
            "'" +
            ", countryCd='" +
            countryCd +
            "'" +
            ", msgUid='" +
            msgUid +
            "'" +
            ", replyToAddress='" +
            replyToAddress +
            "'" +
            ", reqMsgContent='" +
            reqMsgContent +
            "'" +
            ", reqMsgContentContentType='" +
            reqMsgContentContentType +
            "'" +
            ", resMsgContent='" +
            resMsgContent +
            "'" +
            ", resMsgContentContentType='" +
            resMsgContentContentType +
            "'" +
            ", routingStatus='" +
            routingStatus +
            "'" +
            ", sourceId='" +
            sourceId +
            "'" +
            ", messageDirection='" +
            messageDirection +
            "'" +
            ", messageType='" +
            messageType +
            "'" +
            ", validationStatus='" +
            validationStatus +
            "'" +
            ", validationRemarks='" +
            validationRemarks +
            "'" +
            "}"
        );
    }

    public FIMessageInfo update() {
        return update(this);
    }

    public FIMessageInfo persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static FIMessageInfo update(FIMessageInfo fIMessageInfo) {
        if (fIMessageInfo == null) {
            throw new IllegalArgumentException("fIMessageInfo can't be null");
        }
        var entity = FIMessageInfo.<FIMessageInfo>findById(fIMessageInfo.id);
        if (entity != null) {
            entity.recordId = fIMessageInfo.recordId;
            entity.createdBy = fIMessageInfo.createdBy;
            entity.createdDt = fIMessageInfo.createdDt;
            entity.lastUpdatedBy = fIMessageInfo.lastUpdatedBy;
            entity.lastUpdatedDt = fIMessageInfo.lastUpdatedDt;
            entity.lockFlag = fIMessageInfo.lockFlag;
            entity.eventId = fIMessageInfo.eventId;
            entity.payhubTxnRef = fIMessageInfo.payhubTxnRef;
            entity.aging = fIMessageInfo.aging;
            entity.correlationId = fIMessageInfo.correlationId;
            entity.countryCd = fIMessageInfo.countryCd;
            entity.msgUid = fIMessageInfo.msgUid;
            entity.replyToAddress = fIMessageInfo.replyToAddress;
            entity.reqMsgContent = fIMessageInfo.reqMsgContent;
            entity.resMsgContent = fIMessageInfo.resMsgContent;
            entity.routingStatus = fIMessageInfo.routingStatus;
            entity.sourceId = fIMessageInfo.sourceId;
            entity.messageDirection = fIMessageInfo.messageDirection;
            entity.messageType = fIMessageInfo.messageType;
            entity.validationStatus = fIMessageInfo.validationStatus;
            entity.validationRemarks = fIMessageInfo.validationRemarks;
        }
        return entity;
    }

    public static FIMessageInfo persistOrUpdate(FIMessageInfo fIMessageInfo) {
        if (fIMessageInfo == null) {
            throw new IllegalArgumentException("fIMessageInfo can't be null");
        }
        if (fIMessageInfo.id == null) {
            persist(fIMessageInfo);
            return fIMessageInfo;
        } else {
            return update(fIMessageInfo);
        }
    }

    @PrePersist
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

        this.setRecordId(0L);
    }
}
