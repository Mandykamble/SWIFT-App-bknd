package com.ncs.pay.exception;

import lombok.Data;

@Data
public class ProcessingException extends Exception {

    private String ErrorCode;
    private String Message;
    private Class Origin;
    private String RecoveryEndpoint;
    private String PostErrorEnpoint;

    private ProcessingException() {
        }
    public ProcessingException(Class Origin, String ErrorCode , String Message, String RecoveryEndpoint,
                               String PostErrorEndpoint) {
	    super(Origin.getName() + " -- " + ErrorCode + " : " + Message );
        this.Origin = Origin;
        this.ErrorCode = ErrorCode;
	    this.Message = Message;
	    this.RecoveryEndpoint = RecoveryEndpoint;
    }


}
