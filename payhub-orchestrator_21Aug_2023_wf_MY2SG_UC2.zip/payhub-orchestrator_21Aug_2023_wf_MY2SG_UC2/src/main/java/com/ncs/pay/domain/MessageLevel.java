package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.runtime.annotations.RegisterForReflection;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.*;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A MessageLevel.
 */
@Entity
@Table(name = "message_level")
@Cacheable
@RegisterForReflection
@Data
public class MessageLevel extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "event_id", length = 100, nullable = false, unique = true)
    public String eventId;

    @NotNull
    @Size(max = 50)
    @Column(name = "msg_uid", length = 50, nullable = false)
    public String msgUid;

    @NotNull
    @Size(max = 50)
    @Column(name = "message_type", length = 50, nullable = false)
    public String messageType;

    @NotNull
    @Size(max = 50)
    @Column(name = "message_direction", length = 50, nullable = false)
    public String messageDirection;

    @NotNull
    @Size(max = 20)
    @Column(name = "source_id", length = 20, nullable = false)
    public String sourceId;

    @NotNull
    @Size(max = 20)
    @Column(name = "msg_channel", length = 20, nullable = false)
    public String msgChannel;

    @Size(max = 50)
    @Column(name = "correlation_id", length = 50)
    public String correlationId;

    @NotNull
    @Size(max = 100)
    @Column(name = "country_cd", length = 100, nullable = false)
    public String countryCd;

    @Size(max = 100)
    @Column(name = "reply_to_address", length = 100)
    public String replyToAddress;

    @Lob
    @Column(name = "req_msg_content")
    public byte[] reqMsgContent;

    @Column(name = "req_msg_content_content_type")
    public String reqMsgContentContentType;

    @Lob
    @Column(name = "res_msg_content")
    public byte[] resMsgContent;

    @Column(name = "res_msg_content_content_type")
    public String resMsgContentContentType;

    @Size(max = 255)
    @Column(name = "routing_status", length = 255)
    public String routingStatus;

    @Size(max = 50)
    @Column(name = "validation_status", length = 50)
    public String validationStatus;

    @Size(max = 2000)
    @Column(name = "validation_remarks", length = 2000)
    public String validationRemarks;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @Column(name = "aging")
    public Boolean aging;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @OneToMany(mappedBy = "messageLevel")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    public Set<InstructionLevel> instructionLevels = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MessageLevel)) {
            return false;
        }
        return id != null && id.equals(((MessageLevel) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return (
            "MessageLevel{" +
            "id=" +
            id +
            ", eventId='" +
            eventId +
            "'" +
            ", msgUid='" +
            msgUid +
            "'" +
            ", messageType='" +
            messageType +
            "'" +
            ", messageDirection='" +
            messageDirection +
            "'" +
            ", sourceId='" +
            sourceId +
            "'" +
            ", msgChannel='" +
            msgChannel +
            "'" +
            ", correlationId='" +
            correlationId +
            "'" +
            ", countryCd='" +
            countryCd +
            "'" +
            ", replyToAddress='" +
            replyToAddress +
            "'" +
            ", reqMsgContent='" +
            reqMsgContent +
            "'" +
            ", reqMsgContentContentType='" +
            reqMsgContentContentType +
            "'" +
            ", resMsgContent='" +
            resMsgContent +
            "'" +
            ", resMsgContentContentType='" +
            resMsgContentContentType +
            "'" +
            ", routingStatus='" +
            routingStatus +
            "'" +
            ", validationStatus='" +
            validationStatus +
            "'" +
            ", validationRemarks='" +
            validationRemarks +
            "'" +
            ", lockFlag=" +
            lockFlag +
            ", aging='" +
            aging +
            "'" +
            ", createdBy='" +
            createdBy +
            "'" +
            ", createdDt='" +
            createdDt +
            "'" +
            ", lastUpdatedBy='" +
            lastUpdatedBy +
            "'" +
            ", lastUpdatedDt='" +
            lastUpdatedDt +
            "'" +
            "}"
        );
    }

    public MessageLevel update() {
        return update(this);
    }

    public MessageLevel persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static MessageLevel update(MessageLevel messageLevel) {
        if (messageLevel == null) {
            throw new IllegalArgumentException("messageLevel can't be null");
        }
        var entity = MessageLevel.<MessageLevel>findById(messageLevel.id);
        if (entity != null) {
            entity.eventId = messageLevel.eventId;
            entity.msgUid = messageLevel.msgUid;
            entity.messageType = messageLevel.messageType;
            entity.messageDirection = messageLevel.messageDirection;
            entity.sourceId = messageLevel.sourceId;
            entity.msgChannel = messageLevel.msgChannel;
            entity.correlationId = messageLevel.correlationId;
            entity.countryCd = messageLevel.countryCd;
            entity.replyToAddress = messageLevel.replyToAddress;
            entity.reqMsgContent = messageLevel.reqMsgContent;
            entity.resMsgContent = messageLevel.resMsgContent;
            entity.routingStatus = messageLevel.routingStatus;
            entity.validationStatus = messageLevel.validationStatus;
            entity.validationRemarks = messageLevel.validationRemarks;
            entity.lockFlag = messageLevel.lockFlag;
            entity.aging = messageLevel.aging;
            entity.createdBy = messageLevel.createdBy;
            entity.createdDt = messageLevel.createdDt;
            entity.lastUpdatedBy = messageLevel.lastUpdatedBy;
            entity.lastUpdatedDt = messageLevel.lastUpdatedDt;
            entity.instructionLevels = messageLevel.instructionLevels;
        }
        return entity;
    }

    public static MessageLevel persistOrUpdate(MessageLevel messageLevel) {
        if (messageLevel == null) {
            throw new IllegalArgumentException("messageLevel can't be null");
        }
        if (messageLevel.id == null) {
            persist(messageLevel);
            return messageLevel;
        } else {
            return update(messageLevel);
        }
    }

    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

    }
}
