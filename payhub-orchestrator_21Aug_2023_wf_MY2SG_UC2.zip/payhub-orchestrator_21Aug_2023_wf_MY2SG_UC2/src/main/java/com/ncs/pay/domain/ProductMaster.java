package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;

/**
 * A ProductMaster.
 */
@Entity
@Table(name = "product_master")
@RegisterForReflection
public class ProductMaster extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @Size(max = 255)
    @Column(name = "approved_by", length = 255)
    public String approvedBy;

    @Column(name = "approved_dt")
    public Instant approvedDt;

    @NotNull
    @Column(name = "is_draft", nullable = false)
    public Boolean isDraft;

    @Column(name = "original_record_id")
    public Long originalRecordId;

    @NotNull
    @Column(name = "pending_approval", nullable = false)
    public Boolean pendingApproval;

    @NotNull
    @Size(max = 30)
    @Column(name = "branch_code", length = 30, nullable = false)
    public String branchCode;

    @NotNull
    @Size(max = 30)
    @Column(name = "country_code", length = 30, nullable = false)
    public String countryCode;

    @NotNull
    @Column(name = "enabled", nullable = false)
    public Boolean enabled;

    @NotNull
    @Size(max = 30)
    @Column(name = "product_desc", length = 30, nullable = false)
    public String productDesc;

    @NotNull
    @Size(max = 30)
    @Column(name = "product_id", length = 30, nullable = false, unique = true)
    public String productId;

    @NotNull
    @Size(max = 30)
    @Column(name = "txn_categrory", length = 30, nullable = false)
    public String txnCategrory;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProductMaster)) {
            return false;
        }
        return id != null && id.equals(((ProductMaster) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ProductMaster{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", approvedBy='" + approvedBy + "'" +
            ", approvedDt='" + approvedDt + "'" +
            ", isDraft='" + isDraft + "'" +
            ", originalRecordId=" + originalRecordId +
            ", pendingApproval='" + pendingApproval + "'" +
            ", branchCode='" + branchCode + "'" +
            ", countryCode='" + countryCode + "'" +
            ", enabled='" + enabled + "'" +
            ", productDesc='" + productDesc + "'" +
            ", productId='" + productId + "'" +
            ", txnCategrory='" + txnCategrory + "'" +
            "}";
    }

    public ProductMaster update() {
        return update(this);
    }

    public ProductMaster persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static ProductMaster update(ProductMaster productMaster) {
        if (productMaster == null) {
            throw new IllegalArgumentException("productMaster can't be null");
        }
        var entity = ProductMaster.<ProductMaster>findById(productMaster.id);
        if (entity != null) {
            entity.recordId = productMaster.recordId;
            entity.createdBy = productMaster.createdBy;
            entity.createdDt = productMaster.createdDt;
            entity.lastUpdatedBy = productMaster.lastUpdatedBy;
            entity.lastUpdatedDt = productMaster.lastUpdatedDt;
            entity.lockFlag = productMaster.lockFlag;
            entity.approvedBy = productMaster.approvedBy;
            entity.approvedDt = productMaster.approvedDt;
            entity.isDraft = productMaster.isDraft;
            entity.originalRecordId = productMaster.originalRecordId;
            entity.pendingApproval = productMaster.pendingApproval;
            entity.branchCode = productMaster.branchCode;
            entity.countryCode = productMaster.countryCode;
            entity.enabled = productMaster.enabled;
            entity.productDesc = productMaster.productDesc;
            entity.productId = productMaster.productId;
            entity.txnCategrory = productMaster.txnCategrory;
        }
        return entity;
    }

    public static ProductMaster persistOrUpdate(ProductMaster productMaster) {
        if (productMaster == null) {
            throw new IllegalArgumentException("productMaster can't be null");
        }
        if (productMaster.id == null) {
            persist(productMaster);
            return productMaster;
        } else {
            return update(productMaster);
        }
    }


}
