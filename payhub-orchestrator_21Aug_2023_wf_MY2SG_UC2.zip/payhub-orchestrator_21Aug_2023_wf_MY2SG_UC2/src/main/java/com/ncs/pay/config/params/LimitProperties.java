package com.ncs.pay.config.params;
import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "limit")
public interface LimitProperties {
     String usdAmount();

}