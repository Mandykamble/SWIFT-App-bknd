package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;

/**
 * A EventProcessingLog.
 */
@Entity
@Table(name = "event_processing_log")
@RegisterForReflection
public class EventProcessingLog extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 100)
    @Column(name = "event_id", length = 100, nullable = false, unique = true)
    public String eventId;

    @Size(max = 300)
    @Column(name = "error_details", length = 300)
    public String errorDetails;

    @Lob
    @Column(name = "log_cd")
    public byte[] logCd;

    @Column(name = "log_cd_content_type")
      public String logCdContentType;

    @Size(max = 300)
    @Column(name = "log_message", length = 300)
    public String logMessage;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EventProcessingLog)) {
            return false;
        }
        return id != null && id.equals(((EventProcessingLog) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "EventProcessingLog{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", eventId='" + eventId + "'" +
            ", errorDetails='" + errorDetails + "'" +
            ", logCd='" + logCd + "'" +
            ", logCdContentType='" + logCdContentType + "'" +
            ", logMessage='" + logMessage + "'" +
            "}";
    }

    public EventProcessingLog update() {
        return update(this);
    }

    public EventProcessingLog persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static EventProcessingLog update(EventProcessingLog eventProcessingLog) {
        if (eventProcessingLog == null) {
            throw new IllegalArgumentException("eventProcessingLog can't be null");
        }
        var entity = EventProcessingLog.<EventProcessingLog>findById(eventProcessingLog.id);
        if (entity != null) {
            entity.recordId = eventProcessingLog.recordId;
            entity.createdBy = eventProcessingLog.createdBy;
            entity.createdDt = eventProcessingLog.createdDt;
            entity.lastUpdatedBy = eventProcessingLog.lastUpdatedBy;
            entity.lastUpdatedDt = eventProcessingLog.lastUpdatedDt;
            entity.lockFlag = eventProcessingLog.lockFlag;
            entity.eventId = eventProcessingLog.eventId;
            entity.errorDetails = eventProcessingLog.errorDetails;
            entity.logCd = eventProcessingLog.logCd;
            entity.logMessage = eventProcessingLog.logMessage;
        }
        return entity;
    }

    public static EventProcessingLog persistOrUpdate(EventProcessingLog eventProcessingLog) {
        if (eventProcessingLog == null) {
            throw new IllegalArgumentException("eventProcessingLog can't be null");
        }
        if (eventProcessingLog.id == null) {
            persist(eventProcessingLog);
            return eventProcessingLog;
        } else {
            return update(eventProcessingLog);
        }
    }


}
