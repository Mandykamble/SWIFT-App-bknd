package com.ncs.pay.model.constants;

public enum EventLogCodes {

    INFO,ERROR;
}
