package com.ncs.pay.domain;

import com.ncs.pay.domain.repo.MessageTypeEntity;
import io.quarkus.hibernate.orm.panache.PanacheEntity;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import javax.persistence.*;

@Entity
@Table(name = "message_field")
public class MessageFieldEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @ManyToOne
    @JoinColumn(name = "message_type_id", nullable = false)
    public MessageTypeEntity messageType;  // Relationship to MessageTypeEntity

    @Column(name = "field_name", nullable = false)
    public String fieldName;

    @Column(name = "field_type", nullable = false)
    public String fieldType;  // STRING, NUMBER, DATE

    @Column(name = "is_required", nullable = false)
    public boolean isRequired;

    @Column(columnDefinition = "TEXT", nullable = true)
    public String validationRule;  // JSON rules for validation
}
