package com.ncs.pay.domain.repo;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import javax.enterprise.context.ApplicationScoped;
import com.ncs.pay.domain.MessageEntity;

@ApplicationScoped
public class SwiftMessageRepository implements PanacheRepository<MessageEntity> {
    // Inherits CRUD methods
}
