package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * A TransactionAccountPosting.
 */
@Entity
@Table(name = "transaction_account_posting")
@Cacheable
@RegisterForReflection
public class TransactionAccountPosting extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Size(max = 36)
    @Column(name = "acct_bank_branch_cds", length = 36)
    public String acctBankBranchCds;

    @Size(max = 4)
    @Column(name = "acct_branch_id", length = 4)
    public String acctBranchId;

    @Size(max = 15)
    @Column(name = "acct_cardbrand", length = 15)
    public String acctCardbrand;

    @Size(max = 3)
    @Column(name = "acct_ccy", length = 3)
    public String acctCcy;

    @Size(max = 8)
    @Column(name = "acct_class", length = 8)
    public String acctClass;

    @Size(max = 50)
    @Column(name = "acct_desc", length = 50)
    public String acctDesc;

    @Column(name = "acct_entry_amt", precision = 21, scale = 2)
    public BigDecimal acctEntryAmt;

    @Size(max = 3)
    @Column(name = "acct_entry_amt_lcy", length = 3)
    public String acctEntryAmtLcy;

    @Size(max = 3)
    @Column(name = "acct_entry_ccy", length = 3)
    public String acctEntryCcy;

    @Column(name = "acct_entry_sequence_no", precision = 21, scale = 2)
    public BigDecimal acctEntrySequenceNo;

    @Size(max = 36)
    @Column(name = "acct_id", length = 36)
    public String acctId;

    @Size(max = 1)
    @Column(name = "acct_mainsupp_ind", length = 1)
    public String acctMainsuppInd;

    @Size(max = 80)
    @Column(name = "acct_name", length = 80)
    public String acctName;

    @Size(max = 400)
    @Column(name = "acct_name_tc", length = 400)
    public String acctNameTc;

    @Size(max = 10)
    @Column(name = "acct_org_cd", length = 10)
    public String acctOrgCd;

    @Size(max = 10)
    @Column(name = "acct_prod_cd", length = 10)
    public String acctProdCd;

    @Size(max = 10)
    @Column(name = "acct_prod_sub_ty", length = 10)
    public String acctProdSubTy;

    @Size(max = 16)
    @Column(name = "acct_prod_ty", length = 16)
    public String acctProdTy;

    @Size(max = 50)
    @Column(name = "addnl_ref_1", length = 50)
    public String addnlRef1;

    @Size(max = 50)
    @Column(name = "addnl_ref_2", length = 50)
    public String addnlRef2;

    @Column(name = "branch_exchange_rate", precision = 21, scale = 2)
    public BigDecimal branchExchangeRate;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Size(max = 10)
    @Column(name = "entry_type", length = 10)
    public String entryType;

    @Size(max = 50)
    @Column(name = "gl_cd", length = 50)
    public String glCd;

    @Size(max = 4)
    @Column(name = "gl_dept", length = 4)
    public String glDept;

    @Size(max = 4)
    @Column(name = "gl_gst_typ", length = 4)
    public String glGstTyp;

    @Size(max = 160)
    @Column(name = "gl_narr", length = 160)
    public String glNarr;

    @Size(max = 800)
    @Column(name = "gl_narr_tc", length = 800)
    public String glNarrTc;

    @Size(max = 1)
    @Column(name = "gl_res_cd", length = 1)
    public String glResCd;

    @Size(max = 10)
    @Column(name = "gl_sect", length = 10)
    public String glSect;

    @Size(max = 10)
    @Column(name = "gl_short_m", length = 10)
    public String glShortM;

    @Size(max = 36)
    @Column(name = "inter_acct_id", length = 36)
    public String interAcctId;

    @Size(max = 256)
    @Column(name = "misc_product_info", length = 256)
    public String miscProductInfo;

    @Size(max = 10)
    @Column(name = "pay_type", length = 10)
    public String payType;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false)
    public String payhubTxnRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "payment_product_code", length = 50, nullable = false)
    public String paymentProductCode;

    @Column(name = "posting_dt")
    public LocalDate postingDt;

    @Size(max = 10)
    @Column(name = "posting_mode", length = 10)
    public String postingMode;

    @Size(max = 10)
    @Column(name = "pre_advice_ind", length = 10)
    public String preAdviceInd;

    @NotNull
    @Size(max = 50)
    @Column(name = "processing_center_code", length = 50, nullable = false)
    public String processingCenterCode;

    @Size(max = 10)
    @Column(name = "settlm_md", length = 10)
    public String settlmMd;

    @NotNull
    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = false)
    public String tenantId;

    @Column(name = "value_dt")
    public LocalDate valueDt;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionAccountPosting)) {
            return false;
        }
        return id != null && id.equals(((TransactionAccountPosting) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TransactionAccountPosting{" +
            "id=" + id +
            ", acctBankBranchCds='" + acctBankBranchCds + "'" +
            ", acctBranchId='" + acctBranchId + "'" +
            ", acctCardbrand='" + acctCardbrand + "'" +
            ", acctCcy='" + acctCcy + "'" +
            ", acctClass='" + acctClass + "'" +
            ", acctDesc='" + acctDesc + "'" +
            ", acctEntryAmt=" + acctEntryAmt +
            ", acctEntryAmtLcy='" + acctEntryAmtLcy + "'" +
            ", acctEntryCcy='" + acctEntryCcy + "'" +
            ", acctEntrySequenceNo=" + acctEntrySequenceNo +
            ", acctId='" + acctId + "'" +
            ", acctMainsuppInd='" + acctMainsuppInd + "'" +
            ", acctName='" + acctName + "'" +
            ", acctNameTc='" + acctNameTc + "'" +
            ", acctOrgCd='" + acctOrgCd + "'" +
            ", acctProdCd='" + acctProdCd + "'" +
            ", acctProdSubTy='" + acctProdSubTy + "'" +
            ", acctProdTy='" + acctProdTy + "'" +
            ", addnlRef1='" + addnlRef1 + "'" +
            ", addnlRef2='" + addnlRef2 + "'" +
            ", branchExchangeRate=" + branchExchangeRate +
            ", countryCd='" + countryCd + "'" +
            ", entryType='" + entryType + "'" +
            ", glCd='" + glCd + "'" +
            ", glDept='" + glDept + "'" +
            ", glGstTyp='" + glGstTyp + "'" +
            ", glNarr='" + glNarr + "'" +
            ", glNarrTc='" + glNarrTc + "'" +
            ", glResCd='" + glResCd + "'" +
            ", glSect='" + glSect + "'" +
            ", glShortM='" + glShortM + "'" +
            ", interAcctId='" + interAcctId + "'" +
            ", miscProductInfo='" + miscProductInfo + "'" +
            ", payType='" + payType + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", paymentProductCode='" + paymentProductCode + "'" +
            ", postingDt='" + postingDt + "'" +
            ", postingMode='" + postingMode + "'" +
            ", preAdviceInd='" + preAdviceInd + "'" +
            ", processingCenterCode='" + processingCenterCode + "'" +
            ", settlmMd='" + settlmMd + "'" +
            ", tenantId='" + tenantId + "'" +
            ", valueDt='" + valueDt + "'" +
            "}";
    }

    public TransactionAccountPosting update() {
        return update(this);
    }

    public TransactionAccountPosting persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TransactionAccountPosting update(TransactionAccountPosting transactionAccountPosting) {
        if (transactionAccountPosting == null) {
            throw new IllegalArgumentException("transactionAccountPosting can't be null");
        }
        var entity = TransactionAccountPosting.<TransactionAccountPosting>findById(transactionAccountPosting.id);
        if (entity != null) {
            entity.acctBankBranchCds = transactionAccountPosting.acctBankBranchCds;
            entity.acctBranchId = transactionAccountPosting.acctBranchId;
            entity.acctCardbrand = transactionAccountPosting.acctCardbrand;
            entity.acctCcy = transactionAccountPosting.acctCcy;
            entity.acctClass = transactionAccountPosting.acctClass;
            entity.acctDesc = transactionAccountPosting.acctDesc;
            entity.acctEntryAmt = transactionAccountPosting.acctEntryAmt;
            entity.acctEntryAmtLcy = transactionAccountPosting.acctEntryAmtLcy;
            entity.acctEntryCcy = transactionAccountPosting.acctEntryCcy;
            entity.acctEntrySequenceNo = transactionAccountPosting.acctEntrySequenceNo;
            entity.acctId = transactionAccountPosting.acctId;
            entity.acctMainsuppInd = transactionAccountPosting.acctMainsuppInd;
            entity.acctName = transactionAccountPosting.acctName;
            entity.acctNameTc = transactionAccountPosting.acctNameTc;
            entity.acctOrgCd = transactionAccountPosting.acctOrgCd;
            entity.acctProdCd = transactionAccountPosting.acctProdCd;
            entity.acctProdSubTy = transactionAccountPosting.acctProdSubTy;
            entity.acctProdTy = transactionAccountPosting.acctProdTy;
            entity.addnlRef1 = transactionAccountPosting.addnlRef1;
            entity.addnlRef2 = transactionAccountPosting.addnlRef2;
            entity.branchExchangeRate = transactionAccountPosting.branchExchangeRate;
            entity.countryCd = transactionAccountPosting.countryCd;
            entity.entryType = transactionAccountPosting.entryType;
            entity.glCd = transactionAccountPosting.glCd;
            entity.glDept = transactionAccountPosting.glDept;
            entity.glGstTyp = transactionAccountPosting.glGstTyp;
            entity.glNarr = transactionAccountPosting.glNarr;
            entity.glNarrTc = transactionAccountPosting.glNarrTc;
            entity.glResCd = transactionAccountPosting.glResCd;
            entity.glSect = transactionAccountPosting.glSect;
            entity.glShortM = transactionAccountPosting.glShortM;
            entity.interAcctId = transactionAccountPosting.interAcctId;
            entity.miscProductInfo = transactionAccountPosting.miscProductInfo;
            entity.payType = transactionAccountPosting.payType;
            entity.payhubTxnRef = transactionAccountPosting.payhubTxnRef;
            entity.paymentProductCode = transactionAccountPosting.paymentProductCode;
            entity.postingDt = transactionAccountPosting.postingDt;
            entity.postingMode = transactionAccountPosting.postingMode;
            entity.preAdviceInd = transactionAccountPosting.preAdviceInd;
            entity.processingCenterCode = transactionAccountPosting.processingCenterCode;
            entity.settlmMd = transactionAccountPosting.settlmMd;
            entity.tenantId = transactionAccountPosting.tenantId;
            entity.valueDt = transactionAccountPosting.valueDt;
        }
        return entity;
    }

    public static TransactionAccountPosting persistOrUpdate(TransactionAccountPosting transactionAccountPosting) {
        if (transactionAccountPosting == null) {
            throw new IllegalArgumentException("transactionAccountPosting can't be null");
        }
        if (transactionAccountPosting.id == null) {
            persist(transactionAccountPosting);
            return transactionAccountPosting;
        } else {
            return update(transactionAccountPosting);
        }
    }


}
