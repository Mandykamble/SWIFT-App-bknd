package com.ncs.pay.domain.repo;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "message_type")
@Data
public class MessageTypeEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(name = "name", unique = true, nullable = false)
    public String name;  // e.g., MT103

    @Column(name = "description", nullable = false)
    public String description;

    @Column(name = "message_schema", columnDefinition = "TEXT", nullable = false)
    public String messageSchema;  // ✅ Renamed from "schema"
}
