package com.ncs.pay.exception;

import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.core.Response;

/**
 * @author Amila Karunathilaka
 */
public class UsernameNotFoundException extends NotAuthorizedException {

    public UsernameNotFoundException(String message) {
        super(message);
    }
    public UsernameNotFoundException(String message, Object challenge, Object... moreChallenges) {
        super(message, challenge, moreChallenges);
    }

    public UsernameNotFoundException(String message, Response response) {
        super(message, response);
    }
}
