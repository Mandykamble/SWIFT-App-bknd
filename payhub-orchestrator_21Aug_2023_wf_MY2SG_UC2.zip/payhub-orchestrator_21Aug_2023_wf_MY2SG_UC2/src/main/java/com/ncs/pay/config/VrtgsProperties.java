package com.ncs.pay.config;
import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "vrtgs")
public interface VrtgsProperties {
     String cashPoolAccVnd();
     String chargeAccount();

     String chargeAmount();

     String chargeType();

}