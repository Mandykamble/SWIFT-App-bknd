package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.runtime.annotations.RegisterForReflection;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.*;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.Audited;

/**
 * A UserDefinedFields.
 */
@Entity
@Table(name = "user_defined_fields")
@Cacheable
@RegisterForReflection
@Data
@Audited
public class UserDefinedFields extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Size(max = 200)
    @Column(name = "value_time", length = 200)
    public String valueTime;

    @Size(max = 200)
    @Column(name = "channel_login_id", length = 200)
    public String channelLoginId;

    @Size(max = 200)
    @Column(name = "transaction_date", length = 200)
    public String transactionDate;

    @Size(max = 200)
    @Column(name = "transaction_time", length = 200)
    public String transactionTime;

    @Size(max = 200)
    @Column(name = "product_type_code", length = 200)
    public String productTypeCode;

    @Size(max = 200)
    @Column(name = "asi_indicator", length = 200)
    public String asiIndicator;

    @Size(max = 200)
    @Column(name = "velocity_segment", length = 200)
    public String velocitySegment;

    @Size(max = 200)
    @Column(name = "individual_cstmr_instr_ref", length = 200)
    public String individualCstmrInstrRef;

    @Size(max = 200)
    @Column(name = "customer_instruction_ref", length = 200)
    public String customerInstructionRef;

    @Size(max = 200)
    @Column(name = "bulk_product_type_code", length = 200)
    public String bulkProductTypeCode;

    @Size(max = 200)
    @Column(name = "product_code", length = 200)
    public String productCode;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;



    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50)
    public String payhubTxnRef;

    @NotNull
    @Column(name = "txn_id", nullable = false)
    public Long transactionLevelId;


    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof UserDefinedFields)) {
            return false;
        }
        return id != null && id.equals(((UserDefinedFields) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return (
            "UserDefinedFields{" +
            "id=" +
            id +
            ", valueTime='" +
            valueTime +
            "'" +
            ", channelLoginId='" +
            channelLoginId +
            "'" +
            ", transactionDate='" +
            transactionDate +
            "'" +
            ", transactionTime='" +
            transactionTime +
            "'" +
            ", productTypeCode='" +
            productTypeCode +
            "'" +
            ", asiIndicator='" +
            asiIndicator +
            "'" +
            ", velocitySegment='" +
            velocitySegment +
            "'" +
            ", individualCstmrInstrRef='" +
            individualCstmrInstrRef +
            "'" +
            ", customerInstructionRef='" +
            customerInstructionRef +
            "'" +
            ", bulkProductTypeCode='" +
            bulkProductTypeCode +
            "'" +
            ", productCode='" +
            productCode +
            "'" +
            ", createdBy='" +
            createdBy +
            "'" +
            ", createdDt='" +
            createdDt +
            "'" +
            ", lastUpdatedBy='" +
            lastUpdatedBy +
            "'" +
            ", lastUpdatedDt='" +
            lastUpdatedDt +
            "'" +
            "}"
        );
    }

    public UserDefinedFields update() {
        return update(this);
    }

    public UserDefinedFields persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static UserDefinedFields update(UserDefinedFields userDefinedFields) {
        if (userDefinedFields == null) {
            throw new IllegalArgumentException("userDefinedFields can't be null");
        }
        var entity = UserDefinedFields.<UserDefinedFields>findById(userDefinedFields.id);
        if (entity != null) {
            entity.valueTime = userDefinedFields.valueTime;
            entity.channelLoginId = userDefinedFields.channelLoginId;
            entity.transactionDate = userDefinedFields.transactionDate;
            entity.transactionTime = userDefinedFields.transactionTime;
            entity.productTypeCode = userDefinedFields.productTypeCode;
            entity.asiIndicator = userDefinedFields.asiIndicator;
            entity.velocitySegment = userDefinedFields.velocitySegment;
            entity.individualCstmrInstrRef = userDefinedFields.individualCstmrInstrRef;
            entity.customerInstructionRef = userDefinedFields.customerInstructionRef;
            entity.bulkProductTypeCode = userDefinedFields.bulkProductTypeCode;
            entity.productCode = userDefinedFields.productCode;
            entity.createdBy = userDefinedFields.createdBy;
            entity.createdDt = userDefinedFields.createdDt;
            entity.lastUpdatedBy = userDefinedFields.lastUpdatedBy;
            entity.lastUpdatedDt = userDefinedFields.lastUpdatedDt;
            entity.transactionLevelId = userDefinedFields.transactionLevelId;
            entity.payhubTxnRef = userDefinedFields.payhubTxnRef;
        }
        return entity;
    }

    public static UserDefinedFields persistOrUpdate(UserDefinedFields userDefinedFields) {
        if (userDefinedFields == null) {
            throw new IllegalArgumentException("userDefinedFields can't be null");
        }
        if (userDefinedFields.id == null) {
            persist(userDefinedFields);
            return userDefinedFields;
        } else {
            return update(userDefinedFields);
        }
    }

    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

    }
}
