package com.ncs.pay.config;
import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "neobank")
public interface NeoProperties {
     String cashPoolAccVnd();

}