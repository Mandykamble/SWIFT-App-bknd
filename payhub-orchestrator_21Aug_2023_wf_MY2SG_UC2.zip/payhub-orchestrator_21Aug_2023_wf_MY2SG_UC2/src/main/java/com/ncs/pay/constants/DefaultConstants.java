package com.ncs.pay.constants;

public class DefaultConstants {

    public static final String DefaultExceptionQueueEndpoint= "direct:default-exception-queue";
    public static final String DefaultNonStpCurrencyCheckEndpoint = "direct:non-stp-currency-check-endpoint" ;
    public static final String DefaultSpecialWordsCheckEndpoint = "direct:special-words-check-endpoint" ;
    public static final String DefaultIndustryCutoffTimeCheckEndpoint = "direct:industry-cutoff-time-check-endpoint" ;
    public static final String DefaultDuplicateTxnCheckEndpoint = "direct:duplicate-txn-check-endpoint" ;
    public static final String DefaultDeriveChargesEndpoint = "direct:derive-charges-endpoint" ;
    public static final String DefaultRoundTripCheckEndpoint = "direct:round-trip-check-endpoint" ;
    public static final String DefaultWarehouseCheckEndpoint = "direct:warehouse-check-endpoint" ;
    public static final String DefaultCoverMatchEndpoint = "direct:cover-match-endpoint" ;
    public static final String DefaultSettlementPostingEndpoint = "direct:settlement-posting-endpoint" ;
    public static final String DefaultGenerateOutGoingMessageEndpoint = "direct:settlement-posting-endpoint" ;
    public static final String DefaultAMLCheckEndpoint = "direct:aml-check-endpoint" ;
    public static final String DefaultAutoRepairEndpoint = "direct:auto-repair-endpoint" ;
    public static final String DefaultSendOutgoingMessageEndpoint = "direct:send-outgoing-message-endpoint" ;
    public static final String DefaultNostroPostingEndpoint = "direct:nostro-posting-endpoint" ;
    public static final String DefaultGeneratedAdviceEndpoint = "direct:generate-advice-endpoint" ;
    public static final String DefaultSGBKTXRPreProcessingEndpoint= "direct:sg-bktxr-preprocessor";
    public static final String DefaultFNDTProcessingEndpoint= "direct:sg_fast_cpf-processor";


    public static final String DefaultSGBKTXRProcessingEndpoint= "direct:sg-bktxr-processor";
    public static final String DefaultSGBKTXRPostProcessingEndpoint= "direct:sg-bktxr-postprocessor";


    public static final String JDBCConnectionHealthCheckKey= "JDBCConnectionHealthCheckProp";
    public static final String JDBCConnectionHealthCheckValue= "CONNECTION_OK";

    public static final int DefaultJDBCConnectionRecoveryMaxAttempts= 600;
    public static final int DefaultJDBCConnectionRecoveryRetryInterval= 60000;
    public static final int DefaultCheckTxnRecordRetryMaxAttempts= 10;
    public static final int DefaultCheckTxnRecordRetryInterval= 1000;

    public static final String DefaultSGRTGSProcessingEndpoint= "direct:sg_rtgs_out-processor";

    public static final String DefaultMYRTGSProcessingEndpoint= "direct:my_insta_out-processor";

    public static final String DefaultPHRTGSProcessingEndpoint= "direct:ph_insta_out-processor";

    public static final String DefaultPHInstaPayProcessingEndpoint= "direct:ph_instapay_out-processor";

    public static final String DefaultVnRtgsNeoProcessingEndpoint= "direct:vn_dom_rtgs_neo_processor";

    public static final String DefaultVnRtgsVrtgsProcessingEndpoint= "direct:vn_dom_rtgs_vrtgs_processor";


    public static final String DefaultUOBSGProcessingEndpoint= "direct:sg_napas_out-processor";

    public static final String DefaultUOBVNProcessingEndpoint= "direct:vn_napas_out-processor";

    public static final String DefaultNAPASProcessingEndpoint= "direct:vn_napas_in-processor";


    public static final String BANK_BIC = "";

    public static final String CREDIT_TRANSFER = "pacs.008.001.02";

    public static final String PAYMENT_STATUS = "pacs.002.001.03";
}
