package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * A TransactionGlInfo.
 */
@Entity
@Table(name = "transaction_gl_info")
@Cacheable
@RegisterForReflection
@Data
public class TransactionGlInfo extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Size(max = 36)
    @Column(name = "acct_bank_branch_cds", length = 36)
    public String acctBankBranchCds;

    @Column(name = "acct_entry_sequence_no", precision = 21, scale = 2)
    public BigDecimal acctEntrySequenceNo;

    @Size(max = 80)
    @Column(name = "acct_m", length = 80)
    public String acctM;

    @Size(max = 36)
    @Column(name = "acct_no", length = 36)
    public String acctNo;

    @Size(max = 10)
    @Column(name = "acct_prod_ty", length = 10)
    public String acctProdTy;

    @Size(max = 10)
    @Column(name = "acct_relationship_cd", length = 10)
    public String acctRelationshipCd;

    @Size(max = 10)
    @Column(name = "acct_type", length = 10)
    public String acctType;

    @Column(name = "amt", precision = 21, scale = 2)
    public BigDecimal amt;

    @Column(name = "backward_orig_amt", precision = 21, scale = 2)
    public BigDecimal backwardOrigAmt;

    @Size(max = 10)
    @Column(name = "branch_cd", length = 10)
    public String branchCd;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Size(max = 3)
    @Column(name = "currency", length = 3)
    public String currency;

    @Size(max = 2)
    @Column(name = "debit_credit_ind", length = 2)
    public String debitCreditInd;

    @Size(max = 10)
    @Column(name = "fs_settlm_mode", length = 10)
    public String fsSettlmMode;

    @Size(max = 10)
    @Column(name = "gl_short_m", length = 10)
    public String glShortM;

    @Column(name = "has_interface")
    public Boolean hasInterface;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false)
    public String payhubTxnRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "payment_product_code", length = 50, nullable = false)
    public String paymentProductCode;

    @NotNull
    @Size(max = 50)
    @Column(name = "processing_center_code", length = 50, nullable = false)
    public String processingCenterCode;

    @Column(name = "refund")
    public Boolean refund;

    @Column(name = "sequence", precision = 21, scale = 2)
    public BigDecimal sequence;

    @Size(max = 1)
    @Column(name = "settlm_ind", length = 1)
    public String settlmInd;

    @NotNull
    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = false)
    public String tenantId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionGlInfo)) {
            return false;
        }
        return id != null && id.equals(((TransactionGlInfo) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TransactionGlInfo{" +
            "id=" + id +
            ", acctBankBranchCds='" + acctBankBranchCds + "'" +
            ", acctEntrySequenceNo=" + acctEntrySequenceNo +
            ", acctM='" + acctM + "'" +
            ", acctNo='" + acctNo + "'" +
            ", acctProdTy='" + acctProdTy + "'" +
            ", acctRelationshipCd='" + acctRelationshipCd + "'" +
            ", acctType='" + acctType + "'" +
            ", amt=" + amt +
            ", backwardOrigAmt=" + backwardOrigAmt +
            ", branchCd='" + branchCd + "'" +
            ", countryCd='" + countryCd + "'" +
            ", currency='" + currency + "'" +
            ", debitCreditInd='" + debitCreditInd + "'" +
            ", fsSettlmMode='" + fsSettlmMode + "'" +
            ", glShortM='" + glShortM + "'" +
            ", hasInterface='" + hasInterface + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", paymentProductCode='" + paymentProductCode + "'" +
            ", processingCenterCode='" + processingCenterCode + "'" +
            ", refund='" + refund + "'" +
            ", sequence=" + sequence +
            ", settlmInd='" + settlmInd + "'" +
            ", tenantId='" + tenantId + "'" +
            "}";
    }

    public TransactionGlInfo update() {
        return update(this);
    }

    public TransactionGlInfo persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TransactionGlInfo update(TransactionGlInfo transactionGlInfo) {
        if (transactionGlInfo == null) {
            throw new IllegalArgumentException("transactionGlInfo can't be null");
        }
        var entity = TransactionGlInfo.<TransactionGlInfo>findById(transactionGlInfo.id);
        if (entity != null) {
            entity.acctBankBranchCds = transactionGlInfo.acctBankBranchCds;
            entity.acctEntrySequenceNo = transactionGlInfo.acctEntrySequenceNo;
            entity.acctM = transactionGlInfo.acctM;
            entity.acctNo = transactionGlInfo.acctNo;
            entity.acctProdTy = transactionGlInfo.acctProdTy;
            entity.acctRelationshipCd = transactionGlInfo.acctRelationshipCd;
            entity.acctType = transactionGlInfo.acctType;
            entity.amt = transactionGlInfo.amt;
            entity.backwardOrigAmt = transactionGlInfo.backwardOrigAmt;
            entity.branchCd = transactionGlInfo.branchCd;
            entity.countryCd = transactionGlInfo.countryCd;
            entity.currency = transactionGlInfo.currency;
            entity.debitCreditInd = transactionGlInfo.debitCreditInd;
            entity.fsSettlmMode = transactionGlInfo.fsSettlmMode;
            entity.glShortM = transactionGlInfo.glShortM;
            entity.hasInterface = transactionGlInfo.hasInterface;
            entity.payhubTxnRef = transactionGlInfo.payhubTxnRef;
            entity.paymentProductCode = transactionGlInfo.paymentProductCode;
            entity.processingCenterCode = transactionGlInfo.processingCenterCode;
            entity.refund = transactionGlInfo.refund;
            entity.sequence = transactionGlInfo.sequence;
            entity.settlmInd = transactionGlInfo.settlmInd;
            entity.tenantId = transactionGlInfo.tenantId;
        }
        return entity;
    }

    public static TransactionGlInfo persistOrUpdate(TransactionGlInfo transactionGlInfo) {
        if (transactionGlInfo == null) {
            throw new IllegalArgumentException("transactionGlInfo can't be null");
        }
        if (transactionGlInfo.id == null) {
            persist(transactionGlInfo);
            return transactionGlInfo;
        } else {
            return update(transactionGlInfo);
        }
    }


}
