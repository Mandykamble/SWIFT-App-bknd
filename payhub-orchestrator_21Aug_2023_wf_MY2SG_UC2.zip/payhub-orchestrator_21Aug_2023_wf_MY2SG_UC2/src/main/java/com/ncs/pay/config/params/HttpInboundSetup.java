package com.ncs.pay.config.params;

import lombok.Data;

@Data
public class HttpInboundSetup {
   private String rootContext;
    private String createPaymentsContext;
    private String TargetInboundRoutingEndpoint;

}
