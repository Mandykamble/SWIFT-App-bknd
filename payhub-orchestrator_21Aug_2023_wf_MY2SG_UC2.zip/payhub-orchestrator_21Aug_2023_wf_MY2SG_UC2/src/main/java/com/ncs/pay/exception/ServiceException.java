package com.ncs.pay.exception;


import org.springframework.messaging.Message;

public class ServiceException extends Throwable{

    /**
     *
     */
    private static final long serialVersionUID = 7184994757841068432L;

    public ServiceException(Throwable cause) {
//        super(cause);
    }

    /**
     * Constructs a new exception with the specified message
     *
     * @param message
     *                The message
     */
    public ServiceException(Message message) {
//        super(message);
    }

    /**
     * Constructs a new exception with the specified message and cause
     *
     * @param message
     *                The message
     * @param cause
     *                The cause
     */
    public ServiceException(Message message, Throwable cause) {
//        super(message, cause);
    }
}

