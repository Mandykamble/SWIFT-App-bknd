package com.ncs.pay.config.params;

import lombok.Data;


public interface ChannelProductConfiguration {
     String productCd();
     String upstreamCutoffTime();
}
