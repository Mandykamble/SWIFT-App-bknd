package com.ncs.pay.config;

import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "sg")
public interface SGProperties {
     String cashPoolAccSgd();
     String cashPoolAccVnd();
     
     String nostroAcc();
     String cashPoolAccUsd();
}