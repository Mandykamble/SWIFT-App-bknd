package com.ncs.pay.constants;

/**
 * @author Amila Karunathilaka
 */
public enum CasStageCode {
    RCV_REQMSG("L001", "Receive request message from SBI ESB", TxnStatus.RECV),
    REQOBJ_TO_ENTITY("L002", "SOAP XML rquest -> Entity Class", TxnStatus.RECV),
    ENTITY_TO_MSGOBJ("L003", "Entity Class -> ISO Message Object", TxnStatus.RECV),
    MSGOBJ_TO_MSG("L004", "ISO Message Object -> ISO XML Message", TxnStatus.RECV),
    SEND_REQMSG("L005", "Put XML message to CAS", null),
    RCV_RSPMSG("L006", "Receive response XML message from CAS", null),
    MSG_TO_MSGOBJ("L007", "ISO XML Message -> ISO Message Object", null),
    MSGOBJ_TO_ENTITY("L008", "ISO Message Object -> Entity Class", null),
    ENTITY_TO_RSPOBJ("L009", "Entity Class -> SOAP XML Response", null),
    SEND_RESXML("L010", "Send SOAP XML Response to SBI ESB", null);

    private final String code;
    private final String description;
    private TxnStatus adaptorStatus;

    CasStageCode(String code, String description, TxnStatus adaptorStatus) {
        this.code = code;
        this.description = description;
        this.adaptorStatus = adaptorStatus;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public TxnStatus getAdaptorStatus() {
        return adaptorStatus;
    }

}
