package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.runtime.annotations.RegisterForReflection;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.*;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A InstructionLevel.
 */
@Entity
@Table(name = "instruction_level")
@Cacheable
@RegisterForReflection
@Data
public class InstructionLevel extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "instrut_ref", length = 100, nullable = false)
    public String instrutRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "pmt_inf_id", length = 50, nullable = false)
    public String pmtInfId;

    @NotNull
    @Size(max = 50)
    @Column(name = "pmt_mtd", length = 50, nullable = false)
    public String pmtMtd;

    @Column(name = "btch_bookg")
    public Boolean btchBookg;

    @Size(max = 15)
    @Column(name = "svc_lvl", length = 15)
    public String svcLvl;

    @Size(max = 10)
    @Column(name = "chrg_br", length = 10)
    public String chrgBr;

    @Size(max = 15)
    @Column(name = "lcl_instrm", length = 15)
    public String lclInstrm;

    @Column(name = "reqd_exctn_dt")
    public LocalDate reqdExctnDt;

    @Size(max = 255)
    @Column(name = "dbtr_nm", length = 255)
    public String dbtrNm;

    @Size(max = 40)
    @Column(name = "dbtr_acct", length = 40)
    public String dbtrAcct;

    @Size(max = 40)
    @Column(name = "dbtr_acct_type", length = 40)
    public String dbtrAcctType;

    @Size(max = 6)
    @Column(name = "dbtr_acct_ccy", length = 6)
    public String dbtrAcctCcy;

    @Size(max = 40)
    @Column(name = "dbtr_agt_id", length = 40)
    public String dbtrAgtId;

    @Size(max = 255)
    @Column(name = "cdtr_nm", length = 255)
    public String cdtrNm;

    @Size(max = 40)
    @Column(name = "cdtr_acct", length = 40)
    public String cdtrAcct;

    @Size(max = 40)
    @Column(name = "cdtr_acct_type", length = 40)
    public String cdtrAcctType;

    @Size(max = 6)
    @Column(name = "cdtr_acct_ccy", length = 6)
    public String cdtrAcctCcy;

    @Size(max = 40)
    @Column(name = "cdtr_agt_id", length = 40)
    public String cdtrAgtId;

    @Size(max = 20)
    @Column(name = "error_code", length = 20)
    public String errorCode;

    @Size(max = 20)
    @Column(name = "stage_code", length = 20)
    public String stageCode;

    @Size(max = 20)
    @Column(name = "instruct_lvl_status", length = 20)
    public String instructLvlStatus;

    @Size(max = 400)
    @Column(name = "instruct_remarks", length = 400)
    public String instructRemarks;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @OneToMany(mappedBy = "instructionLevel")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    public Set<TransactionLevel> transactionLevels = new HashSet<>();

    @ManyToOne
    @JoinColumn(name = "message_level_id")
    @JsonbTransient
    public MessageLevel messageLevel;

    @NotNull
    @Column(name = "msg_info_id", nullable = false)
    public Long messageInfoId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof InstructionLevel)) {
            return false;
        }
        return id != null && id.equals(((InstructionLevel) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return (
            "InstructionLevel{" +
            "id=" +
            id +
            ", instrutRef='" +
            instrutRef +
            "'" +
            ", pmtInfId='" +
            pmtInfId +
            "'" +
            ", pmtMtd='" +
            pmtMtd +
            "'" +
            ", btchBookg='" +
            btchBookg +
            "'" +
            ", svcLvl='" +
            svcLvl +
            "'" +
            ", chrgBr='" +
            chrgBr +
            "'" +
            ", lclInstrm='" +
            lclInstrm +
            "'" +
            ", reqdExctnDt='" +
            reqdExctnDt +
            "'" +
            ", dbtrNm='" +
            dbtrNm +
            "'" +
            ", dbtrAcct='" +
            dbtrAcct +
            "'" +
            ", dbtrAcctType='" +
            dbtrAcctType +
            "'" +
            ", dbtrAcctCcy='" +
            dbtrAcctCcy +
            "'" +
            ", dbtrAgtId='" +
            dbtrAgtId +
            "'" +
            ", cdtrNm='" +
            cdtrNm +
            "'" +
            ", cdtrAcct='" +
            cdtrAcct +
            "'" +
            ", cdtrAcctType='" +
            cdtrAcctType +
            "'" +
            ", cdtrAcctCcy='" +
            cdtrAcctCcy +
            "'" +
            ", cdtrAgtId='" +
            cdtrAgtId +
            "'" +
            ", errorCode='" +
            errorCode +
            "'" +
            ", stageCode='" +
            stageCode +
            "'" +
            ", instructLvlStatus='" +
            instructLvlStatus +
            "'" +
            ", instructRemarks='" +
            instructRemarks +
            "'" +
            ", lockFlag=" +
            lockFlag +
            ", createdBy='" +
            createdBy +
            "'" +
            ", createdDt='" +
            createdDt +
            "'" +
            ", lastUpdatedBy='" +
            lastUpdatedBy +
            "'" +
            ", lastUpdatedDt='" +
            lastUpdatedDt +
            "'" +
            "}"
        );
    }

    public InstructionLevel update() {
        return update(this);
    }

    public InstructionLevel persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static InstructionLevel update(InstructionLevel instructionLevel) {
        if (instructionLevel == null) {
            throw new IllegalArgumentException("instructionLevel can't be null");
        }
        var entity = InstructionLevel.<InstructionLevel>findById(instructionLevel.id);
        if (entity != null) {
            entity.instrutRef = instructionLevel.instrutRef;
            entity.pmtInfId = instructionLevel.pmtInfId;
            entity.pmtMtd = instructionLevel.pmtMtd;
            entity.btchBookg = instructionLevel.btchBookg;
            entity.svcLvl = instructionLevel.svcLvl;
            entity.chrgBr = instructionLevel.chrgBr;
            entity.lclInstrm = instructionLevel.lclInstrm;
            entity.reqdExctnDt = instructionLevel.reqdExctnDt;
            entity.dbtrNm = instructionLevel.dbtrNm;
            entity.dbtrAcct = instructionLevel.dbtrAcct;
            entity.dbtrAcctType = instructionLevel.dbtrAcctType;
            entity.dbtrAcctCcy = instructionLevel.dbtrAcctCcy;
            entity.dbtrAgtId = instructionLevel.dbtrAgtId;
            entity.cdtrNm = instructionLevel.cdtrNm;
            entity.cdtrAcct = instructionLevel.cdtrAcct;
            entity.cdtrAcctType = instructionLevel.cdtrAcctType;
            entity.cdtrAcctCcy = instructionLevel.cdtrAcctCcy;
            entity.cdtrAgtId = instructionLevel.cdtrAgtId;
            entity.errorCode = instructionLevel.errorCode;
            entity.stageCode = instructionLevel.stageCode;
            entity.instructLvlStatus = instructionLevel.instructLvlStatus;
            entity.instructRemarks = instructionLevel.instructRemarks;
            entity.lockFlag = instructionLevel.lockFlag;
            entity.createdBy = instructionLevel.createdBy;
            entity.createdDt = instructionLevel.createdDt;
            entity.lastUpdatedBy = instructionLevel.lastUpdatedBy;
            entity.lastUpdatedDt = instructionLevel.lastUpdatedDt;
            entity.transactionLevels = instructionLevel.transactionLevels;
            entity.messageLevel = instructionLevel.messageLevel;
            entity.messageInfoId =instructionLevel.messageInfoId;
        }
        return entity;
    }

    public static InstructionLevel persistOrUpdate(InstructionLevel instructionLevel) {
        if (instructionLevel == null) {
            throw new IllegalArgumentException("instructionLevel can't be null");
        }
        if (instructionLevel.id == null) {
            persist(instructionLevel);
            return instructionLevel;
        } else {
            return update(instructionLevel);
        }
    }

    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

    }
}
