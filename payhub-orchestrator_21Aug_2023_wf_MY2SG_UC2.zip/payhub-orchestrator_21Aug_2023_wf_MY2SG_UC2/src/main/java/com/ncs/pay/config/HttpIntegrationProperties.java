package com.ncs.pay.config;

//import io.quarkus.arc.config.ConfigProperties;
import io.smallrye.config.ConfigMapping;
import lombok.Data;



@ConfigMapping(prefix = "payhub.integration.http")
public interface HttpIntegrationProperties {
     String rootContext();
     String createPaymentsContext();
     String paymentStatusContext();
     String targetIso20022InboundRoutingEndpoint();
     String targetInstaPayInboundRoutingEndpoint();

     String targetVnDomRtgsInboundRoutingEndpoint();


     String targetVnVrtgsInboundRoutingEndpoint();
     String targetFastInboundRoutingEndpoint();
     String targetFundtInboundRoutingEndpoint();
     String iso20022Pain001Context();
     String iso20022Pain002Context();

     String targetInterMaybankInboundRoutingEndpoint();
}
