package com.ncs.pay.config.params;

import lombok.Data;


public interface MessageRoutingSetup {
     String defaultProcessingQueue();
     String defaultProcessingExceptionQueue();

}
