package com.ncs.pay.config.params;

import lombok.Data;

import java.util.List;

public interface ChannelSetup {
     String channelId();
     String countryCd();
     List<ChannelProductConfiguration> productConfigurations();
}
