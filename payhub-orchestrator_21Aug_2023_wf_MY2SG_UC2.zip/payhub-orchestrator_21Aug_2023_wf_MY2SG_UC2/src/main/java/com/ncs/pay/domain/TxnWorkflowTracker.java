package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.List;

/**
 * A TxnWorkflowTracker.
 */
@Entity
@Table(name = "txn_workflow_tracker")
@RegisterForReflection
@Data
public class TxnWorkflowTracker extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 30)
    @Column(name = "execution_status", length = 30, nullable = false)
    public String executionStatus;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false)
    public String payhubTxnRef;

    @NotNull
    @Column(name = "sequence_id", nullable = false)
    public Integer sequenceId;

    @NotNull
    @Size(max = 100)
    @Column(name = "workflow_stage_code", length = 100, nullable = false)
    public String workflowStageCode;



    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TxnWorkflowTracker)) {
            return false;
        }
        return id != null && id.equals(((TxnWorkflowTracker) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TxnWorkflowTracker{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", executionStatus='" + executionStatus + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", sequenceId=" + sequenceId +
            ", workflowStageCode='" + workflowStageCode + "'" +
            "}";
    }

    public TxnWorkflowTracker update() {
        return update(this);
    }

    public TxnWorkflowTracker persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TxnWorkflowTracker update(TxnWorkflowTracker txnWorkflowTracker) {
        if (txnWorkflowTracker == null) {
            throw new IllegalArgumentException("txnWorkflowTracker can't be null");
        }
        var entity = TxnWorkflowTracker.<TxnWorkflowTracker>findById(txnWorkflowTracker.id);
        if (entity != null) {
            entity.recordId = txnWorkflowTracker.recordId;
            entity.createdBy = txnWorkflowTracker.createdBy;
            entity.createdDt = txnWorkflowTracker.createdDt;
            entity.lastUpdatedBy = txnWorkflowTracker.lastUpdatedBy;
            entity.lastUpdatedDt = txnWorkflowTracker.lastUpdatedDt;
            entity.lockFlag = txnWorkflowTracker.lockFlag;
            entity.executionStatus = txnWorkflowTracker.executionStatus;
            entity.payhubTxnRef = txnWorkflowTracker.payhubTxnRef;
            entity.sequenceId = txnWorkflowTracker.sequenceId;
            entity.workflowStageCode = txnWorkflowTracker.workflowStageCode;
        }
        return entity;
    }

    public static TxnWorkflowTracker persistOrUpdate(TxnWorkflowTracker txnWorkflowTracker) {
        if (txnWorkflowTracker == null) {
            throw new IllegalArgumentException("txnWorkflowTracker can't be null");
        }
        if (txnWorkflowTracker.id == null) {
            persist(txnWorkflowTracker);
            return txnWorkflowTracker;
        } else {
            return update(txnWorkflowTracker);
        }
    }

    public static List<TxnWorkflowTracker> findByPayhubTxnRef(String payhubTxnRef) {
        return find("payhubTxnRef", payhubTxnRef).list();

    }

    public static TxnWorkflowTracker findByPayhubTxnRefAndWorkflowStageCode(String payhubTxnRef, String workflowStageCode) {
        return find("payhubTxnRef = ?1 and workflowStageCode = ?2", payhubTxnRef, workflowStageCode).firstResult();

    }


    @PrePersist
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

        this.setRecordId(0L);
    }


}
