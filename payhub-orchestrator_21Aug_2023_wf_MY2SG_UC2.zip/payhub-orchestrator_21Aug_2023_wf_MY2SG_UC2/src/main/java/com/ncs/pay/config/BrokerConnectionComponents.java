package com.ncs.pay.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.component.amqp.AMQPComponent;

import javax.annotation.PostConstruct;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
@Slf4j
public class BrokerConnectionComponents {
    @Inject
    CamelContext camelContext;

    @Inject
    MessagingIntegrationProperties messagingIntegrationProperties;

    public BrokerConnectionComponents(MessagingIntegrationProperties messagingIntegrationProperties, CamelContext camelContext){
        this.messagingIntegrationProperties =messagingIntegrationProperties;
        this.camelContext =camelContext;
    }

    @PostConstruct
    public void customizeContextForAMQP() {

        messagingIntegrationProperties.brokers().forEach(broker ->{
            log.info("Creating connection factory for broker: " + broker.brokerId() + " and URL: " + broker.brokerId());
            camelContext.addComponent(broker.brokerId(), AMQPComponent.amqpComponent(broker.brokerUrl()));
        });

    }

   /* */
}
