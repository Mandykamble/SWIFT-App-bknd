package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;

/**
 * A SystemProperties.
 */
@Entity
@Table(name = "system_properties")
@RegisterForReflection
public class SystemProperties extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @Size(max = 255)
    @Column(name = "approved_by", length = 255)
    public String approvedBy;

    @Column(name = "approved_dt")
    public Instant approvedDt;

    @NotNull
    @Column(name = "is_draft", nullable = false)
    public Boolean isDraft;

    @Column(name = "original_record_id")
    public Long originalRecordId;

    @NotNull
    @Column(name = "pending_approval", nullable = false)
    public Boolean pendingApproval;

    @NotNull
    @Size(max = 30)
    @Column(name = "property_group", length = 30, nullable = false)
    public String propertyGroup;

    @NotNull
    @Size(max = 150)
    @Column(name = "property_key", length = 150, nullable = false, unique = true)
    public String propertyKey;

    @NotNull
    @Size(max = 300)
    @Column(name = "property_value", length = 300, nullable = false)
    public String propertyValue;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SystemProperties)) {
            return false;
        }
        return id != null && id.equals(((SystemProperties) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "SystemProperties{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", approvedBy='" + approvedBy + "'" +
            ", approvedDt='" + approvedDt + "'" +
            ", isDraft='" + isDraft + "'" +
            ", originalRecordId=" + originalRecordId +
            ", pendingApproval='" + pendingApproval + "'" +
            ", propertyGroup='" + propertyGroup + "'" +
            ", propertyKey='" + propertyKey + "'" +
            ", propertyValue='" + propertyValue + "'" +
            "}";
    }

    public SystemProperties update() {
        return update(this);
    }

    public SystemProperties persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static SystemProperties update(SystemProperties systemProperties) {
        if (systemProperties == null) {
            throw new IllegalArgumentException("systemProperties can't be null");
        }
        var entity = SystemProperties.<SystemProperties>findById(systemProperties.id);
        if (entity != null) {
            entity.recordId = systemProperties.recordId;
            entity.createdBy = systemProperties.createdBy;
            entity.createdDt = systemProperties.createdDt;
            entity.lastUpdatedBy = systemProperties.lastUpdatedBy;
            entity.lastUpdatedDt = systemProperties.lastUpdatedDt;
            entity.lockFlag = systemProperties.lockFlag;
            entity.approvedBy = systemProperties.approvedBy;
            entity.approvedDt = systemProperties.approvedDt;
            entity.isDraft = systemProperties.isDraft;
            entity.originalRecordId = systemProperties.originalRecordId;
            entity.pendingApproval = systemProperties.pendingApproval;
            entity.propertyGroup = systemProperties.propertyGroup;
            entity.propertyKey = systemProperties.propertyKey;
            entity.propertyValue = systemProperties.propertyValue;
        }
        return entity;
    }

    public static SystemProperties persistOrUpdate(SystemProperties systemProperties) {
        if (systemProperties == null) {
            throw new IllegalArgumentException("systemProperties can't be null");
        }
        if (systemProperties.id == null) {
            persist(systemProperties);
            return systemProperties;
        } else {
            return update(systemProperties);
        }
    }


}
