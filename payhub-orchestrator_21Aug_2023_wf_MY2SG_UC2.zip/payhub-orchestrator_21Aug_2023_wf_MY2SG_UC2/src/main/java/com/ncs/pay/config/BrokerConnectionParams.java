package com.ncs.pay.config;

import lombok.Data;


public interface BrokerConnectionParams {
     String brokerId();

     String brokerUrl();
}
