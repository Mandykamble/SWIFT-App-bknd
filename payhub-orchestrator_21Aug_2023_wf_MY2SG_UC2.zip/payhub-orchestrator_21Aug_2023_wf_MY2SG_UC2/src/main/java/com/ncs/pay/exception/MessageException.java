package com.ncs.pay.exception;

public class MessageException extends Exception {

	public MessageException() {
		super();
	}

	public MessageException(String msg) {
		super(msg);
	}

	public MessageException(String msg, Throwable e) {
		super(msg, e);
	}

	public MessageException(String msg, StackTraceElement stackTraceElement[]) {
		super(msg);
	}

	public MessageException(String msg, Throwable e,
                            StackTraceElement stackTraceElement[]) {
		super(msg, e);
	}
}
