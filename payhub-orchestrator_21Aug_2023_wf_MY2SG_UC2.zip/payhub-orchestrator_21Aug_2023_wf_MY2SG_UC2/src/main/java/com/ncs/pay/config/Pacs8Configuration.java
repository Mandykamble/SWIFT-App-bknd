package com.ncs.pay.config;

import io.smallrye.config.ConfigMapping;


@ConfigMapping(prefix = "pacs8")
public interface Pacs8Configuration {
     String g3bic();
     String bankbic();
     String serviceLevelCode();
     String chargeBearer();
     String settlementMethod();
     String clearingSystemCode();
}
