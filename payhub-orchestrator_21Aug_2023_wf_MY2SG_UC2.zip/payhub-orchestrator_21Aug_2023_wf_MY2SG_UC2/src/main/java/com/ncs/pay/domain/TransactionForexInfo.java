package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Calendar;

/**
 * A TransactionForexInfo.
 */
@Entity
@Table(name = "transaction_forex_info")
@Cacheable
@RegisterForReflection
@Data
public class TransactionForexInfo extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Size(max = 36)
    @Column(name = "acct_no", length = 36, nullable = false)
    public String acctNo;

    @Column(name = "agent_rate", precision = 21, scale = 2)
    public BigDecimal agentRate;

    @Column(name = "buy_amt", precision = 21, scale = 2)
    public BigDecimal buyAmt;

    @Column(name = "buy_ccy_buy_rate", precision = 21, scale = 2)
    public BigDecimal buyCcyBuyRate;

    @Column(name = "buy_ccy_negative_spread", precision = 21, scale = 2)
    public BigDecimal buyCcyNegativeSpread;

    @Column(name = "buy_ccy_positive_spread", precision = 21, scale = 2)
    public BigDecimal buyCcyPositiveSpread;

    @Column(name = "buy_ccy_sell_rate", precision = 21, scale = 2)
    public BigDecimal buyCcySellRate;

    @Column(name = "buy_ccy_unit_factor", precision = 21, scale = 2)
    public BigDecimal buyCcyUnitFactor;

    @Column(name = "buy_value_dt")
    public LocalDate buyValueDt;

    @Column(name = "coll_board_rate", precision = 21, scale = 2)
    public BigDecimal collBoardRate;

    @Size(max = 3)
    @Column(name = "coll_currency", length = 3)
    public String collCurrency;

    @Size(max = 50)
    @Column(name = "contract_ref", length = 50)
    public String contractRef;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Size(max = 10)
    @Column(name = "exchange_type", length = 10)
    public String exchangeType;

    @Column(name = "factor", precision = 21, scale = 2)
    public BigDecimal factor;

    @Size(max = 10)
    @Column(name = "fx_product_ty", length = 10)
    public String fxProductTy;

    @Column(name = "gl_sequence", precision = 21, scale = 2)
    public BigDecimal glSequence;

    @Column(name = "option_period_end_dt")
    public LocalDate optionPeriodEndDt;

    @Column(name = "option_period_start_dt")
    public LocalDate optionPeriodStartDt;

    @Column(name = "orig_board_rate", precision = 21, scale = 2)
    public BigDecimal origBoardRate;

    @Size(max = 3)
    @Column(name = "orig_currency_cd", length = 3)
    public String origCurrencyCd;

    @Column(name = "orig_rate", precision = 21, scale = 2)
    public BigDecimal origRate;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false, unique = true)
    public String payhubTxnRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "payment_product_code", length = 50, nullable = false)
    public String paymentProductCode;

    @NotNull
    @Size(max = 50)
    @Column(name = "processing_center_code", length = 50, nullable = false)
    public String processingCenterCode;

    @Size(max = 3)
    @Column(name = "ref_currency_cd", length = 3)
    public String refCurrencyCd;

    @Column(name = "sell_amt", precision = 21, scale = 2)
    public BigDecimal sellAmt;

    @Column(name = "sell_ccy_buy_rate", precision = 21, scale = 2)
    public BigDecimal sellCcyBuyRate;

    @Column(name = "sell_ccy_negative_spread", precision = 21, scale = 2)
    public BigDecimal sellCcyNegativeSpread;

    @Column(name = "sell_ccy_positive_spread", precision = 21, scale = 2)
    public BigDecimal sellCcyPositiveSpread;

    @Column(name = "sell_ccy_sell_rate", precision = 21, scale = 2)
    public BigDecimal sellCcySellRate;

    @Column(name = "sell_ccy_unit_factor", precision = 21, scale = 2)
    public BigDecimal sellCcyUnitFactor;

    @Size(max = 3)
    @Column(name = "sell_currency_cd", length = 3)
    public String sellCurrencyCd;

    @Column(name = "sequence", precision = 21, scale = 2)
    public BigDecimal sequence;

    @Size(max = 1)
    @Column(name = "special_ind", length = 1)
    public String specialInd;

    @Size(max = 1)
    @Column(name = "staff_ind", length = 1)
    public String staffInd;

    @Size(max = 50)
    @Column(name = "temp_contract_ref", length = 50)
    public String tempContractRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = false)
    public String tenantId;

    @Column(name = "trade_dt")
    public LocalDate tradeDt;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionForexInfo)) {
            return false;
        }
        return id != null && id.equals(((TransactionForexInfo) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TransactionForexInfo{" +
            "id=" + id +
            ", acctNo='" + acctNo + "'" +
            ", agentRate=" + agentRate +
            ", buyAmt=" + buyAmt +
            ", buyCcyBuyRate=" + buyCcyBuyRate +
            ", buyCcyNegativeSpread=" + buyCcyNegativeSpread +
            ", buyCcyPositiveSpread=" + buyCcyPositiveSpread +
            ", buyCcySellRate=" + buyCcySellRate +
            ", buyCcyUnitFactor=" + buyCcyUnitFactor +
            ", buyValueDt='" + buyValueDt + "'" +
            ", collBoardRate=" + collBoardRate +
            ", collCurrency='" + collCurrency + "'" +
            ", contractRef='" + contractRef + "'" +
            ", countryCd='" + countryCd + "'" +
            ", exchangeType='" + exchangeType + "'" +
            ", factor=" + factor +
            ", fxProductTy='" + fxProductTy + "'" +
            ", glSequence=" + glSequence +
            ", optionPeriodEndDt='" + optionPeriodEndDt + "'" +
            ", optionPeriodStartDt='" + optionPeriodStartDt + "'" +
            ", origBoardRate=" + origBoardRate +
            ", origCurrencyCd='" + origCurrencyCd + "'" +
            ", origRate=" + origRate +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", paymentProductCode='" + paymentProductCode + "'" +
            ", processingCenterCode='" + processingCenterCode + "'" +
            ", refCurrencyCd='" + refCurrencyCd + "'" +
            ", sellAmt=" + sellAmt +
            ", sellCcyBuyRate=" + sellCcyBuyRate +
            ", sellCcyNegativeSpread=" + sellCcyNegativeSpread +
            ", sellCcyPositiveSpread=" + sellCcyPositiveSpread +
            ", sellCcySellRate=" + sellCcySellRate +
            ", sellCcyUnitFactor=" + sellCcyUnitFactor +
            ", sellCurrencyCd='" + sellCurrencyCd + "'" +
            ", sequence=" + sequence +
            ", specialInd='" + specialInd + "'" +
            ", staffInd='" + staffInd + "'" +
            ", tempContractRef='" + tempContractRef + "'" +
            ", tenantId='" + tenantId + "'" +
            ", tradeDt='" + tradeDt + "'" +
            "}";
    }

    public TransactionForexInfo update() {
        return update(this);
    }

    public TransactionForexInfo persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TransactionForexInfo update(TransactionForexInfo transactionForexInfo) {
        if (transactionForexInfo == null) {
            throw new IllegalArgumentException("transactionForexInfo can't be null");
        }
        var entity = TransactionForexInfo.<TransactionForexInfo>findById(transactionForexInfo.id);
        if (entity != null) {
            entity.acctNo = transactionForexInfo.acctNo;
            entity.agentRate = transactionForexInfo.agentRate;
            entity.buyAmt = transactionForexInfo.buyAmt;
            entity.buyCcyBuyRate = transactionForexInfo.buyCcyBuyRate;
            entity.buyCcyNegativeSpread = transactionForexInfo.buyCcyNegativeSpread;
            entity.buyCcyPositiveSpread = transactionForexInfo.buyCcyPositiveSpread;
            entity.buyCcySellRate = transactionForexInfo.buyCcySellRate;
            entity.buyCcyUnitFactor = transactionForexInfo.buyCcyUnitFactor;
            entity.buyValueDt = transactionForexInfo.buyValueDt;
            entity.collBoardRate = transactionForexInfo.collBoardRate;
            entity.collCurrency = transactionForexInfo.collCurrency;
            entity.contractRef = transactionForexInfo.contractRef;
            entity.countryCd = transactionForexInfo.countryCd;
            entity.exchangeType = transactionForexInfo.exchangeType;
            entity.factor = transactionForexInfo.factor;
            entity.fxProductTy = transactionForexInfo.fxProductTy;
            entity.glSequence = transactionForexInfo.glSequence;
            entity.optionPeriodEndDt = transactionForexInfo.optionPeriodEndDt;
            entity.optionPeriodStartDt = transactionForexInfo.optionPeriodStartDt;
            entity.origBoardRate = transactionForexInfo.origBoardRate;
            entity.origCurrencyCd = transactionForexInfo.origCurrencyCd;
            entity.origRate = transactionForexInfo.origRate;
            entity.payhubTxnRef = transactionForexInfo.payhubTxnRef;
            entity.paymentProductCode = transactionForexInfo.paymentProductCode;
            entity.processingCenterCode = transactionForexInfo.processingCenterCode;
            entity.refCurrencyCd = transactionForexInfo.refCurrencyCd;
            entity.sellAmt = transactionForexInfo.sellAmt;
            entity.sellCcyBuyRate = transactionForexInfo.sellCcyBuyRate;
            entity.sellCcyNegativeSpread = transactionForexInfo.sellCcyNegativeSpread;
            entity.sellCcyPositiveSpread = transactionForexInfo.sellCcyPositiveSpread;
            entity.sellCcySellRate = transactionForexInfo.sellCcySellRate;
            entity.sellCcyUnitFactor = transactionForexInfo.sellCcyUnitFactor;
            entity.sellCurrencyCd = transactionForexInfo.sellCurrencyCd;
            entity.sequence = transactionForexInfo.sequence;
            entity.specialInd = transactionForexInfo.specialInd;
            entity.staffInd = transactionForexInfo.staffInd;
            entity.tempContractRef = transactionForexInfo.tempContractRef;
            entity.tenantId = transactionForexInfo.tenantId;
            entity.tradeDt = transactionForexInfo.tradeDt;
        }
        return entity;
    }

    public static TransactionForexInfo persistOrUpdate(TransactionForexInfo transactionForexInfo) {
        if (transactionForexInfo == null) {
            throw new IllegalArgumentException("transactionForexInfo can't be null");
        }
        if (transactionForexInfo.id == null) {
            persist(transactionForexInfo);
            return transactionForexInfo;
        } else {
            return update(transactionForexInfo);
        }
    }

/*    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

        this.setRecordId(0L);
    }*/


}
