package com.ncs.pay.model.constants;

public class ErrorCodes {
    //Exception Error Codes
    public static final String ROUTER_STARTUP_FAILED = "ROUTER_STARTUP_FAILED";
    public static final String UNHANDLED_EXCEPTION = "UNHANDLED_EXCEPTION";
    public static final String PERSISTENCE_EXCEPTION = "PERSISTENCE_EXCEPTION";
    public static final String MISSING_RECORD = "MISSING_RECORD";
    public static final String RECORD_ALREADY_EXISTS = "RECORD_ALREADY_EXISTS";

    public static final String MISSING_CONFIGURATION = "MISSING_CONFIGURATION";
    //Processing Error Codes
    public static final String DEFAULT_ROUTING_ERROR = "DEFAULT_ROUTING_ERROR";
    public static final String MAX_RETRIES_EXCEEDED = "MAX_RETRIES_EXCEEDED";




}
