package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * A TransactionCharges.
 */
@Entity
@Table(name = "transaction_charges")
@Cacheable
@RegisterForReflection
public class TransactionCharges extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Size(max = 36)
    @Column(name = "acct_no", length = 36, nullable = false)
    public String acctNo;

    @Size(max = 36)
    @Column(name = "acct_no_bank_branch_cd", length = 36)
    public String acctNoBankBranchCd;

    @Size(max = 10)
    @Column(name = "acct_type", length = 10)
    public String acctType;

    @Column(name = "accurate_override_amt", precision = 21, scale = 2)
    public BigDecimal accurateOverrideAmt;

    @Size(max = 3)
    @Column(name = "agent_cr_acct_currency", length = 3)
    public String agentCrAcctCurrency;

    @Size(max = 36)
    @Column(name = "agent_cr_acct_no", length = 36)
    public String agentCrAcctNo;

    @Size(max = 3)
    @Column(name = "agent_cr_acct_type", length = 3)
    public String agentCrAcctType;

    @Column(name = "agent_cr_amt", precision = 21, scale = 2)
    public BigDecimal agentCrAmt;

    @Column(name = "agent_cr_board_rate", precision = 21, scale = 2)
    public BigDecimal agentCrBoardRate;

    @Size(max = 36)
    @Column(name = "agt_cr_acct_no_bank_branch_cds", length = 36)
    public String agtCrAcctNoBankBranchCds;

    @Column(name = "board_rate", precision = 21, scale = 2)
    public BigDecimal boardRate;

    @Column(name = "charge_amt", precision = 21, scale = 2)
    public BigDecimal chargeAmt;

    @Size(max = 3)
    @Column(name = "charge_currency", length = 3)
    public String chargeCurrency;

    @Size(max = 140)
    @Column(name = "charge_desc", length = 140)
    public String chargeDesc;

    @Size(max = 16)
    @Column(name = "charge_id", length = 16)
    public String chargeId;

    @Size(max = 30)
    @Column(name = "charge_type", length = 30)
    public String chargeType;

    @Size(max = 50)
    @Column(name = "contract_ref", length = 50)
    public String contractRef;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Column(name = "cr_acct_entry_sequence_no")
    public Long crAcctEntrySequenceNo;

    @Size(max = 50)
    @Column(name = "deferred_override_ind", length = 50)
    public String deferredOverrideInd;

    @Column(name = "display_rate", precision = 21, scale = 2)
    public BigDecimal displayRate;

    @Column(name = "dr_acct_entry_sequence_no")
    public Long drAcctEntrySequenceNo;

    @Size(max = 10)
    @Column(name = "exchange_type", length = 10)
    public String exchangeType;

    @Size(max = 4)
    @Column(name = "gl_short_name", length = 4)
    public String glShortName;

    @NotNull
    @Column(name = "is_adhoc_charge", nullable = false)
    public Boolean isAdhocCharge;

    @NotNull
    @Column(name = "is_deferred", nullable = false)
    public Boolean isDeferred;

    @NotNull
    @Column(name = "is_waived", nullable = false)
    public Boolean isWaived;

    @Size(max = 36)
    @Column(name = "original_agent_cr_acct_no", length = 36)
    public String originalAgentCrAcctNo;

    @Size(max = 36)
    @Column(name = "originial_acct_no", length = 36)
    public String originialAcctNo;

    @Column(name = "override_amt", precision = 21, scale = 2)
    public BigDecimal overrideAmt;

    @Size(max = 3)
    @Column(name = "override_amt_lcy", length = 3)
    public String overrideAmtLcy;

    @Size(max = 3)
    @Column(name = "override_currency", length = 3)
    public String overrideCurrency;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false, unique = true)
    public String payhubTxnRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "payment_product_code", length = 50, nullable = false)
    public String paymentProductCode;

    @NotNull
    @Size(max = 50)
    @Column(name = "processing_center_code", length = 50, nullable = false)
    public String processingCenterCode;

    @NotNull
    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = false)
    public String tenantId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionCharges)) {
            return false;
        }
        return id != null && id.equals(((TransactionCharges) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TransactionCharges{" +
            "id=" + id +
            ", acctNo='" + acctNo + "'" +
            ", acctNoBankBranchCd='" + acctNoBankBranchCd + "'" +
            ", acctType='" + acctType + "'" +
            ", accurateOverrideAmt=" + accurateOverrideAmt +
            ", agentCrAcctCurrency='" + agentCrAcctCurrency + "'" +
            ", agentCrAcctNo='" + agentCrAcctNo + "'" +
            ", agentCrAcctType='" + agentCrAcctType + "'" +
            ", agentCrAmt=" + agentCrAmt +
            ", agentCrBoardRate=" + agentCrBoardRate +
            ", agtCrAcctNoBankBranchCds='" + agtCrAcctNoBankBranchCds + "'" +
            ", boardRate=" + boardRate +
            ", chargeAmt=" + chargeAmt +
            ", chargeCurrency='" + chargeCurrency + "'" +
            ", chargeDesc='" + chargeDesc + "'" +
            ", chargeId='" + chargeId + "'" +
            ", chargeType='" + chargeType + "'" +
            ", contractRef='" + contractRef + "'" +
            ", countryCd='" + countryCd + "'" +
            ", crAcctEntrySequenceNo=" + crAcctEntrySequenceNo +
            ", deferredOverrideInd='" + deferredOverrideInd + "'" +
            ", displayRate=" + displayRate +
            ", drAcctEntrySequenceNo=" + drAcctEntrySequenceNo +
            ", exchangeType='" + exchangeType + "'" +
            ", glShortName='" + glShortName + "'" +
            ", isAdhocCharge='" + isAdhocCharge + "'" +
            ", isDeferred='" + isDeferred + "'" +
            ", isWaived='" + isWaived + "'" +
            ", originalAgentCrAcctNo='" + originalAgentCrAcctNo + "'" +
            ", originialAcctNo='" + originialAcctNo + "'" +
            ", overrideAmt=" + overrideAmt +
            ", overrideAmtLcy='" + overrideAmtLcy + "'" +
            ", overrideCurrency='" + overrideCurrency + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", paymentProductCode='" + paymentProductCode + "'" +
            ", processingCenterCode='" + processingCenterCode + "'" +
            ", tenantId='" + tenantId + "'" +
            "}";
    }

    public TransactionCharges update() {
        return update(this);
    }

    public TransactionCharges persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TransactionCharges update(TransactionCharges transactionCharges) {
        if (transactionCharges == null) {
            throw new IllegalArgumentException("transactionCharges can't be null");
        }
        var entity = TransactionCharges.<TransactionCharges>findById(transactionCharges.id);
        if (entity != null) {
            entity.acctNo = transactionCharges.acctNo;
            entity.acctNoBankBranchCd = transactionCharges.acctNoBankBranchCd;
            entity.acctType = transactionCharges.acctType;
            entity.accurateOverrideAmt = transactionCharges.accurateOverrideAmt;
            entity.agentCrAcctCurrency = transactionCharges.agentCrAcctCurrency;
            entity.agentCrAcctNo = transactionCharges.agentCrAcctNo;
            entity.agentCrAcctType = transactionCharges.agentCrAcctType;
            entity.agentCrAmt = transactionCharges.agentCrAmt;
            entity.agentCrBoardRate = transactionCharges.agentCrBoardRate;
            entity.agtCrAcctNoBankBranchCds = transactionCharges.agtCrAcctNoBankBranchCds;
            entity.boardRate = transactionCharges.boardRate;
            entity.chargeAmt = transactionCharges.chargeAmt;
            entity.chargeCurrency = transactionCharges.chargeCurrency;
            entity.chargeDesc = transactionCharges.chargeDesc;
            entity.chargeId = transactionCharges.chargeId;
            entity.chargeType = transactionCharges.chargeType;
            entity.contractRef = transactionCharges.contractRef;
            entity.countryCd = transactionCharges.countryCd;
            entity.crAcctEntrySequenceNo = transactionCharges.crAcctEntrySequenceNo;
            entity.deferredOverrideInd = transactionCharges.deferredOverrideInd;
            entity.displayRate = transactionCharges.displayRate;
            entity.drAcctEntrySequenceNo = transactionCharges.drAcctEntrySequenceNo;
            entity.exchangeType = transactionCharges.exchangeType;
            entity.glShortName = transactionCharges.glShortName;
            entity.isAdhocCharge = transactionCharges.isAdhocCharge;
            entity.isDeferred = transactionCharges.isDeferred;
            entity.isWaived = transactionCharges.isWaived;
            entity.originalAgentCrAcctNo = transactionCharges.originalAgentCrAcctNo;
            entity.originialAcctNo = transactionCharges.originialAcctNo;
            entity.overrideAmt = transactionCharges.overrideAmt;
            entity.overrideAmtLcy = transactionCharges.overrideAmtLcy;
            entity.overrideCurrency = transactionCharges.overrideCurrency;
            entity.payhubTxnRef = transactionCharges.payhubTxnRef;
            entity.paymentProductCode = transactionCharges.paymentProductCode;
            entity.processingCenterCode = transactionCharges.processingCenterCode;
            entity.tenantId = transactionCharges.tenantId;
        }
        return entity;
    }

    public static TransactionCharges persistOrUpdate(TransactionCharges transactionCharges) {
        if (transactionCharges == null) {
            throw new IllegalArgumentException("transactionCharges can't be null");
        }
        if (transactionCharges.id == null) {
            persist(transactionCharges);
            return transactionCharges;
        } else {
            return update(transactionCharges);
        }
    }


}
