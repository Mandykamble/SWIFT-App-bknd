package com.ncs.pay.config;
import io.smallrye.config.ConfigMapping;
import org.eclipse.microprofile.config.inject.ConfigProperties;

import javax.validation.constraints.NotBlank;

@ConfigMapping(prefix = "php")
public interface PhpProperties {
     String cashPoolAcc();

     String cashPoolAccNm();

     String vostroAcc();

     String instaPayAcc();
}