package com.ncs.pay.constants;

public class CamelEndpointConstants {
    //
    public static final String CAMEL_SERVLET_CONTEXT="CamelServletContext";
    //System Endpoints
    public static final String SYSTEM_ENDPOINT_DIRECT_GLOBAL_EVENT_LOGGER = "direct:global-event-logger";

    //Event and Message processing Endpoints
    public static final String DOMAIN_ENDPOINT_DIRECT_COMMON_INBOUND_PROCESSOR = "direct:common-inbound-queue"  ;

    public static final String DOMAIN_ENDPOINT_DIRECT_FI_MESSAGE_PERSISTER = "direct:common-fi-message-queue"  ;

    public static final String DOMAIN_ENDPOINT_DIRECT_COMMON_INBOUND_ROUTER = "direct:common-inbound-router"  ;
    public static final String DOMAIN_ENDPOINT_DIRECT_RETRY_ROUTER = "direct:common-retry-router"  ;
    public static final String DOMAIN_ENDPOINT_MAX_RETRIES_REACHED = "direct:common-max-retry-router"  ;
    public static final String DOMAIN_ENDPOINT_EVENT_PROCESSING_ERROR_HANDLER = "direct:event-processing-error" +
            "-handler"  ;

    //Txn Processing End points
    public static final String DOMAIN_ENDPOINT_TXN_PROCESSING_LOG_COLLECTOR = "direct:txn-processing-log-collector" ;



}
