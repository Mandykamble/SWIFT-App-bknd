package com.ncs.pay.config.myuc2;

import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "sgmaybank")
public interface SgMayBankProperties {
     String cashPoolAccMyr();
     String cashPoolAccSgd();
     String cashPoolAccUsd();
     String cashPoolAccPhp();
     String nostroAcc();


}