package com.ncs.pay.config;

import io.smallrye.config.ConfigMapping;
import org.eclipse.microprofile.config.inject.ConfigProperties;

import javax.validation.constraints.NotBlank;

@ConfigMapping(prefix = "myr")
public interface MyrProperties {
     String cashPoolAccMyr();
     String cashPoolAccPhp();

     String nostroAcc();
     String cashPoolAccUsd();
}