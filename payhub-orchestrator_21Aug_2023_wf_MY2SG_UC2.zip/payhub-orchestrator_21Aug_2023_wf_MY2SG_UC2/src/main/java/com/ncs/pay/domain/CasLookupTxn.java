package com.ncs.pay.domain;

import com.ncs.pay.constants.CasStageCode;
import com.ncs.pay.constants.TxnStatus;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.Calendar;

/**
 * @author Amila Karunathilaka
 */

@Entity
@Table(name = "instapay_lookup_txn")
@RegisterForReflection
@Data
@Audited
public class CasLookupTxn extends PanacheEntityBase  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false, precision = 0)
    protected Long id;
    @Column(name = "MSGID", length = 35)
    private String msgId;
    @Column(name = "PROXYTYPE", length = 12)
    private String proxyType;
    @Column(name = "PROXYVALUE", length = 140)
    private String proxyValue;
    @Column(name = "DISPLAYNAME", length = 140)
    private String displayName;
    @Column(name = "ACCOUNTNO", length = 34)
    private String accountNo;
    @Column(name = "ACCOUNTNAME", length = 140)
    private String accountName;
    @Column(name = "BICFISENDER", length = 11)
    private String bicfiSender;
    @Column(name = "BICFIREQ", length = 11)
    private String bicfiReq;
    @Column(name = "STAGEID", length = 10)
    private CasStageCode stageCode;
    @Column(name = "PREAUTHRSD", length = 5)
    private String preAuthrsd;
    @Column(name = "PRTRY", length = 4)
    private String party;
    @Enumerated(value = EnumType.STRING)
    @Column(name = "REGSTATUS", length = 4)
    private TxnStatus txnStatus;
    @Column(name = "STATUSCD", length = 4)
    private String statusCd;
    @Column(name = "PRXYONLYID", unique = true, nullable = false, length = 35)
    private String proxyOnlyId;
    @Column(name = "PROXYREQTY", length = 12)
    private String proxyReqTy;
    @Column(name = "PROXYREQVALUE", length = 140)
    private String proxyReqValue;
    @Column(name = "REGNID", length = 35)
    private String regnId;
    @Column(name = "LOOKUPREF", length = 35)
    private String lookupRef;

    private String country;

    private String tenant;

    @Column(name = "CREATEDT", nullable = false)
    private ZonedDateTime createdDt;
    @Column(name = "CREATEBY", nullable = false)
    private String createdBy;
    @Column(name = "UPDATEDT", nullable = false)
    private ZonedDateTime lastUpdatedDt;
    @Column(name = "UPDATEBY", nullable = false)
    private String lastUpdatedBy;

    public CasLookupTxn update() {
        return update(this);
    }

    public CasLookupTxn persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static CasLookupTxn update(CasLookupTxn casLookupTxn) {
        if (casLookupTxn == null) {
            throw new IllegalArgumentException("casLookupTxn can't be null");
        }
        var entity = CasLookupTxn.<CasLookupTxn>findById(casLookupTxn.id);
        if (entity != null) {
            entity.msgId = casLookupTxn.msgId;
            entity.proxyType = casLookupTxn.proxyType;
            entity.proxyValue = casLookupTxn.proxyValue;
            entity.displayName = casLookupTxn.displayName;
            entity.accountNo = casLookupTxn.accountNo;
            entity.accountName = casLookupTxn.accountName;
            entity.bicfiSender = casLookupTxn.bicfiSender;
            entity.bicfiReq = casLookupTxn.bicfiReq;
            entity.stageCode = casLookupTxn.stageCode;
            entity.preAuthrsd = casLookupTxn.preAuthrsd;
            entity.party = casLookupTxn.party;
            entity.txnStatus = casLookupTxn.txnStatus;
            entity.statusCd = casLookupTxn.statusCd;
            entity.proxyOnlyId = casLookupTxn.proxyOnlyId;
            entity.proxyReqTy = casLookupTxn.proxyReqTy;
            entity.proxyReqValue = casLookupTxn.proxyReqValue;
            entity.regnId = casLookupTxn.regnId;
            entity.lookupRef = casLookupTxn.lookupRef;
            entity.country = casLookupTxn.country;
            entity.tenant = casLookupTxn.tenant;

        }
        return entity;
    }

    public static CasLookupTxn persistOrUpdate(CasLookupTxn casLookupTxn) {
        if (casLookupTxn == null) {
            throw new IllegalArgumentException("casLookupTxn can't be null");
        }
        if (casLookupTxn.id == null) {
            persist(casLookupTxn);
            return casLookupTxn;
        } else {
            return update(casLookupTxn);
        }
    }

    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(ZonedDateTime.now());
        }
        this.setLastUpdatedDt(ZonedDateTime.now());
    }

}
