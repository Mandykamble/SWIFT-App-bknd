package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;
import org.hibernate.envers.Audited;

import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import static org.hibernate.envers.RelationTargetAuditMode.NOT_AUDITED;

/**
 * A PayhubTxnMaster.
 */
@Entity
@Table(name = "payhub_txn_master")
@RegisterForReflection
@Data
@Audited
public class PayhubTxnMaster extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 100)
    @Column(name = "event_id", length = 100, nullable = false)
    public String eventId;

    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, unique = true)
    public String payhubTxnRef;

    @Size(max = 4)
    @Column(name = "appl_branch_cd", length = 4)
    public String applBranchCd;

    @Size(max = 50)
    @Column(name = "approving_officer_id", length = 50)
    public String approvingOfficerId;

    @Size(max = 40)
    @Column(name = "assign_to", length = 40)
    public String assignTo;

    @Column(name = "auth_1_dt")
    public Instant auth1Dt;

    @Size(max = 35)
    @Column(name = "auth_1_rework", length = 35)
    public String auth1Rework;

    @Column(name = "auth_2_dt")
    public Instant auth2Dt;

    @Size(max = 35)
    @Column(name = "auth_2_rework", length = 35)
    public String auth2Rework;

    @Size(max = 1)
    @Column(name = "auth_ind", length = 1)
    public String authInd;

    @Size(max = 1)
    @Column(name = "auth_level", length = 1)
    public String authLevel;

    @Size(max = 1)
    @Column(name = "available_funds_override_ind", length = 1)
    public String availableFundsOverrideInd;

    @Size(max = 10)
    @Column(name = "base_message_type", length = 10)
    public String baseMessageType;

    @Size(max = 1)
    @Column(name = "bckward_forward_ind", length = 1)
    public String bckwardForwardInd;

    @Size(max = 1)
    @Column(name = "board_rate_failed", length = 1)
    public String boardRateFailed;

    @Size(max = 1)
    @Column(name = "check_103", length = 1)
    public String check103;

    @Size(max = 1)
    @Column(name = "check_202", length = 1)
    public String check202;

    @Size(max = 36)
    @Column(name = "cin", length = 36)
    public String cin;

    @Size(max = 3)
    @Column(name = "cin_suffix", length = 3)
    public String cinSuffix;

    @Size(max = 40)
    @Column(name = "claimed_by", length = 40)
    public String claimedBy;

    @Size(max = 1)
    @Column(name = "clarification_status", length = 1)
    public String clarificationStatus;

    @Size(max = 1)
    @Column(name = "comment_ind", length = 1)
    public String commentInd;

    @Size(max = 1)
    @Column(name = "confirm_sr_done_ind", length = 1)
    public String confirmSrDoneInd;

    @Size(max = 2)
    @Column(name = "confirmcharge_ind", length = 2)
    public String confirmchargeInd;

    @Size(max = 3)
    @Column(name = "convert_to_product", length = 3)
    public String convertToProduct;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Size(max = 1)
    @Column(name = "cover_found_ind", length = 1)
    public String coverFoundInd;

    @Size(max = 50)
    @Column(name = "credit_acct", length = 50)
    public String creditAcct;

    @Size(max = 100)
    @Column(name = "credit_acct_nm", length = 100)
    public String creditAcctNm;

    @Size(max = 36)
    @Column(name = "credit_acct_bank_branch_cds", length = 36)
    public String creditAcctBankBranchCds;

    @Size(max = 3)
    @Column(name = "credit_acct_currency_cd", length = 3)
    public String creditAcctCurrencyCd;

    @Size(max = 1)
    @Column(name = "credit_nostro_reporting_ind", length = 1)
    public String creditNostroReportingInd;

    @Size(max = 10)
    @Column(name = "credit_to_tag", length = 10)
    public String creditToTag;

    @Column(name = "credit_value_dt")
    public LocalDate creditValueDt;

    @Column(name = "critical_check_dt")
    public Instant criticalCheckDt;

    @Size(max = 50)
    @Column(name = "customer_ref", length = 50)
    public String customerRef;

    @Size(max = 50)
    @Column(name = "debit_acct", length = 50)
    public String debitAcct;


    @Size(max = 100)
    @Column(name = "debit_acct_nm", length = 100)
    public String debtrAcctNm;


    @Size(max = 50)
    @Column(name = "debit_acct_1", length = 50)
    public String debitAcct1;

    @Size(max = 36)
    @Column(name = "debit_acct_bank_branch_cds", length = 36)
    public String debitAcctBankBranchCds;

    @Size(max = 36)
    @Column(name = "debit_acct_bank_branch_cds_1", length = 36)
    public String debitAcctBankBranchCds1;

    @Size(max = 4)
    @Column(name = "debit_acct_bank_id", length = 4)
    public String debitAcctBankId;

    @Size(max = 4)
    @Column(name = "debit_acct_bank_id_1", length = 4)
    public String debitAcctBankId1;

    @Size(max = 4)
    @Column(name = "debit_acct_branch_id", length = 4)
    public String debitAcctBranchId;

    @Size(max = 4)
    @Column(name = "debit_acct_branch_id_1", length = 4)
    public String debitAcctBranchId1;

    @Size(max = 3)
    @Column(name = "debit_acct_currency_cd", length = 3)
    public String debitAcctCurrencyCd;

    @Size(max = 3)
    @Column(name = "debit_acct_currency_cd_1", length = 3)
    public String debitAcctCurrencyCd1;

    @Size(max = 8)
    @Column(name = "debit_acct_prod_type", length = 8)
    public String debitAcctProdType;

    @Size(max = 8)
    @Column(name = "debit_acct_prod_type_1", length = 8)
    public String debitAcctProdType1;

    @Size(max = 10)
    @Column(name = "debit_from_tag", length = 10)
    public String debitFromTag;

    @Size(max = 1)
    @Column(name = "debit_nostro_reporting_ind", length = 1)
    public String debitNostroReportingInd;

    @Column(name = "debit_value_dt")
    public LocalDate debitValueDt;

    @Size(max = 3)
    @Column(name = "derived_charging_party", length = 3)
    public String derivedChargingParty;

    @Size(max = 40)
    @Column(name = "discard_id", length = 40)
    public String discardId;

    @Size(max = 3)
    @Column(name = "discard_prior_status_cd", length = 3)
    public String discardPriorStatusCd;

    @Size(max = 400)
    @Column(name = "discard_rsn", length = 400)
    public String discardRsn;

    @Size(max = 1)
    @Column(name = "force_release_forward_ind", length = 1)
    public String forceReleaseForwardInd;

    @Size(max = 1)
    @Column(name = "fraud_check_ind", length = 1)
    public String fraudCheckInd;

    @Size(max = 1)
    @Column(name = "fs_validation_done_ind", length = 1)
    public String fsValidationDoneInd;

    @Size(max = 1)
    @Column(name = "had_pend_saa", length = 1)
    public String hadPendSaa;

    @Size(max = 3)
    @Column(name = "handoff_stage_cd", length = 3)
    public String handoffStageCd;

    @Size(max = 50)
    @Column(name = "interface_ref_no", length = 50)
    public String interfaceRefNo;

    @Size(max = 140)
    @Column(name = "intermediary_acct_m", length = 140)
    public String intermediaryAcctM;

    @Size(max = 1)
    @Column(name = "intra_booktransfer_ind", length = 1)
    public String intraBooktransferInd;

    @Size(max = 1)
    @Column(name = "kiv_status", length = 1)
    public String kivStatus;

    @Size(max = 1)
    @Column(name = "manual_override_ind", length = 1)
    public String manualOverrideInd;

    @Column(name = "mca_fs_attempt_cnt", precision = 21, scale = 2)
    public BigDecimal mcaFsAttemptCnt;

    @Size(max = 2)
    @Column(name = "msg_construction_status_cd", length = 2)
    public String msgConstructionStatusCd;

    @Size(max = 50)
    @Column(name = "msg_ref_no", length = 50)
    public String msgRefNo;

    @Size(max = 1)
    @Column(name = "nostro_reporting_done_ind", length = 1)
    public String nostroReportingDoneInd;

    @Column(name = "nostro_reporting_dt")
    public LocalDate nostroReportingDt;

    @Column(name = "nostro_value_dt")
    public LocalDate nostroValueDt;

    @Size(max = 1)
    @Column(name = "odd_currency_ind", length = 1)
    public String oddCurrencyInd;

    @Size(max = 3)
    @Column(name = "outgoing_charging_party", length = 3)
    public String outgoingChargingParty;

    @Size(max = 20)
    @Column(name = "outgoing_msg_format", length = 20)
    public String outgoingMsgFormat;

    @Size(max = 12)
    @Column(name = "outgoing_msg_rcpt_bnk_cd", length = 12)
    public String outgoingMsgRcptBnkCd;

    @Size(max = 8)
    @Column(name = "outgoing_msg_rcpt_brn_cd", length = 8)
    public String outgoingMsgRcptBrnCd;

    @Size(max = 1)
    @Column(name = "outgoing_msg_required_ind", length = 1)
    public String outgoingMsgRequiredInd;

    @Size(max = 1)
    @Column(name = "outgoing_msg_suppress_ind", length = 1)
    public String outgoingMsgSuppressInd;

    @Size(max = 10)
    @Column(name = "outgoing_msg_type", length = 10)
    public String outgoingMsgType;

    @Size(max = 1)
    @Column(name = "override_acct_signal_ind", length = 1)
    public String overrideAcctSignalInd;

    @Size(max = 1)
    @Column(name = "override_type", length = 1)
    public String overrideType;

    @Column(name = "page_no", precision = 21, scale = 2)
    public BigDecimal pageNo;

    @Column(name = "pay_out_dt")
    public LocalDate payOutDt;

    @Size(max = 10)
    @Column(name = "paymnt_time", length = 10)
    public String paymntTime;

    @Column(name = "posting_status_cd", precision = 21, scale = 2)
    public BigDecimal postingStatusCd;

    @Size(max = 1)
    @Column(name = "preadvice_ind", length = 1)
    public String preadviceInd;

    @Size(max = 1)
    @Column(name = "prio_chg_by_sup_ind", length = 1)
    public String prioChgBySupInd;

    @Column(name = "priority", precision = 21, scale = 2)
    public BigDecimal priority;

    @Size(max = 4)
    @Column(name = "processing_branch_cd", length = 4)
    public String processingBranchCd;

    @Column(name = "processing_dt")
    public LocalDate processingDt;

    @Size(max = 4)
    @Column(name = "processing_section", length = 4)
    public String processingSection;

    @Size(max = 30)
    @Column(name = "product_cd", length = 30)
    public String productCd;

    @Size(max = 10)
    @Column(name = "q_category", length = 10)
    public String qCategory;

    @Size(max = 11)
    @Column(name = "receive_bank_cd", length = 11)
    public String receiveBankCd;

    @Column(name = "received_amt", precision = 21, scale = 2)
    public BigDecimal receivedAmt;

    @Size(max = 1)
    @Column(name = "received_amt_type_ind", length = 1)
    public String receivedAmtTypeInd;

    @Size(max = 1)
    @Column(name = "released_from_warehouse_ind", length = 1)
    public String releasedFromWarehouseInd;

    @Column(name = "rem_amt", precision = 21, scale = 2)
    public BigDecimal remAmt;

    @Column(name = "rem_amt_lcy", precision = 21, scale = 2)
    public BigDecimal remAmtLcy;

    @Size(max = 3)
    @Column(name = "rem_amt_lcy_currency_cd", length = 3)
    public String remAmtLcyCurrencyCd;

    @Size(max = 11)
    @Column(name = "remit_bank_cd", length = 11)
    public String remitBankCd;

    @Column(name = "remit_currency_value_dt_offset", precision = 21, scale = 2)
    public BigDecimal remitCurrencyValueDtOffset;

    @Size(max = 1)
    @Column(name = "repair_ind", length = 1)
    public String repairInd;

    @Column(name = "retry_cnt", precision = 21, scale = 2)
    public BigDecimal retryCnt;

    @Column(name = "retry_count", precision = 21, scale = 2)
    public BigDecimal retryCount;

    @Size(max = 1)
    @Column(name = "same_debit_credit_acct_ind", length = 1)
    public String sameDebitCreditAcctInd;

    @Column(name = "settlm_amt", precision = 21, scale = 2)
    public BigDecimal settlmAmt;

    @Column(name = "settlm_amt_lcy", precision = 21, scale = 2)
    public BigDecimal settlmAmtLcy;

    @Size(max = 3)
    @Column(name = "settlm_amt_lcy_currency_cd", length = 3)
    public String settlmAmtLcyCurrencyCd;

    @Size(max = 3)
    @Column(name = "settlm_currency_cd", length = 3)
    public String settlmCurrencyCd;

    @Column(name = "settlm_dt")
    public LocalDate settlmDt;

    @NotNull
    @Size(max = 20)
    @Column(name = "source_id", length =20, nullable = false)
    public String sourceId;

    @Size(max = 10)
    @Column(name = "stage_cd", length = 10)
    public String stageCd;

    @Size(max = 3)
    @Column(name = "status_cd", length = 3)
    public String statusCd;

    @Size(max = 10)
    @Column(name = "stp_status_cd", length = 10)
    public String stpStatusCd;

    @Size(max = 15)
    @Column(name = "team", length = 15)
    public String team;

    @Size(max = 1)
    @Column(name = "third_party_mandate_involved", length = 1)
    public String thirdPartyMandateInvolved;

    @Size(max = 50)
    @Column(name = "trans_ref_old", length = 50)
    public String transRefOld;

    @Column(name = "transaction_cd", precision = 21, scale = 2)
    public BigDecimal transactionCd;

    @Size(max = 1)
    @Column(name = "warehouse_status_cd", length = 1)
    public String warehouseStatusCd;


    @Size(max = 400)
    @Column(name = "remarks", length = 400)
    public String remarks;

    @NotNull
    @Column(name = "msg_info_id", nullable = false)
    public Long messageInfoId;

    @Size(max = 16)
    @Column(name = "purp_cd", length = 16)
    public String purpCd;


    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PayhubTxnMaster)) {
            return false;
        }
        return id != null && id.equals(((PayhubTxnMaster) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "PayhubTxnMaster{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", eventId='" + eventId + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", applBranchCd='" + applBranchCd + "'" +
            ", approvingOfficerId='" + approvingOfficerId + "'" +
            ", assignTo='" + assignTo + "'" +
            ", auth1Dt='" + auth1Dt + "'" +
            ", auth1Rework='" + auth1Rework + "'" +
            ", auth2Dt='" + auth2Dt + "'" +
            ", auth2Rework='" + auth2Rework + "'" +
            ", authInd='" + authInd + "'" +
            ", authLevel='" + authLevel + "'" +
            ", availableFundsOverrideInd='" + availableFundsOverrideInd + "'" +
            ", baseMessageType='" + baseMessageType + "'" +
            ", bckwardForwardInd='" + bckwardForwardInd + "'" +
            ", boardRateFailed='" + boardRateFailed + "'" +
            ", check103='" + check103 + "'" +
            ", check202='" + check202 + "'" +
            ", cin='" + cin + "'" +
            ", cinSuffix='" + cinSuffix + "'" +
            ", claimedBy='" + claimedBy + "'" +
            ", clarificationStatus='" + clarificationStatus + "'" +
            ", commentInd='" + commentInd + "'" +
            ", confirmSrDoneInd='" + confirmSrDoneInd + "'" +
            ", confirmchargeInd='" + confirmchargeInd + "'" +
            ", convertToProduct='" + convertToProduct + "'" +
            ", countryCd='" + countryCd + "'" +
            ", coverFoundInd='" + coverFoundInd + "'" +
            ", creditAcct='" + creditAcct + "'" +
            ", creditAcctBankBranchCds='" + creditAcctBankBranchCds + "'" +
            ", creditAcctCurrencyCd='" + creditAcctCurrencyCd + "'" +
            ", creditNostroReportingInd='" + creditNostroReportingInd + "'" +
            ", creditToTag='" + creditToTag + "'" +
            ", creditValueDt='" + creditValueDt + "'" +
            ", criticalCheckDt='" + criticalCheckDt + "'" +
            ", customerRef='" + customerRef + "'" +
            ", debitAcct='" + debitAcct + "'" +
            ", debtrAcctNm='" + debtrAcctNm + "'" +
            ", debitAcct1='" + debitAcct1 + "'" +
            ", debitAcctBankBranchCds='" + debitAcctBankBranchCds + "'" +
            ", debitAcctBankBranchCds1='" + debitAcctBankBranchCds1 + "'" +
            ", debitAcctBankId='" + debitAcctBankId + "'" +
            ", debitAcctBankId1='" + debitAcctBankId1 + "'" +
            ", debitAcctBranchId='" + debitAcctBranchId + "'" +
            ", debitAcctBranchId1='" + debitAcctBranchId1 + "'" +
            ", debitAcctCurrencyCd='" + debitAcctCurrencyCd + "'" +
            ", debitAcctCurrencyCd1='" + debitAcctCurrencyCd1 + "'" +
            ", debitAcctProdType='" + debitAcctProdType + "'" +
            ", debitAcctProdType1='" + debitAcctProdType1 + "'" +
            ", debitFromTag='" + debitFromTag + "'" +
            ", debitNostroReportingInd='" + debitNostroReportingInd + "'" +
            ", debitValueDt='" + debitValueDt + "'" +
            ", derivedChargingParty='" + derivedChargingParty + "'" +
            ", discardId='" + discardId + "'" +
            ", discardPriorStatusCd='" + discardPriorStatusCd + "'" +
            ", discardRsn='" + discardRsn + "'" +
            ", forceReleaseForwardInd='" + forceReleaseForwardInd + "'" +
            ", fraudCheckInd='" + fraudCheckInd + "'" +
            ", fsValidationDoneInd='" + fsValidationDoneInd + "'" +
            ", hadPendSaa='" + hadPendSaa + "'" +
            ", handoffStageCd='" + handoffStageCd + "'" +
            ", interfaceRefNo='" + interfaceRefNo + "'" +
            ", intermediaryAcctM='" + intermediaryAcctM + "'" +
            ", intraBooktransferInd='" + intraBooktransferInd + "'" +
            ", kivStatus='" + kivStatus + "'" +
            ", manualOverrideInd='" + manualOverrideInd + "'" +
            ", mcaFsAttemptCnt=" + mcaFsAttemptCnt +
            ", msgConstructionStatusCd='" + msgConstructionStatusCd + "'" +
            ", msgRefNo='" + msgRefNo + "'" +
            ", nostroReportingDoneInd='" + nostroReportingDoneInd + "'" +
            ", nostroReportingDt='" + nostroReportingDt + "'" +
            ", nostroValueDt='" + nostroValueDt + "'" +
            ", oddCurrencyInd='" + oddCurrencyInd + "'" +
            ", outgoingChargingParty='" + outgoingChargingParty + "'" +
            ", outgoingMsgFormat='" + outgoingMsgFormat + "'" +
            ", outgoingMsgRcptBnkCd='" + outgoingMsgRcptBnkCd + "'" +
            ", outgoingMsgRcptBrnCd='" + outgoingMsgRcptBrnCd + "'" +
            ", outgoingMsgRequiredInd='" + outgoingMsgRequiredInd + "'" +
            ", outgoingMsgSuppressInd='" + outgoingMsgSuppressInd + "'" +
            ", outgoingMsgType='" + outgoingMsgType + "'" +
            ", overrideAcctSignalInd='" + overrideAcctSignalInd + "'" +
            ", overrideType='" + overrideType + "'" +
            ", pageNo=" + pageNo +
            ", payOutDt='" + payOutDt + "'" +
            ", paymntTime='" + paymntTime + "'" +
            ", postingStatusCd=" + postingStatusCd +
            ", preadviceInd='" + preadviceInd + "'" +
            ", prioChgBySupInd='" + prioChgBySupInd + "'" +
            ", priority=" + priority +
            ", processingBranchCd='" + processingBranchCd + "'" +
            ", processingDt='" + processingDt + "'" +
            ", processingSection='" + processingSection + "'" +
            ", productCd='" + productCd + "'" +
            ", qCategory='" + qCategory + "'" +
            ", receiveBankCd='" + receiveBankCd + "'" +
            ", receivedAmt=" + receivedAmt +
            ", receivedAmtTypeInd='" + receivedAmtTypeInd + "'" +
            ", releasedFromWarehouseInd='" + releasedFromWarehouseInd + "'" +
            ", remAmt=" + remAmt +
            ", remAmtLcy=" + remAmtLcy +
            ", remAmtLcyCurrencyCd='" + remAmtLcyCurrencyCd + "'" +
            ", remitBankCd='" + remitBankCd + "'" +
            ", remitCurrencyValueDtOffset=" + remitCurrencyValueDtOffset +
            ", repairInd='" + repairInd + "'" +
            ", retryCnt=" + retryCnt +
            ", retryCount=" + retryCount +
            ", sameDebitCreditAcctInd='" + sameDebitCreditAcctInd + "'" +
            ", settlmAmt=" + settlmAmt +
            ", settlmAmtLcy=" + settlmAmtLcy +
            ", settlmAmtLcyCurrencyCd='" + settlmAmtLcyCurrencyCd + "'" +
            ", settlmCurrencyCd='" + settlmCurrencyCd + "'" +
            ", settlmDt='" + settlmDt + "'" +
            ", sourceId='" + sourceId + "'" +
            ", stageCd='" + stageCd + "'" +
            ", statusCd='" + statusCd + "'" +
            ", stpStatusCd='" + stpStatusCd + "'" +
            ", team='" + team + "'" +
            ", thirdPartyMandateInvolved='" + thirdPartyMandateInvolved + "'" +
            ", transRefOld='" + transRefOld + "'" +
            ", transactionCd=" + transactionCd +
            ", warehouseStatusCd='" + warehouseStatusCd + "'" +
            ", remarks='" + remarks + "'" +
            "}";
    }

    public PayhubTxnMaster update() {
        return update(this);
    }

    public PayhubTxnMaster persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static PayhubTxnMaster update(PayhubTxnMaster payhubTxnMaster) {
        if (payhubTxnMaster == null) {
            throw new IllegalArgumentException("payhubTxnMaster can't be null");
        }
        var entity = PayhubTxnMaster.<PayhubTxnMaster>findById(payhubTxnMaster.id);
        if (entity != null) {
            entity.recordId = payhubTxnMaster.recordId;
            entity.createdBy = payhubTxnMaster.createdBy;
            entity.createdDt = payhubTxnMaster.createdDt;
            entity.lastUpdatedBy = payhubTxnMaster.lastUpdatedBy;
            entity.lastUpdatedDt = payhubTxnMaster.lastUpdatedDt;
            entity.lockFlag = payhubTxnMaster.lockFlag;
            entity.eventId = payhubTxnMaster.eventId;
            entity.payhubTxnRef = payhubTxnMaster.payhubTxnRef;
            entity.applBranchCd = payhubTxnMaster.applBranchCd;
            entity.approvingOfficerId = payhubTxnMaster.approvingOfficerId;
            entity.assignTo = payhubTxnMaster.assignTo;
            entity.auth1Dt = payhubTxnMaster.auth1Dt;
            entity.auth1Rework = payhubTxnMaster.auth1Rework;
            entity.auth2Dt = payhubTxnMaster.auth2Dt;
            entity.auth2Rework = payhubTxnMaster.auth2Rework;
            entity.authInd = payhubTxnMaster.authInd;
            entity.authLevel = payhubTxnMaster.authLevel;
            entity.availableFundsOverrideInd = payhubTxnMaster.availableFundsOverrideInd;
            entity.baseMessageType = payhubTxnMaster.baseMessageType;
            entity.bckwardForwardInd = payhubTxnMaster.bckwardForwardInd;
            entity.boardRateFailed = payhubTxnMaster.boardRateFailed;
            entity.check103 = payhubTxnMaster.check103;
            entity.check202 = payhubTxnMaster.check202;
            entity.cin = payhubTxnMaster.cin;
            entity.cinSuffix = payhubTxnMaster.cinSuffix;
            entity.claimedBy = payhubTxnMaster.claimedBy;
            entity.clarificationStatus = payhubTxnMaster.clarificationStatus;
            entity.commentInd = payhubTxnMaster.commentInd;
            entity.confirmSrDoneInd = payhubTxnMaster.confirmSrDoneInd;
            entity.confirmchargeInd = payhubTxnMaster.confirmchargeInd;
            entity.convertToProduct = payhubTxnMaster.convertToProduct;
            entity.countryCd = payhubTxnMaster.countryCd;
            entity.coverFoundInd = payhubTxnMaster.coverFoundInd;
            entity.creditAcct = payhubTxnMaster.creditAcct;
            entity.creditAcctBankBranchCds = payhubTxnMaster.creditAcctBankBranchCds;
            entity.creditAcctCurrencyCd = payhubTxnMaster.creditAcctCurrencyCd;
            entity.creditNostroReportingInd = payhubTxnMaster.creditNostroReportingInd;
            entity.creditToTag = payhubTxnMaster.creditToTag;
            entity.creditValueDt = payhubTxnMaster.creditValueDt;
            entity.criticalCheckDt = payhubTxnMaster.criticalCheckDt;
            entity.customerRef = payhubTxnMaster.customerRef;
            entity.debitAcct = payhubTxnMaster.debitAcct;
            entity.debtrAcctNm = payhubTxnMaster.debtrAcctNm;
            entity.debitAcct1 = payhubTxnMaster.debitAcct1;
            entity.debitAcctBankBranchCds = payhubTxnMaster.debitAcctBankBranchCds;
            entity.debitAcctBankBranchCds1 = payhubTxnMaster.debitAcctBankBranchCds1;
            entity.debitAcctBankId = payhubTxnMaster.debitAcctBankId;
            entity.debitAcctBankId1 = payhubTxnMaster.debitAcctBankId1;
            entity.debitAcctBranchId = payhubTxnMaster.debitAcctBranchId;
            entity.debitAcctBranchId1 = payhubTxnMaster.debitAcctBranchId1;
            entity.debitAcctCurrencyCd = payhubTxnMaster.debitAcctCurrencyCd;
            entity.debitAcctCurrencyCd1 = payhubTxnMaster.debitAcctCurrencyCd1;
            entity.debitAcctProdType = payhubTxnMaster.debitAcctProdType;
            entity.debitAcctProdType1 = payhubTxnMaster.debitAcctProdType1;
            entity.debitFromTag = payhubTxnMaster.debitFromTag;
            entity.debitNostroReportingInd = payhubTxnMaster.debitNostroReportingInd;
            entity.debitValueDt = payhubTxnMaster.debitValueDt;
            entity.derivedChargingParty = payhubTxnMaster.derivedChargingParty;
            entity.discardId = payhubTxnMaster.discardId;
            entity.discardPriorStatusCd = payhubTxnMaster.discardPriorStatusCd;
            entity.discardRsn = payhubTxnMaster.discardRsn;
            entity.forceReleaseForwardInd = payhubTxnMaster.forceReleaseForwardInd;
            entity.fraudCheckInd = payhubTxnMaster.fraudCheckInd;
            entity.fsValidationDoneInd = payhubTxnMaster.fsValidationDoneInd;
            entity.hadPendSaa = payhubTxnMaster.hadPendSaa;
            entity.handoffStageCd = payhubTxnMaster.handoffStageCd;
            entity.interfaceRefNo = payhubTxnMaster.interfaceRefNo;
            entity.intermediaryAcctM = payhubTxnMaster.intermediaryAcctM;
            entity.intraBooktransferInd = payhubTxnMaster.intraBooktransferInd;
            entity.kivStatus = payhubTxnMaster.kivStatus;
            entity.manualOverrideInd = payhubTxnMaster.manualOverrideInd;
            entity.mcaFsAttemptCnt = payhubTxnMaster.mcaFsAttemptCnt;
            entity.msgConstructionStatusCd = payhubTxnMaster.msgConstructionStatusCd;
            entity.msgRefNo = payhubTxnMaster.msgRefNo;
            entity.nostroReportingDoneInd = payhubTxnMaster.nostroReportingDoneInd;
            entity.nostroReportingDt = payhubTxnMaster.nostroReportingDt;
            entity.nostroValueDt = payhubTxnMaster.nostroValueDt;
            entity.oddCurrencyInd = payhubTxnMaster.oddCurrencyInd;
            entity.outgoingChargingParty = payhubTxnMaster.outgoingChargingParty;
            entity.outgoingMsgFormat = payhubTxnMaster.outgoingMsgFormat;
            entity.outgoingMsgRcptBnkCd = payhubTxnMaster.outgoingMsgRcptBnkCd;
            entity.outgoingMsgRcptBrnCd = payhubTxnMaster.outgoingMsgRcptBrnCd;
            entity.outgoingMsgRequiredInd = payhubTxnMaster.outgoingMsgRequiredInd;
            entity.outgoingMsgSuppressInd = payhubTxnMaster.outgoingMsgSuppressInd;
            entity.outgoingMsgType = payhubTxnMaster.outgoingMsgType;
            entity.overrideAcctSignalInd = payhubTxnMaster.overrideAcctSignalInd;
            entity.overrideType = payhubTxnMaster.overrideType;
            entity.pageNo = payhubTxnMaster.pageNo;
            entity.payOutDt = payhubTxnMaster.payOutDt;
            entity.paymntTime = payhubTxnMaster.paymntTime;
            entity.postingStatusCd = payhubTxnMaster.postingStatusCd;
            entity.preadviceInd = payhubTxnMaster.preadviceInd;
            entity.prioChgBySupInd = payhubTxnMaster.prioChgBySupInd;
            entity.priority = payhubTxnMaster.priority;
            entity.processingBranchCd = payhubTxnMaster.processingBranchCd;
            entity.processingDt = payhubTxnMaster.processingDt;
            entity.processingSection = payhubTxnMaster.processingSection;
            entity.productCd = payhubTxnMaster.productCd;
            entity.qCategory = payhubTxnMaster.qCategory;
            entity.receiveBankCd = payhubTxnMaster.receiveBankCd;
            entity.receivedAmt = payhubTxnMaster.receivedAmt;
            entity.receivedAmtTypeInd = payhubTxnMaster.receivedAmtTypeInd;
            entity.releasedFromWarehouseInd = payhubTxnMaster.releasedFromWarehouseInd;
            entity.remAmt = payhubTxnMaster.remAmt;
            entity.remAmtLcy = payhubTxnMaster.remAmtLcy;
            entity.remAmtLcyCurrencyCd = payhubTxnMaster.remAmtLcyCurrencyCd;
            entity.remitBankCd = payhubTxnMaster.remitBankCd;
            entity.remitCurrencyValueDtOffset = payhubTxnMaster.remitCurrencyValueDtOffset;
            entity.repairInd = payhubTxnMaster.repairInd;
            entity.retryCnt = payhubTxnMaster.retryCnt;
            entity.retryCount = payhubTxnMaster.retryCount;
            entity.sameDebitCreditAcctInd = payhubTxnMaster.sameDebitCreditAcctInd;
            entity.settlmAmt = payhubTxnMaster.settlmAmt;
            entity.settlmAmtLcy = payhubTxnMaster.settlmAmtLcy;
            entity.settlmAmtLcyCurrencyCd = payhubTxnMaster.settlmAmtLcyCurrencyCd;
            entity.settlmCurrencyCd = payhubTxnMaster.settlmCurrencyCd;
            entity.settlmDt = payhubTxnMaster.settlmDt;
            entity.sourceId = payhubTxnMaster.sourceId;
            entity.stageCd = payhubTxnMaster.stageCd;
            entity.statusCd = payhubTxnMaster.statusCd;
            entity.stpStatusCd = payhubTxnMaster.stpStatusCd;
            entity.team = payhubTxnMaster.team;
            entity.thirdPartyMandateInvolved = payhubTxnMaster.thirdPartyMandateInvolved;
            entity.transRefOld = payhubTxnMaster.transRefOld;
            entity.transactionCd = payhubTxnMaster.transactionCd;
            entity.warehouseStatusCd = payhubTxnMaster.warehouseStatusCd;
            entity.remarks = payhubTxnMaster.remarks;
            entity.messageInfoId = payhubTxnMaster.messageInfoId;
            entity.creditAcctNm = payhubTxnMaster.creditAcctNm;
            entity.purpCd = payhubTxnMaster.purpCd;
        }
        return entity;
    }

    public static PayhubTxnMaster persistOrUpdate(PayhubTxnMaster payhubTxnMaster) {
        if (payhubTxnMaster == null) {
            throw new IllegalArgumentException("payhubTxnMaster can't be null");
        }
        if (payhubTxnMaster.id == null) {
            persist(payhubTxnMaster);
            return payhubTxnMaster;
        } else {
            return update(payhubTxnMaster);
        }
    }

    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        // Set the timezone to SGT
        TimeZone timeZone = TimeZone.getTimeZone("Asia/Singapore");

        // Obtain a Calendar instance using the specified timezone
        Calendar calendar = Calendar.getInstance(timeZone);

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

        this.setRecordId(0L);
    }


    public static PayhubTxnMaster getRecordByPayhubTxnRef(String payhubTxnRef) {
        return find("payhubTxnRef", payhubTxnRef).firstResult();
    }

    public static List<PayhubTxnMaster> getRecordByInterfaceRefNo(String interfaceRefNo) {
       return find("interfaceRefNo", interfaceRefNo).list();

    }


}
