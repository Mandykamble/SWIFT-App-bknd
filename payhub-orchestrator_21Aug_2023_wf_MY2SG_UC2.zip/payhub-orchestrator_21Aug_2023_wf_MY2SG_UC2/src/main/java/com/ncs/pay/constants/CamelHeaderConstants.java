package com.ncs.pay.constants;


public class CamelHeaderConstants {

    // Event Processing Headers
    public static final String HEADER_EVENT_ID="EventId";
    public static final String HEADER_EVENT_LOG_MESSAGE="EventLogMessage";
    public static final String HEADER_EVENT_RPOCESSING_ERROR_DETAILS="EventProcessingErrorDetails";

    // Message Processing Headers
    public static final String HEADER_CHANNEL_ID="ChannelId";
    public static final String HEADER_COUNTRY_CODE="CountryCode";
    public static final String HEADER_PROCESSING_QUEUE_ROUTER_ENDPOINT="ProcessingQueueRouterEndpoint";
    public static final String HEADER_PROCESSING_NEXT_ENDPOINT="NextEndpoint";
    public static final String HEADER_PROCESSING_RETRY_ATTEMPTS="RetryAttempts";
    public static final String HEADER_PROCESSING_MAX_RETRY_ATTEMPTS_EXCEEDED="MaxRetryAttemptsExceeded";

    //Transaction Processing Headers
    public static final String HEADER_SOURCE_TYPE="SourceType";

    public static final String MESSAGE_DIRECTION="MessageDirection";

    public static final String MESSAGE_ROUTING_STATUS="MessageRoutingStatus";


    public static final String MESSAGE_TYPE="MessageType";

    public static final String ORIGINAL_MESSAGE="originalMessage";
    public static final String TRANSLATED_MESSAGE="translatedMessage";
    public static final String VALIDATION_STATUS="validationStatus";
    public static final String VALIDATION_REMARKS="validationRemarks";


    public static final String HEADER_SOURCE_TYPE_VALUE_HTTP="http";
    public static final String HEADER_SOURCE_TYPE_VALUE_MESSAGE="message";
    public static final String HEADER_SOURCE_SYSTEM="SourceSystem";
    public static final String HEADER_MESSAGE_TYPE="MessageType";
    public static final String HEADER_PAYMENT_TYPES="PaymentType";
    public static final String HEADER_PAYMENT_HUB_TXN_REF="HubTxnRef";
    public static final String HEADER_PAYMENT_IS_RETRIGGER="RETRIGGER";

    public static final String HEADER_PROCESSING_STATUS_CODE="ProcessingStatus";
    public static final String HEADER_PROCESSING_STAGE_CODE="ProcessingStage";
    public static final String HEADER_PAYMENT_PROCESSING_LOG_DETAIL="ProcessingLogDetails";

    public static final String HEADER_TENANT_ID="TenantId";

    public static final String HEADER_SOURCE_TYPE_VALUE_HTTP_ISO20022="http_iso20022";

    public static final String HEADER_SOURCE_TYPE_VALUE_CUSTOM_JSON="http_custom_json";

    public static final String HEADER_SOURCE_TYPE_VALUE_HTTP_MT202="MT202";

    public static final String HEADER_MESSAGE_TYPE_PAIN="PAIN";
    public static final String HEADER_MESSAGE_TYPE_CUSTOM_JSON="CustomJSON";

    public static final String HEADER_MESSAGE_TYPE_MT_101="MT101";

    public static final String HEADER_MESSAGE_TYPE_MT_202="MT202";
    public static final String HEADER_MESSAGE_TYPE_MT_103="MT103";

    public static final String HEADER_MESSAGE_TYPE_FAST="FAST";
    public static final String HEADER_MESSAGE_TYPE_PACS8="PACS8";
    public static final String HEADER_MESSAGE_TYPE_PACS2="PACS2";

    public static final String HEADER_MESSAGE_TYPE_PACS9COV="PACS9COVE";


    public static final String PRODUCT_TYPE = "PRODUCT_TYPE";

    public static final String VALIDATED_OBJ="EventId";
    public static final String MESSAGE_LEVEL_ID="MsgLvlId";

    public static final String BATCH_HEADER="BatchHeader";

    public static final String INSTRUCT_LEVEL_ID="InstructLvlId";

    public static final String INSTRUCT_LEVEL_DATA="InstructLevelData";


    public static final String MESSAGE_LEVEL_OID = "MsgLvlOId";
    public static final String LATEST_CURRENCY_RATE = "LatestCurrRate";
    // D for debit C for credit
    public static final String HEADER_ACCOUNT_POSTING_TYPE="AccountPostingType";
    public static final String ACCOUNT_POSTING_TYPE_DEBIT="D";
    public static final String ACCOUNT_POSTING_TYPE_CREDIT="C";


}
