package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;

/**
 * A TxnProcessLog.
 */
@Entity
@Table(name = "txn_process_log")
@RegisterForReflection
@Data
public class TxnProcessLog extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Column(name = "record_id", nullable = false)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @Size(max = 400)
    @Column(name = "details", length = 400)
    public String details;

    @NotNull
    @Size(max = 100)
    @Column(name = "event_id", length = 100, nullable = false)
    public String eventId;

    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50)
    public String payhubTxnRef;

    @Size(max = 10)
    @Column(name = "stage_cd", length = 10)
    public String stageCd;

    @Size(max = 3)
    @Column(name = "status_cd", length = 3)
    public String statusCd;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TxnProcessLog)) {
            return false;
        }
        return id != null && id.equals(((TxnProcessLog) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TxnProcessLog{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", details='" + details + "'" +
            ", eventId='" + eventId + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", stageCd='" + stageCd + "'" +
            ", statusCd='" + statusCd + "'" +
            "}";
    }

    public TxnProcessLog update() {
        return update(this);
    }

    public TxnProcessLog persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TxnProcessLog update(TxnProcessLog txnProcessLog) {
        if (txnProcessLog == null) {
            throw new IllegalArgumentException("txnProcessLog can't be null");
        }
        var entity = TxnProcessLog.<TxnProcessLog>findById(txnProcessLog.id);
        if (entity != null) {
            entity.recordId = txnProcessLog.recordId;
            entity.createdBy = txnProcessLog.createdBy;
            entity.createdDt = txnProcessLog.createdDt;
            entity.lastUpdatedBy = txnProcessLog.lastUpdatedBy;
            entity.lastUpdatedDt = txnProcessLog.lastUpdatedDt;
            entity.lockFlag = txnProcessLog.lockFlag;
            entity.details = txnProcessLog.details;
            entity.eventId = txnProcessLog.eventId;
            entity.payhubTxnRef = txnProcessLog.payhubTxnRef;
            entity.stageCd = txnProcessLog.stageCd;
            entity.statusCd = txnProcessLog.statusCd;
        }
        return entity;
    }

    public static TxnProcessLog persistOrUpdate(TxnProcessLog txnProcessLog) {
        if (txnProcessLog == null) {
            throw new IllegalArgumentException("txnProcessLog can't be null");
        }
        if (txnProcessLog.id == null) {
            persist(txnProcessLog);
            return txnProcessLog;
        } else {
            return update(txnProcessLog);
        }
    }

    @PrePersist
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

        this.setRecordId(0L);
    }


}
