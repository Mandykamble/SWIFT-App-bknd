package com.ncs.pay.config.params;
import lombok.Data;


public interface CamelMessageRouteProperty {

     String routeId();
     String channelId();
     String countryCd();
     String inputEndpoint();
     String processor();
     String targetProcessingQueueEndpoint();
     String outputEndpoint();
}
