package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.TimeZone;

/**
 * A MessageInfo.
 */
@Entity
@Table(name = "messages_info" ,   uniqueConstraints={
        @UniqueConstraint(columnNames = {"payhub_txn_ref", "message_direction", "message_type"})
})
@RegisterForReflection
@Data
public class MessageInfo extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(name = "record_id", nullable = true)
    public Long recordId;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 100)
    @Column(name = "event_id", length = 100, nullable = false, unique = true)
    public String eventId;

    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50)
    public String payhubTxnRef;

    @Column(name = "aging")
    public Boolean aging;

    @Size(max = 50)
    @Column(name = "correlation_id", length = 50)
    public String correlationId;

    @NotNull
    @Size(max = 100)
    @Column(name = "country_cd", length = 100, nullable = false)
    public String countryCd;

    @NotNull
    @Size(max = 50)
    @Column(name = "msg_uid", length = 50, nullable = false)
    public String msgUid;

    @Size(max = 100)
    @Column(name = "reply_to_address", length = 100)
    public String replyToAddress;

    @Lob
    @Column(name = "req_msg_content")
    public byte[] reqMsgContent;

    @Column(name = "req_msg_content_content_type")
      public String reqMsgContentContentType;

    @Lob
    @Column(name = "res_msg_content")
    public byte[] resMsgContent;

    @Column(name = "res_msg_content_content_type")
      public String resMsgContentContentType;

    @Size(max = 255)
    @Column(name = "routing_status", length = 255)
    public String routingStatus;

    @NotNull
    @Size(max = 20)
    @Column(name = "source_id", length = 20, nullable = false)
    public String sourceId;

    @NotNull
    @Column(name = "message_direction",  nullable = false)
    public String messageDirection;

    @NotNull
    @Column(name = "message_type", length = 20, nullable = false)
    public String messageType;

    @Column(name = "validation_status", length = 50, nullable = true)
    public String validationStatus;

    @Lob
    @Column(name = "validation_remarks", nullable = true)
    public String validationRemarks;

    @Column(name = "nb_of_txns", nullable = true)
    public Integer nbOfTxns;

    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = true)
    public String tenantId;



    public static MessageInfo findByEventId(String eventId) {

        MessageInfo inboundMessages = MessageInfo.find("eventId", eventId).firstResult();

        return  inboundMessages;

    }
    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MessageInfo)) {
            return false;
        }
        return id != null && id.equals(((MessageInfo) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "MessageInfo{" +
            "id=" + id +
            ", recordId=" + recordId +
            ", createdBy='" + createdBy + "'" +
            ", createdDt='" + createdDt + "'" +
            ", lastUpdatedBy='" + lastUpdatedBy + "'" +
            ", lastUpdatedDt='" + lastUpdatedDt + "'" +
            ", lockFlag=" + lockFlag +
            ", eventId='" + eventId + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", aging='" + aging + "'" +
            ", correlationId='" + correlationId + "'" +
            ", countryCd='" + countryCd + "'" +
            ", msgUid='" + msgUid + "'" +
            ", replyToAddress='" + replyToAddress + "'" +
            ", reqMsgContent='" + reqMsgContent + "'" +
            ", reqMsgContentContentType='" + reqMsgContentContentType + "'" +
            ", resMsgContent='" + resMsgContent + "'" +
            ", resMsgContentContentType='" + resMsgContentContentType + "'" +
            ", routingStatus='" + routingStatus + "'" +
            ", sourceId='" + sourceId + "'" +
            ", messageDirection='" + messageDirection + "'" +
            ", messageType='" + messageType + "'" +
            ", validationStatus='" + validationStatus + "'" +
            ", validationRemarks='" + validationRemarks + "'" +
            "}";
    }

    public MessageInfo update() {
        return update(this);
    }

    public MessageInfo persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static MessageInfo update(MessageInfo inboundMessages) {
        if (inboundMessages == null) {
            throw new IllegalArgumentException("inboundMessages can't be null");
        }
        var entity = MessageInfo.<MessageInfo>findById(inboundMessages.id);
        if (entity != null) {
            entity.recordId = inboundMessages.recordId;
            entity.createdBy = inboundMessages.createdBy;
            entity.createdDt = inboundMessages.createdDt;
            entity.lastUpdatedBy = inboundMessages.lastUpdatedBy;
            entity.lastUpdatedDt = inboundMessages.lastUpdatedDt;
            entity.lockFlag = inboundMessages.lockFlag;
            entity.eventId = inboundMessages.eventId;
            entity.payhubTxnRef = inboundMessages.payhubTxnRef;
            entity.aging = inboundMessages.aging;
            entity.correlationId = inboundMessages.correlationId;
            entity.countryCd = inboundMessages.countryCd;
            entity.msgUid = inboundMessages.msgUid;
            entity.replyToAddress = inboundMessages.replyToAddress;
            entity.reqMsgContent = inboundMessages.reqMsgContent;
            entity.resMsgContent = inboundMessages.resMsgContent;
            entity.routingStatus = inboundMessages.routingStatus;
            entity.sourceId = inboundMessages.sourceId;
            entity.messageDirection =inboundMessages.messageDirection;
            entity.messageType = inboundMessages.messageType;
            entity.validationStatus = inboundMessages.validationStatus;
            entity.validationRemarks =inboundMessages.validationRemarks;
            entity.nbOfTxns = inboundMessages.nbOfTxns;
            entity.tenantId =inboundMessages.tenantId;
        }
        return entity;
    }

    public static MessageInfo persistOrUpdate(MessageInfo inboundMessages) {
        if (inboundMessages == null) {
            throw new IllegalArgumentException("inboundMessages can't be null");
        }
        if (inboundMessages.id == null) {
            persist(inboundMessages);
            return inboundMessages;
        } else {
            return update(inboundMessages);
        }
    }

    @PrePersist
    public void onPrePersist() {

        TimeZone timeZone = TimeZone.getTimeZone("Asia/Singapore");

        // Obtain a Calendar instance using the specified timezone
        Calendar calendar = Calendar.getInstance(timeZone);

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

        this.setRecordId(0L);
    }


}
