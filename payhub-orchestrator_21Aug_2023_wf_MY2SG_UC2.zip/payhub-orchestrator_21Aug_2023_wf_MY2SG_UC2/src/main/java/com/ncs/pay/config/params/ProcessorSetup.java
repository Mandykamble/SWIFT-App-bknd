package com.ncs.pay.config.params;

import lombok.Data;


public interface ProcessorSetup {
     MessageRoutingSetup endpoints();
   /// private HashMap<String, Integer> maxRetries;
}
