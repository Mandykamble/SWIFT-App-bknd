package com.ncs.pay.config;


import com.ncs.pay.config.params.CustomQueue;
import com.ncs.pay.config.params.ProcessorSetup;
import com.ncs.pay.config.params.ProductSetup;
import io.smallrye.config.ConfigMapping;
import lombok.Data;

import java.util.List;
import java.util.Map;

@ConfigMapping(prefix = "payhub.product-setup")
public interface ProductSetupProperties {

    List<ProductSetup> products();
    ProcessorSetup processors();
    List<CustomQueue> workflowQueueList();

    Map<String, String> workflowQueues();

}
