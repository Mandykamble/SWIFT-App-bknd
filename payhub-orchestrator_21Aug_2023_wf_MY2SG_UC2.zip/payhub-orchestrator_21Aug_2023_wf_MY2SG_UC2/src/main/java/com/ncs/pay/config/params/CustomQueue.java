package com.ncs.pay.config.params;


import lombok.Data;


public interface CustomQueue {

     String queueName();
     String queueValue();
}
