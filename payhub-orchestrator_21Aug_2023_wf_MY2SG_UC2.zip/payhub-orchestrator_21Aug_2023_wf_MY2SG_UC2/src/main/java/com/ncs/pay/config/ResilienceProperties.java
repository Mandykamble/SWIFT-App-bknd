package com.ncs.pay.config;

import io.smallrye.config.ConfigMapping;



@ConfigMapping(prefix = "payhub.resilience")
public interface ResilienceProperties {
    int defaultRetryWaitInterval();
    int defaultRetryAttempts();
    int defultInitialAckRetryWaitInterval();
    int defultInitialAckRetryAttempts();
}
