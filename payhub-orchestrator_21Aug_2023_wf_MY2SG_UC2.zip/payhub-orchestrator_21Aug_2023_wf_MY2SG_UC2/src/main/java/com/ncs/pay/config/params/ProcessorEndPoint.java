package com.ncs.pay.config.params;

import lombok.Data;

@Data
public class ProcessorEndPoint {
   private String DefaultProcessingQueueRouter;
    private String OUT_FASTProcessingQueue;
    private String OUT_PayNowProcessingQueue;
    private String OUT_MEPSProcessingQueue;
    private String OUT_TTProcessingQueue;
    private String BKTXRProcessingQueue;
    private String IN_FASTProcessingQueue;
    private String IN_PayNowProcessingQueue;
    private String IN_MEPSProcessingQueue;
    private String IN_TTProcessingQueue;
}
