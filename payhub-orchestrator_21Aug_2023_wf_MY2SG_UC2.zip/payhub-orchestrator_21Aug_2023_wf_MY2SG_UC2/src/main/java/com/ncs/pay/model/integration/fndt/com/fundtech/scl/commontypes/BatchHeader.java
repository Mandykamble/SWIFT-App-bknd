package com.ncs.pay.model.integration.fndt.com.fundtech.scl.commontypes;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
@XmlRootElement(name = "BatchHeader")
public class BatchHeader {

    @XmlElement(name = "GrpHdr")
    protected GroupHeader95 grpHdr;
    // getters and setters
}