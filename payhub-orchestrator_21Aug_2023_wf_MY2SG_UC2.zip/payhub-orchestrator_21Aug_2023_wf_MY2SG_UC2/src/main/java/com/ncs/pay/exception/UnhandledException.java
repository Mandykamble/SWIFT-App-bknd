package com.ncs.pay.exception;


import com.ncs.pay.constants.DefaultConstants;
import com.ncs.pay.model.constants.ErrorCodes;
import lombok.Data;

@Data
public class UnhandledException extends Exception {


    private String ErrorCode;
    private String Message;
    private Class Origin;
    private String RecoveryEndpoint;
    private String PostErrorEnpoint;

    public UnhandledException(String Message) {
	    super(ErrorCodes.UNHANDLED_EXCEPTION );
        this.ErrorCode = ErrorCodes.UNHANDLED_EXCEPTION;
	    this.Message = Message;
	    this.RecoveryEndpoint = DefaultConstants.DefaultExceptionQueueEndpoint;
    }


}
