package com.ncs.pay.config.params;

import com.ncs.pay.constants.DefaultConstants;
import lombok.Data;

import java.util.Set;


public interface ProductSetup {
     String productCd();
     String countryCd();
     String preProcessingException();
     Set<String> allowedBranches();
     String preProcessorEndPoint();
     boolean enablePreProcessor();
     String processorEndpoint();
     boolean enableProcessor();
     String postProcessorEndpoint();
     boolean enablePostProcessor = false;
     boolean nonStpCurrencyCheck = false;
     String nonStpCurrencyCheckEndpoint = DefaultConstants.DefaultNonStpCurrencyCheckEndpoint;
     boolean specialWordsCheck = false;
     String specialWordsCheckEndpoint = DefaultConstants.DefaultSpecialWordsCheckEndpoint;
     boolean industryCutoffTimeCheck = false;
     String industryCutoffTimeCheckEndpoint = DefaultConstants.DefaultIndustryCutoffTimeCheckEndpoint;
     boolean duplicateTxnCheck = false;
     String duplicateTxnCheckEndpoint = DefaultConstants.DefaultDuplicateTxnCheckEndpoint;
     boolean deriveCharges = false;
     String deriveChargesEndpoint = DefaultConstants.DefaultDeriveChargesEndpoint;
     boolean roundTripCheck = false;
     String roundTripCheckEndpoint = DefaultConstants.DefaultRoundTripCheckEndpoint;
     boolean warehouseCheck = false;
     String warehouseCheckEndpoint = DefaultConstants.DefaultWarehouseCheckEndpoint;
     boolean coverMatch = false;
     String coverMatchEndpoint = DefaultConstants.DefaultCoverMatchEndpoint;
     boolean settlementPosting = false;
     String settlementPostingEndpoint = DefaultConstants.DefaultSettlementPostingEndpoint;
     boolean generateOutGoingMessage = false;
     String generateOutGoingMessageEndpoint = DefaultConstants.DefaultGenerateOutGoingMessageEndpoint;
     boolean amlCheck = false;
     String amlCheckEndpoint = DefaultConstants.DefaultAMLCheckEndpoint;
     boolean allowAutoRepair = false;
     String autoRepairEndpoint = DefaultConstants.DefaultAutoRepairEndpoint;
     boolean sendOutgoingMessage = false;
     String sendOutgoingMessageEndpoint = DefaultConstants.DefaultSendOutgoingMessageEndpoint;
     boolean nostroPosting = false;
     String nostroPostingEndpoint = DefaultConstants.DefaultNostroPostingEndpoint;
     boolean generatedAdvice = false;
     String generatedAdviceEndpoint = DefaultConstants.DefaultGeneratedAdviceEndpoint;


}
