package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.runtime.annotations.RegisterForReflection;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.*;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransactionLevel.
 */
@Entity
@Table(name = "transaction_level")
@Cacheable
@RegisterForReflection
@Data
public class TransactionLevel extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull
    @Size(max = 40)
    @Column(name = "txn_ref", length = 40, nullable = false)
    public String txnRef;

    @NotNull
    @Size(max = 20)
    @Column(name = "txn_id", length = 20, nullable = false)
    public String txnId;

    @NotNull
    @Size(max = 20)
    @Column(name = "end_to_end_id", length = 20, nullable = false)
    public String endToEndId;

    @Column(name = "instd_amt", precision = 21, scale = 2)
    public BigDecimal instdAmt;

    @Size(max = 255)
    @Column(name = "instd_amtccy", length = 255)
    public String instdAmtccy;

    @Size(max = 15)
    @Column(name = "purp_cd", length = 15)
    public String purpCd;

    @Size(max = 255)
    @Column(name = "dbtr_nm", length = 255)
    public String dbtrNm;

    @Size(max = 40)
    @Column(name = "dbtr_acct", length = 40)
    public String dbtrAcct;

    @Size(max = 40)
    @Column(name = "dbtr_acct_type", length = 40)
    public String dbtrAcctType;

    @Size(max = 6)
    @Column(name = "dbtr_acct_ccy", length = 6)
    public String dbtrAcctCcy;

    @Size(max = 40)
    @Column(name = "dbtr_agt_id", length = 40)
    public String dbtrAgtId;

    @Size(max = 255)
    @Column(name = "cdtr_nm", length = 255)
    public String cdtrNm;

    @Size(max = 40)
    @Column(name = "cdtr_acct", length = 40)
    public String cdtrAcct;

    @Size(max = 40)
    @Column(name = "cdtr_acct_type", length = 40)
    public String cdtrAcctType;

    @Size(max = 6)
    @Column(name = "cdtr_acct_ccy", length = 6)
    public String cdtrAcctCcy;

    @Size(max = 40)
    @Column(name = "cdtr_agt_id", length = 40)
    public String cdtrAgtId;

    @Size(max = 20)
    @Column(name = "error_code", length = 20)
    public String errorCode;

    @Size(max = 20)
    @Column(name = "stage_code", length = 20)
    public String stageCode;

    @Size(max = 20)
    @Column(name = "trans_lvl_status", length = 20)
    public String transLvlStatus;

    @Size(max = 400)
    @Column(name = "trans_remarks", length = 400)
    public String transRemarks;

    @NotNull
    @Column(name = "lock_flag", nullable = false)
    public Integer lockFlag;

    @NotNull
    @Size(max = 100)
    @Column(name = "created_by", length = 100, nullable = false)
    public String createdBy;

    @NotNull
    @Column(name = "created_dt", nullable = false)
    public Instant createdDt;

    @Size(max = 100)
    @Column(name = "last_updated_by", length = 100)
    public String lastUpdatedBy;

    @NotNull
    @Column(name = "last_updated_dt", nullable = false)
    public Instant lastUpdatedDt;


    @ManyToOne
    @JoinColumn(name = "instruction_level_id")
    @JsonbTransient
    public InstructionLevel instructionLevel;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionLevel)) {
            return false;
        }
        return id != null && id.equals(((TransactionLevel) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return (
            "TransactionLevel{" +
            "id=" +
            id +
            ", txnRef='" +
            txnRef +
            "'" +
            ", txnId='" +
            txnId +
            "'" +
            ", endToEndId='" +
            endToEndId +
            "'" +
            ", instdAmt=" +
            instdAmt +
            ", instdAmtccy='" +
            instdAmtccy +
            "'" +
            ", purpCd='" +
            purpCd +
            "'" +
            ", dbtrNm='" +
            dbtrNm +
            "'" +
            ", dbtrAcct='" +
            dbtrAcct +
            "'" +
            ", dbtrAcctType='" +
            dbtrAcctType +
            "'" +
            ", dbtrAcctCcy='" +
            dbtrAcctCcy +
            "'" +
            ", dbtrAgtId='" +
            dbtrAgtId +
            "'" +
            ", cdtrNm='" +
            cdtrNm +
            "'" +
            ", cdtrAcct='" +
            cdtrAcct +
            "'" +
            ", cdtrAcctType='" +
            cdtrAcctType +
            "'" +
            ", cdtrAcctCcy='" +
            cdtrAcctCcy +
            "'" +
            ", cdtrAgtId='" +
            cdtrAgtId +
            "'" +
            ", errorCode='" +
            errorCode +
            "'" +
            ", stageCode='" +
            stageCode +
            "'" +
            ", transLvlStatus='" +
            transLvlStatus +
            "'" +
            ", transRemarks='" +
            transRemarks +
            "'" +
            ", lockFlag=" +
            lockFlag +
            ", createdBy='" +
            createdBy +
            "'" +
            ", createdDt='" +
            createdDt +
            "'" +
            ", lastUpdatedBy='" +
            lastUpdatedBy +
            "'" +
            ", lastUpdatedDt='" +
            lastUpdatedDt +
            "'" +
            "}"
        );
    }

    public TransactionLevel update() {
        return update(this);
    }

    public TransactionLevel persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TransactionLevel update(TransactionLevel transactionLevel) {
        if (transactionLevel == null) {
            throw new IllegalArgumentException("transactionLevel can't be null");
        }
        var entity = TransactionLevel.<TransactionLevel>findById(transactionLevel.id);
        if (entity != null) {
            entity.txnRef = transactionLevel.txnRef;
            entity.txnId = transactionLevel.txnId;
            entity.endToEndId = transactionLevel.endToEndId;
            entity.instdAmt = transactionLevel.instdAmt;
            entity.instdAmtccy = transactionLevel.instdAmtccy;
            entity.purpCd = transactionLevel.purpCd;
            entity.dbtrNm = transactionLevel.dbtrNm;
            entity.dbtrAcct = transactionLevel.dbtrAcct;
            entity.dbtrAcctType = transactionLevel.dbtrAcctType;
            entity.dbtrAcctCcy = transactionLevel.dbtrAcctCcy;
            entity.dbtrAgtId = transactionLevel.dbtrAgtId;
            entity.cdtrNm = transactionLevel.cdtrNm;
            entity.cdtrAcct = transactionLevel.cdtrAcct;
            entity.cdtrAcctType = transactionLevel.cdtrAcctType;
            entity.cdtrAcctCcy = transactionLevel.cdtrAcctCcy;
            entity.cdtrAgtId = transactionLevel.cdtrAgtId;
            entity.errorCode = transactionLevel.errorCode;
            entity.stageCode = transactionLevel.stageCode;
            entity.transLvlStatus = transactionLevel.transLvlStatus;
            entity.transRemarks = transactionLevel.transRemarks;
            entity.lockFlag = transactionLevel.lockFlag;
            entity.createdBy = transactionLevel.createdBy;
            entity.createdDt = transactionLevel.createdDt;
            entity.lastUpdatedBy = transactionLevel.lastUpdatedBy;
            entity.lastUpdatedDt = transactionLevel.lastUpdatedDt;
            entity.instructionLevel = transactionLevel.instructionLevel;
        }
        return entity;
    }

    public static TransactionLevel persistOrUpdate(TransactionLevel transactionLevel) {
        if (transactionLevel == null) {
            throw new IllegalArgumentException("transactionLevel can't be null");
        }
        if (transactionLevel.id == null) {
            persist(transactionLevel);
            return transactionLevel;
        } else {
            return update(transactionLevel);
        }
    }

    @PrePersist
    @PreUpdate
    public void onPrePersist() {

        Timestamp sqlTS = new Timestamp(Calendar.getInstance().getTime().getTime());

        if (this.getCreatedBy() == null) {
            this.setCreatedBy("SYSTEM");
        }
        if (this.getLastUpdatedBy() == null) {
            this.setLastUpdatedBy("SYSTEM");
        }

        if (this.getCreatedDt() == null) {
            this.setCreatedDt(sqlTS.toInstant());
        }
        this.setLastUpdatedDt(sqlTS.toInstant());

        this.setLockFlag(0);

    }
}
