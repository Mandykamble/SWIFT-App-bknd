package com.ncs.pay.config;


import com.ncs.pay.config.params.CamelMessageRouteProperty;
import com.ncs.pay.config.params.MessageRoutingSetup;
import io.smallrye.config.ConfigMapping;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.List;


@ConfigMapping(prefix = "payhub.integration.messaging")
public interface MessagingIntegrationProperties {
    List<CamelMessageRouteProperty> inbound();
    List<BrokerConnectionParams> brokers();
    MessageRoutingSetup routing();
    //   HttpInboundSetup http;

}

