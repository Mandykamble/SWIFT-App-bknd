package com.ncs.pay.config;

import com.ncs.pay.config.params.ChannelSetup;
import io.smallrye.config.ConfigMapping;
import lombok.Data;

import java.util.List;


@ConfigMapping(prefix = "payhub.channels-setup")
public interface ChannelSetupProperties {
    List<ChannelSetup> channels();
}
