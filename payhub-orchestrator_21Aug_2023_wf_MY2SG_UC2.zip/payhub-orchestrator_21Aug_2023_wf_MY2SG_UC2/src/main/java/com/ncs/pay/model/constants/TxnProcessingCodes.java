package com.ncs.pay.model.constants;

public class TxnProcessingCodes {
    public interface StatusCodes {
        //Status Codes
        public static final String CREATED = "00";
        public static final String AUTH1 = "01";
        public static final String AUTH2 = "02";
        public static final String UNKNOWN = "05";
        public static final String PROCESSING = "10";

        public static final String REPAIR = "20";

        public static final String PENDING_APPROVAL = "25";
        public static final String RETRIGGER = "26";


        public static final String PENDING_OVERRIDING = "10";
        public static final String PENDING_ADHOC_APPROVAL = "11";
        public static final String WAREHOOUSED = "10W";
        public static final String PENDING_DISCARDED = "13";
        public static final String COMPLETED = "30";
        public static final String REJECTED = "40";
        public static final String PENDING_PRINT = "20";
        public static final String FORCE_COMPLETED = "34";
        public static final String DELETED = "40";

        public static final String PENDING_LIMIT_CHECK = "41";

        public static final String KIV = "100";
        public static final String CLARIFY = "101";
        public static final String DISCARDED = "99";
        public static final String MANAGE_IMAGE = "102";
        public static final String MAKER = "103";
        public static final String CHECKER = "104";
        public static final String MERGED = "105";
        public static final String SPLITTED = "106";
        public static final String ATTACHED = "107";


    }
    public interface StageCodes {
        // Stage Codes
        // General Code Naming Convention
        // First 2 digits before hyphen represent status cd
        // Codes ending in 0 indicate Informational or Decision Status
        // Codes ending in 1 indicate success
        // Codes ending in 5 indicate failure

        // RECEIVED Stage Codes
        public static final String UNKNOWN_UNDETERMINED = "99-000";
        public static final String CREATED_000_TXN_ROUTED = "00-000";
        public static final String CREATED_005_TXN_ROUTING_FAILED = "00-005";


        // PROCESSING Stage Codes

        //Pre Processing Stages
        public static final String PROCESSING_100_INITIATED = "10-100";
        public static final String PROCESSING_101_TXN_MASTER_CREATED = "10-101";
        public static final String PROCESSING_105_TXN_MASTER_CREATION_FAILED = "10-105";
        public static final String PROCESSING_111_TXN_INITIAL_ACK_SUCCESS = "10-111";
        public static final String PROCESSING_115_TXN_INITIAL_ACK_FAILED = "10-115";
        public static final String PROCESSING_120_PROCESSING_DATE_DERVIED = "10-120";
        public static final String PROCESSING_140_DEBIT_CREDIT_ACCOUNT_VALIDATION_INITIATED = "10-140";
        public static final String PROCESSING_141_DEBIT_CREDIT_ACCOUNT_VALIDATION_SUCCESS = "10-141";
        public static final String PROCESSING_145_DEBIT_CREDIT_ACCOUNT_VALIDATION_FAILED = "10-145";


        public static final String PROCESSING_150_ACCOUNT_BALANCE_INQUIRY_INITIATED = "10-150";
        public static final String PROCESSING_151_ACCOUNT_BALANCE_INQUIRY_SUCCESS = "10-151";
        public static final String PROCESSING_155_ACCOUNT_BALANCE_INQUIRY_FAILED = "10-155";


        //Processing Non Financial Stages
        public static final String PROCESSING_200_CHARACTER_CHECK_INITIATED = "20-200";
        public static final String PROCESSING_201_CHARACTER_CHECK_SUCCESS = "20-201";
        public static final String PROCESSING_205_CHARACTER_CHECK_FAILED = "20-205";

        public static final String PROCESSING_201_NON_STP_CURRENCY_CHECK_SUCCESS="10-201";
        public static final String PROCESSING_210_SPECIAL_WORDS_CHECK_INITIATED = "10-210";
        public static final String PROCESSING_211_SPECIAL_WORDS_CHECK_SUCCESS = "10-211";
        public static final String PROCESSING_215_SPECIAL_WORDS_CHECK_FAILED = "10-215";
        public static final String PROCESSING_220_INDUSTRY_CUTOFF_TIME_CHECK_INITIATED = "10-220";
        public static final String PROCESSING_221_INDUSTRY_CUTOFF_TIME_CHECK_SUCCESS = "10-221";
        public static final String PROCESSING_225_INDUSTRY_CUTOFF_TIME_CHECK_FAILED = "10-225";
        public static final String PROCESSING_230_DUPLICATE_TXN_CHECK_INITIATED = "10-230";
        public static final String PROCESSING_231_DUPLICATE_TXN_CHECK_SUCCESS = "10-231";
        public static final String PROCESSING_235_DUPLICATE_TXN_CHECK_FAILED = "10-235";
        public static final String PROCESSING_240_DERIVE_CHARGES_INITIATED = "10-240";
        public static final String PROCESSING_241_DERIVE_CHARGES_SUCCESS = "10-241";
        public static final String PROCESSING_245_DERIVE_CHARGES_FAILED = "10-245";
        public static final String PROCESSING_250_ROUND_TRIP_CHECK_INITIATED = "10-250";
        public static final String PROCESSING_251_ROUND_TRIP_CHECK_SUCCESS = "10-251";
        public static final String PROCESSING_255_ROUND_TRIP_CHECK_FAILED = "10-255";
        public static final String PROCESSING_260_WAREHOUSE_CHECK_INITIATED = "10-260";
        public static final String PROCESSING_261_WAREHOUSE_CHECK_SUCCESS = "10-261";
        public static final String PROCESSING_265_WAREHOUSE_CHECK_FAILED = "10-265";
        public static final String PROCESSING_270_COVER_MATCH_INITIATED = "10-270";
        public static final String PROCESSING_271_COVER_MATCH_SUCCESS = "10-271";
        public static final String PROCESSING_275_COVER_MATCH_FAILED = "10-275";
        public static final String PROCESSING_280_SETTLEMENT_POSTING_INITIATED = "10-280";
        public static final String PROCESSING_281_SETTLEMENT_POSTING_SUCCESS = "10-281";
        public static final String PROCESSING_285_SETTLEMENT_POSTING_FAILED = "10-285";
        public static final String PROCESSING_290_GENERATE_OUTGOING_MESSAGE_INITIATED = "10-290";
        public static final String PROCESSING_291_GENERATE_OUTGOING_MESSAGE_SUCCESS = "10-291";
        public static final String PROCESSING_295_GENERATE_OUTGOING_MESSAGE_FAILED = "10-295";
        public static final String PROCESSING_300_AML_CHECK_INITIATED = "10-300";
        public static final String PROCESSING_301_AML_CHECK_SUCCESS = "10-301";
        public static final String PROCESSING_305_AML_CHECK_FAILED = "10-305";
        public static final String PROCESSING_310_STP_AMOUNT_LIMIT_CHECK_INITIATED = "10-310";
        public static final String PROCESSING_311_STP_AMOUNT_LIMIT_CHECK_SUCCESS = "10-311";
        public static final String PROCESSING_315_STP_AMOUNT_LIMIT_CHECK_FAILED = "10-315";

        // Processing Financial Stages
        public static final String PROCESSING_1310_FINAL_POSTING_INITIATED = "10-1310";
        public static final String PROCESSING_1311_FINAL_POSTING_SUCCESS = "10-1311";
        public static final String PROCESSING_1315_FINAL_POSTING_FAILED = "10-1315";
        public static final String PROCESSING_820_NOSTRO_POSTING_INITIATED = "10-330";
        public static final String PROCESSING_821_NOSTRO_POSTING_SUCCESS = "10-331";
        public static final String PROCESSING_825_NOSTRO_POSTING_FAILED = "10-335";
        public static final String PROCESSING_830_FX_POSTING_INITIATED = "10-340";
        public static final String PROCESSING_831_FX_POSTING_SUCCESS = "10-341";
        public static final String PROCESSING_835_FX_POSTING_FAILED = "10-345";
        public static final String PROCESSING_350_ACCOUNT_POSTING_INITIATED = "10-350";
        public static final String PROCESSING_351_ACCOUNT_POSTING_SUCCESS = "10-351";
        public static final String PROCESSING_355_ACCOUNT_POSTING_FAILED = "10-355";
        public static final String PROCESSING_360_COMPLIANCE_CHECK_INITIATED = "10-360";
        public static final String PROCESSING_361_COMPLIANCE_CHECK_SUCCESS = "10-361";
        public static final String PROCESSING_365_COMPLIANCE_CHECK_FAILED = "10-365";

        // Manual Recovery Stages
        public static final String REPAIR_100_MANUAL_REPAIR_QUEUE_RECEIVED = "20-100";
        public static final String REPAIR_110_MANUAL_REPAIR_QUEUE_ASSIGNED = "20-110";
        public static final String REPAIR_120_MANUAL_REPAIR_QUEUE_AUTHORIZED = "20-120";


        //  Auto Recovery Stages
        public static final String REPAIR_1100_AUTO_REPAIR_CORRECTION_INITIATED = "20-1100";
        public static final String REPAIR_1101_AUTO_REPAIR_CORRECTION_SUCCESS = "20-1101";
        public static final String REPAIR_1105_AUTO_REPAIR_CORRECTION_FAILED = "20-1105";
        public static final String REPAIR_1110_AUTO_REPAIR_NAME_VARIANCE_INITIATED = "20-1110";
        public static final String REPAIR_1111_AUTO_REPAIR_NAME_VARIANCE_SUCCESS = "20-1111";
        public static final String REPAIR_1115_AUTO_REPAIR_NAME_VARIANCE_FAILED = "20-1115";
        public static final String REPAIR_1120_AUTO_REPAIR_NAME_VARIANCE_INITIATED = "20-1110";
        public static final String REPAIR_1121_AUTO_REPAIR_NAME_VARIANCE_SUCCESS = "20-1111";
        public static final String REPAIR_1125_AUTO_REPAIR_NAME_VARIANCE_FAILED = "20-1115";


        //Post Successful Processing Stages
        public static final String COMPLETED_101_PROCESSING_SUCCESS = "30-101";
        public static final String COMPLETED_110_SEND_OUTGOING_MESSAGE_INITIATED = "30-110";
        public static final String COMPLETED_111_SEND_OUTGOING_MESSAGE_SUCCESS = "30-111";
        public static final String COMPLETED_115_SEND_OUTGOING_MESSAGE_FAILED = "30-115";
        public static final String COMPLETED_120_CONFIRM_CHARGES_INITIATED = "30-120";
        public static final String COMPLETED_121_CONFIRM_CHARGES_SUCCESS = "30-121";
        public static final String COMPLETED_125_CONFIRM_CHARGES_FAILED = "30-125";
        public static final String COMPLETED_130_SEND_GENERATE_ADVICE_INITIATED = "30-130";
        public static final String COMPLETED_131_SEND_GENERATE_ADVICE_SUCCESS = "30-131";
        public static final String COMPLETED_135_SEND_GENERATE_ADVICE_FAILED = "30-135";

        // Post Failed Processing Stages
        public static final String REJECTED_102_REJECTED = "40-102";
        public static final String REJECTED_103_DISCARDED = "40-103";
        public static final String REJECTED_110_SEND_OUTGOING_MESSAGE_INITIATED = "40-110";
        public static final String REJECTED_101_SEND_OUTGOING_MESSAGE_SUCCESS = "40-111";
        public static final String REJECTED_115_SEND_OUTGOING_MESSAGE_FAILED = "40-115";

        public static final String PACS8_GENERATED = "75-000";
        public static final String PACS8_SENT = "75-005";

        public static final String PACS2_GENERATED = "76-000";
        public static final String PACS2_RECIEVED = "76-005";

        public static final String MAY_BANK_MY_PACS8_GENERATED=  "80-000";

        public static final String MAY_BANK_MY_PACS8_SENT=  "80-005";
        public static final String MAY_BANK_MY_PACS9_COV_GENERATED=  "81-000";

        public static final String MAY_BANK_MY_PACS9_COV_SENT=  "81-005";

        public static final String MAY_BANK_MY_PACS2_FOR_PACS9COV_RECIEVED=  "82-000";

        public static final String MAY_BANK_MY_CAMT54_RECIEVED=  "83-000";

        public static final String MAY_BANK_PACS2_FOR_PACS8_RECIEVED=  "84-000";

        public static final String MAY_BANK_MY_CAMT53_RECIEVED=  "85-000";

        public static final String MAY_BANK_SG_PACS9_RECIEVED=  "86-000";
        public static final String MAY_BANK_SG_PACS2_SENT=  "87-000";
        public static final String MAY_BANK_SG_CAMT54_RECIEVED=  "88-000";
        public static final String MAY_BANK_SG_PACS2_MY_SENT=  "89-000";
        public static final String MAY_BANK_SG_CAMT53_RECIEVED=  "90-000";

        public static final String MAY_BANK_US_PACS2_SENT=  "91-000";

        public static final String MAY_BANK_US_CAMT54_SENT=  "92-000";

        public static final String MAY_BANK_US_CAMT53_SENT=  "93-000";

        public static final String MAY_BANK_US_SG_PACS9_SENT=  "94-000";

        public static final String MAY_BANK_US_SG_PACS2_RECIEVE=  "95-000";

        public static final String MAY_BANK_US_SG_CAMT54_SENT=  "96-000";


        public static final String MAY_BANK_US_SG_CAMT53_SENT=  "97-000";



    }

}
