package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.runtime.annotations.RegisterForReflection;
import java.io.Serializable;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import javax.validation.constraints.*;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A FITransaction.
 */
@Entity
@Table(name = "fi_transaction")
@Cacheable
@RegisterForReflection
public class FITransaction extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Size(max = 1)
    @Column(name = "auth_ind", length = 1)
    public String authInd;

    @Size(max = 1)
    @Column(name = "available_funds_override_ind", length = 1)
    public String availableFundsOverrideInd;

    @NotNull
    @Size(max = 1)
    @Column(name = "batch_txn_ind", length = 1, nullable = false)
    public String batchTxnInd;

    @NotNull
    @Size(max = 50)
    @Column(name = "channel", length = 50, nullable = false)
    public String channel;

    @Size(max = 1)
    @Column(name = "clarification_status", length = 1)
    public String clarificationStatus;

    @Size(max = 50)
    @Column(name = "convert_to_product_cd", length = 50)
    public String convertToProductCd;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Size(max = 50)
    @Column(name = "customer_ref", length = 50, unique = true)
    public String customerRef;

    @Size(max = 50)
    @Column(name = "discard_id", length = 50)
    public String discardId;

    @Size(max = 50)
    @Column(name = "discard_prior_status_code", length = 50)
    public String discardPriorStatusCode;

    @NotNull
    @Size(max = 50)
    @Column(name = "event_id", length = 50, nullable = false, unique = true)
    public String eventId;

    @Size(max = 1)
    @Column(name = "force_release_forward_ind", length = 1)
    public String forceReleaseForwardInd;

    @Size(max = 1)
    @Column(name = "handoff_stage_code", length = 1)
    public String handoffStageCode;

    @Size(max = 1)
    @Column(name = "inward_outward_ind", length = 1)
    public String inwardOutwardInd;

    @Size(max = 1)
    @Column(name = "kiv_status", length = 1)
    public String kivStatus;

    @Size(max = 1)
    @Column(name = "manual_override_ind", length = 1)
    public String manualOverrideInd;

    @Size(max = 100)
    @Column(name = "message_ref_number", length = 100)
    public String messageRefNumber;

    @Size(max = 1)
    @Column(name = "odd_currency_ind", length = 1)
    public String oddCurrencyInd;

    @Size(max = 1)
    @Column(name = "outgoing_msg_required_ind", length = 1)
    public String outgoingMsgRequiredInd;

    @Size(max = 1)
    @Column(name = "outgoing_msg_suppress_ind", length = 1)
    public String outgoingMsgSuppressInd;

    @Size(max = 1)
    @Column(name = "override_acct_signal_ind", length = 1)
    public String overrideAcctSignalInd;

    @Size(max = 50)
    @Column(name = "override_type", length = 50)
    public String overrideType;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false, unique = true)
    public String payhubTxnRef;

    @Size(max = 50)
    @Column(name = "payhub_txn_ref_old", length = 50)
    public String payhubTxnRefOld;

    @NotNull
    @Size(max = 50)
    @Column(name = "payment_product_code", length = 50, nullable = false)
    public String paymentProductCode;

    @Size(max = 1)
    @Column(name = "posting_status_cd", length = 1)
    public String postingStatusCd;

    @Size(max = 1)
    @Column(name = "prio_chg_by_sup_ind", length = 1)
    public String prioChgBySupInd;

    @Column(name = "priority")
    public Integer priority;

    @Size(max = 50)
    @Column(name = "processing_center_code", length = 50)
    public String processingCenterCode;

    @Size(max = 1)
    @Column(name = "received_amt_type_ind", length = 1)
    public String receivedAmtTypeInd;

    @Size(max = 1)
    @Column(name = "released_from_warehouse_ind", length = 1)
    public String releasedFromWarehouseInd;

    @Size(max = 1)
    @Column(name = "repair_ind", length = 1)
    public String repairInd;

    @Column(name = "retry_count")
    public Integer retryCount;

    @Size(max = 1)
    @Column(name = "same_debit_credit_acct_ind", length = 1)
    public String sameDebitCreditAcctInd;

    @NotNull
    @Size(max = 20)
    @Column(name = "source_id", length = 20, nullable = false)
    public String sourceId;

    @Size(max = 50)
    @Column(name = "source_txn_ref", length = 50)
    public String sourceTxnRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "stage_cd", length = 50, nullable = false)
    public String stageCd;

    @NotNull
    @Size(max = 50)
    @Column(name = "status_cd", length = 50, nullable = false)
    public String statusCd;

    @NotNull
    @Size(max = 1)
    @Column(name = "stp_result_ind", length = 1, nullable = false)
    public String stpResultInd;

    @NotNull
    @Size(max = 50)
    @Column(name = "stp_status_cd", length = 50, nullable = false)
    public String stpStatusCd;

    @NotNull
    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = false)
    public String tenantId;

    @Size(max = 50)
    @Column(name = "warehouse_status_cd", length = 50)
    public String warehouseStatusCd;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof FITransaction)) {
            return false;
        }
        return id != null && id.equals(((FITransaction) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return (
            "FITransaction{" +
            "id=" +
            id +
            ", authInd='" +
            authInd +
            "'" +
            ", availableFundsOverrideInd='" +
            availableFundsOverrideInd +
            "'" +
            ", batchTxnInd='" +
            batchTxnInd +
            "'" +
            ", channel='" +
            channel +
            "'" +
            ", clarificationStatus='" +
            clarificationStatus +
            "'" +
            ", convertToProductCd='" +
            convertToProductCd +
            "'" +
            ", countryCd='" +
            countryCd +
            "'" +
            ", customerRef='" +
            customerRef +
            "'" +
            ", discardId='" +
            discardId +
            "'" +
            ", discardPriorStatusCode='" +
            discardPriorStatusCode +
            "'" +
            ", eventId='" +
            eventId +
            "'" +
            ", forceReleaseForwardInd='" +
            forceReleaseForwardInd +
            "'" +
            ", handoffStageCode='" +
            handoffStageCode +
            "'" +
            ", inwardOutwardInd='" +
            inwardOutwardInd +
            "'" +
            ", kivStatus='" +
            kivStatus +
            "'" +
            ", manualOverrideInd='" +
            manualOverrideInd +
            "'" +
            ", messageRefNumber='" +
            messageRefNumber +
            "'" +
            ", oddCurrencyInd='" +
            oddCurrencyInd +
            "'" +
            ", outgoingMsgRequiredInd='" +
            outgoingMsgRequiredInd +
            "'" +
            ", outgoingMsgSuppressInd='" +
            outgoingMsgSuppressInd +
            "'" +
            ", overrideAcctSignalInd='" +
            overrideAcctSignalInd +
            "'" +
            ", overrideType='" +
            overrideType +
            "'" +
            ", payhubTxnRef='" +
            payhubTxnRef +
            "'" +
            ", payhubTxnRefOld='" +
            payhubTxnRefOld +
            "'" +
            ", paymentProductCode='" +
            paymentProductCode +
            "'" +
            ", postingStatusCd='" +
            postingStatusCd +
            "'" +
            ", prioChgBySupInd='" +
            prioChgBySupInd +
            "'" +
            ", priority=" +
            priority +
            ", processingCenterCode='" +
            processingCenterCode +
            "'" +
            ", receivedAmtTypeInd='" +
            receivedAmtTypeInd +
            "'" +
            ", releasedFromWarehouseInd='" +
            releasedFromWarehouseInd +
            "'" +
            ", repairInd='" +
            repairInd +
            "'" +
            ", retryCount=" +
            retryCount +
            ", sameDebitCreditAcctInd='" +
            sameDebitCreditAcctInd +
            "'" +
            ", sourceId='" +
            sourceId +
            "'" +
            ", sourceTxnRef='" +
            sourceTxnRef +
            "'" +
            ", stageCd='" +
            stageCd +
            "'" +
            ", statusCd='" +
            statusCd +
            "'" +
            ", stpResultInd='" +
            stpResultInd +
            "'" +
            ", stpStatusCd='" +
            stpStatusCd +
            "'" +
            ", tenantId='" +
            tenantId +
            "'" +
            ", warehouseStatusCd='" +
            warehouseStatusCd +
            "'" +
            "}"
        );
    }

    public FITransaction update() {
        return update(this);
    }

    public FITransaction persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static FITransaction update(FITransaction fITransaction) {
        if (fITransaction == null) {
            throw new IllegalArgumentException("fITransaction can't be null");
        }
        var entity = FITransaction.<FITransaction>findById(fITransaction.id);
        if (entity != null) {
            entity.authInd = fITransaction.authInd;
            entity.availableFundsOverrideInd = fITransaction.availableFundsOverrideInd;
            entity.batchTxnInd = fITransaction.batchTxnInd;
            entity.channel = fITransaction.channel;
            entity.clarificationStatus = fITransaction.clarificationStatus;
            entity.convertToProductCd = fITransaction.convertToProductCd;
            entity.countryCd = fITransaction.countryCd;
            entity.customerRef = fITransaction.customerRef;
            entity.discardId = fITransaction.discardId;
            entity.discardPriorStatusCode = fITransaction.discardPriorStatusCode;
            entity.eventId = fITransaction.eventId;
            entity.forceReleaseForwardInd = fITransaction.forceReleaseForwardInd;
            entity.handoffStageCode = fITransaction.handoffStageCode;
            entity.inwardOutwardInd = fITransaction.inwardOutwardInd;
            entity.kivStatus = fITransaction.kivStatus;
            entity.manualOverrideInd = fITransaction.manualOverrideInd;
            entity.messageRefNumber = fITransaction.messageRefNumber;
            entity.oddCurrencyInd = fITransaction.oddCurrencyInd;
            entity.outgoingMsgRequiredInd = fITransaction.outgoingMsgRequiredInd;
            entity.outgoingMsgSuppressInd = fITransaction.outgoingMsgSuppressInd;
            entity.overrideAcctSignalInd = fITransaction.overrideAcctSignalInd;
            entity.overrideType = fITransaction.overrideType;
            entity.payhubTxnRef = fITransaction.payhubTxnRef;
            entity.payhubTxnRefOld = fITransaction.payhubTxnRefOld;
            entity.paymentProductCode = fITransaction.paymentProductCode;
            entity.postingStatusCd = fITransaction.postingStatusCd;
            entity.prioChgBySupInd = fITransaction.prioChgBySupInd;
            entity.priority = fITransaction.priority;
            entity.processingCenterCode = fITransaction.processingCenterCode;
            entity.receivedAmtTypeInd = fITransaction.receivedAmtTypeInd;
            entity.releasedFromWarehouseInd = fITransaction.releasedFromWarehouseInd;
            entity.repairInd = fITransaction.repairInd;
            entity.retryCount = fITransaction.retryCount;
            entity.sameDebitCreditAcctInd = fITransaction.sameDebitCreditAcctInd;
            entity.sourceId = fITransaction.sourceId;
            entity.sourceTxnRef = fITransaction.sourceTxnRef;
            entity.stageCd = fITransaction.stageCd;
            entity.statusCd = fITransaction.statusCd;
            entity.stpResultInd = fITransaction.stpResultInd;
            entity.stpStatusCd = fITransaction.stpStatusCd;
            entity.tenantId = fITransaction.tenantId;
            entity.warehouseStatusCd = fITransaction.warehouseStatusCd;
        }
        return entity;
    }

    public static FITransaction persistOrUpdate(FITransaction fITransaction) {
        if (fITransaction == null) {
            throw new IllegalArgumentException("fITransaction can't be null");
        }
        if (fITransaction.id == null) {
            persist(fITransaction);
            return fITransaction;
        } else {
            return update(fITransaction);
        }
    }
}
