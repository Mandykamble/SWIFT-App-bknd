package com.ncs.pay.model.constants;

public enum InterfaceSystemsConstants {

    // Channels
    CHANNEL_IB("IB") ,
    CHANNEL_MB("MB");


    private String code;

    private InterfaceSystemsConstants(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
