/**
 *               Copyright (c) 2017 by NCS 
 *
 * All rights reserved.  These materials are confidential and
 * proprietary to NCS. and no part of these materials
 * should be reproduced, published in any form by any means, 
 * electronic or mechanical, including photocopy or any
 * Information storage or retrieval system nor should the
 * materials be disclosed to third parties without the express
 * written authorization of NCS.
 */
package com.ncs.pay.constants;

public enum TxnStatus {
	RECV, RJCT, ACTC, INDT, CNCL;
}