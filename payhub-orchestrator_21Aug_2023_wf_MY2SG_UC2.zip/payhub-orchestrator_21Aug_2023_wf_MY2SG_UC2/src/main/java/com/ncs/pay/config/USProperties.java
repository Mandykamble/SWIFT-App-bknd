package com.ncs.pay.config;

import io.smallrye.config.ConfigMapping;

/**
 * @author Amila Karunathilaka
 */
@ConfigMapping(prefix = "us")
public interface USProperties {

    String vostroSgAcc();

    String vostroMyAcc();
     String cashPoolAccUsd();
}
