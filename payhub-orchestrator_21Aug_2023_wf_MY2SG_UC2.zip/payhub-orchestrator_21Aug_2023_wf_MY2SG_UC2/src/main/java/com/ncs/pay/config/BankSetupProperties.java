package com.ncs.pay.config;

import io.smallrye.config.ConfigMapping;
@ConfigMapping(prefix = "payhub.bank-setup")
public interface BankSetupProperties {
     String countryCd();
     String bankCd();
     String defaultBranch();
     String bankName();

}
