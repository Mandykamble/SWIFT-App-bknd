package com.ncs.pay.config;
import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "vn")
public interface VNProperties {
     String cashPoolAcc();

     String cashPoolAccNm();

     String vostroAcc();

     String napasPayAcc();
}