package com.ncs.pay.model.constants;

public class WorkflowStageCodes {

        //Categories
        public interface WorkflowStageCategories {
        public static final String System = "SYSTEM";
        public static final String PreProcessing = "PRE_PROCESSING";
        public static final String Processing = "PROCESSING";
        public static final String PostProcessing = "POST_PROCESSING";
        public static final String MANUAL = "MANUAL";
        }

        public interface ExecutionStatus {
                public static final String EXECUTING = "EXECUTING";
                public static final String SUCCESS = "SUCCESS";
                public static final String FAILED = "FAILED";
                public static final String RERUN = "RERUN";
                public static final String UNKNOWN = "UNKNOWN";
        }
        //System Workflow Stages
        public interface SystemWorkflowStages {
                public static final String DefaultProcessingRouterQueue = "DefaultProcessingRouterQueue";
        }
        //Processing Stages
        public interface ProcessingWorkflowStages {
                public static final String DuplicateTxnCheckQueue = "DuplicateTxnCheckQueue";
                public static final String CharacterValidationCheckQueue = "CharacterValidationCheckQueue";

                public static final String AMLCheckQueue = "AMLCheckQueue";

                public static final String StpAmountLimitCheckQueue = "StpAmountLimitCheckQueue";
                public static final String CutoffTimeCheckQueue = "CutoffTimeCheckQueue";
                public static final String DebitCreditAccountValidationQueue = "DebitCreditAccountValidationQueue";
                public static final String WarehouseCheckQueue = "WarehouseCheckQueue";
                public static final String CheckChargesQueue = "CheckChargesQueue";
                public static final String ConfirmChargesQueue = "ConfirmChargesQueue";
                public static final String FinalPostingQueue = "FinalPostingQueue";

                public static final String FinalPostingMYQueue = "FinalPostingMYQueue";

                public static final String AccountPostingMYQueue = "AccountPostingMYQueue";

                public static final String AccountPostingRTGSQueue = "AccountPostingRTGSQueue";

                public static final String AccountPostingInstantPayQueue = "AccountPostingInstantPayQueue";


                public static final String ComplianceCheckQueue = "ComplianceCheckQueue";

                public static final String FinalPostingPHQueue = "FinalPostingPHQueue";
                public static final String FinalPostingInstaPayQueue = "FinalPostingInstaPayQueue";
                public static final String FinalPostingNAPASQueue = "FinalPostingNAPASQueue";

                public static final String FinalPostingNAPASSGQueue = "FinalPostingNAPASSGQueue";
                public static final String FinalPostingNAPASVNQueue = "FinalPostingNAPASVNQueue";

                public static final String GenerateOutgoingSwiftMessageQueue = "GenerateOutgoingSwiftMessageQueue";
                public static final String SendSwiftMessageQueue = "SendSwiftMessageQueue";
                public static final String CoverMatchQueue = "CoverMatchQueue";
                public static final String NostroPostingQueue = "NostroPostingQueue";
                public static final String AutoCorrectionCheckQueue = "ConfirmChargesQueue";
                public static final String ForexConverterQueue = "ForexConverterQueue";

                public static final String DuplicateTxnCheckInstaPayQueue = "DuplicateTxnCheckInstaPayQueue";

                public static final String FinalPostingMYUC2Queue = "FinalPostingMYUC2Queue" ;

                public static final String FinalPostingUSUC2Queue = "FinalPostingUSUC2Queue" ;

                public static final String FinalPostingUSOUTUC2Queue = "FinalPostingUSOUTUC2Queue" ;

                public static final String FinalPostingSGUC2Queue = "FinalPostingSGUC2Queue" ;

                public static final String  FinalPostingNEOQueue = "FinalPostingNEOQueue";
                public static final String FinalPostingInstantPayQueue = "FinalPostingInstantPayQueue";

                public static final String  DuplicateTxnCheckVnDomRtgsQueue = "DuplicateTxnCheckVnDomRtgsQueue";

                public static final String  FinalPostingVrtgsQueue = "FinalPostingVrtgsQueue";

                public static final String AccountValidityCheckQueue = "AccountValidityCheckQueue";
                public static final String AccountBalanceCheckQueue = "AccountBalanceCheckQueue";
                public static final String  ChargeDerivationRTGSQueue = "ChargeDerivationRTGSQueue";


        }
        public interface PostProcessingWorkflow  {
                public static final String SendFinalAckQueue = "SendFinalAckQueue";
                public static final String GenerateOrderPartyAdviceQueue = "GenerateAdviceContentQueue";
                public static final String GenerateBeneficiaryAdviceQueue = "GenerateAdviceContentQueue";
                public static final String SendAdviceQueue = "SendAdviceQueue";

        }

        public interface ManualWorkflowStages{
        // Operations Workflow Stages
        public static final String DraftQueue = "DraftQueue";
        public static final String KIVQueue = "KIVQueue";
        public static final String PendingAuthorizationQueue = "PendingAuthorizationQueue";
        public static final String RepairQueue = "RepairQueue";
        public static final String OverrideQueue = "OverrideQueue";
        public static final String AwaitDebitConfirmationQueue = "AwaitDebitConfirmationQueue";
        public static final String ReleaseAwaitDebitConfirmationQueue = "ReleaseAwaitDebitConfirmationQueue";
        public static final String ApproveAwaitDebitConfirmationQueue = "ApproveAwaitDebitConfirmationQueue";
        public static final String AwaitCreditConfirmationQueue = "AwaitCreditConfirmationQueue";
        public static final String ReleaseAwaitCreditConfirmationQueue = "ReleaseAwaitCreditConfirmationQueue";
        public static final String ApproveAwaitCreditConfirmationQueue = "ApproveAwaitCreditConfirmationQueue";
        public static final String DiscardQueue = "DiscardQueue";
        }
}
