package com.ncs.pay.model.constants;

public enum MessageTypeConstants {
}
