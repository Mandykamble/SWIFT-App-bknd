package com.ncs.pay.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Calendar;

/**
 * A TransactionDetails.
 */
@Entity
@Table(name = "transaction_details")
@Cacheable
@RegisterForReflection
@Data
public class TransactionDetails extends PanacheEntityBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Size(max = 3)
    @Column(name = "outgoing_charging_party", length = 3)
    public String outgoingChargingParty;

    @Size(max = 50)
    @Column(name = "applicant_account", length = 50)
    public String applicantAccount;

    @NotNull
    @Size(max = 3)
    @Column(name = "applicant_account_currency", length = 3, nullable = false)
    public String applicantAccountCurrency;

    @Size(max = 50)
    @Column(name = "applicant_bank_code", length = 50)
    public String applicantBankCode;

    @Size(max = 50)
    @Column(name = "applicant_branch_code", length = 50)
    public String applicantBranchCode;

    @Size(max = 50)
    @Column(name = "applicant_cif", length = 50)
    public String applicantCif;

    @Size(max = 50)
    @Column(name = "applicant_name", length = 50)
    public String applicantName;

    @Size(max = 2)
    @Column(name = "country_cd", length = 2)
    public String countryCd;

    @Size(max = 3)
    @Column(name = "dervied_charging_party", length = 3)
    public String derviedChargingParty;

    @NotNull
    @Size(max = 50)
    @Column(name = "payhub_txn_ref", length = 50, nullable = false, unique = true)
    public String payhubTxnRef;

    @NotNull
    @Size(max = 50)
    @Column(name = "payment_product_code", length = 50, nullable = false)
    public String paymentProductCode;

    @NotNull
    @Column(name = "payout_date", nullable = false)
    public LocalDate payoutDate;

    @Size(max = 50)
    @Column(name = "processing_center_code", length = 50)
    public String processingCenterCode;

    @NotNull
    @Column(name = "processing_date", nullable = false)
    public LocalDate processingDate;

    @NotNull
    @Column(name = "settlement_amount", nullable = false)
    public Double settlementAmount;

    @NotNull
    @Column(name = "settlement_amount_local_currency", nullable = false)
    public Double settlementAmountLocalCurrency;

    @NotNull
    @Size(max = 3)
    @Column(name = "settlement_amount_local_currency_code", length = 3, nullable = false)
    public String settlementAmountLocalCurrencyCode;

    @NotNull
    @Column(name = "settlement_date", nullable = false)
    public LocalDate settlementDate;

    @NotNull
    @Size(max = 50)
    @Column(name = "tenant_id", length = 50, nullable = false)
    public String tenantId;

    @NotNull
    @Column(name = "txn_amount", nullable = false)
    public Double txnAmount;

    @NotNull
    @Size(max = 3)
    @Column(name = "txn_amount_lcy_code", length = 3, nullable = false)
    public String txnAmountLcyCode;

    @NotNull
    @Column(name = "txn_amount_local_currency", nullable = false)
    public Double txnAmountLocalCurrency;

    @NotNull
    @Size(max = 3)
    @Column(name = "txn_currency", length = 3, nullable = false)
    public String txnCurrency;

    @NotNull
    @Column(name = "value_date", nullable = false)
    public LocalDate valueDate;

    @Column(name = "value_date_offset")
    public Integer valueDateOffset;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionDetails)) {
            return false;
        }
        return id != null && id.equals(((TransactionDetails) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TransactionDetails{" +
            "id=" + id +
            ", outgoingChargingParty='" + outgoingChargingParty + "'" +
            ", applicantAccount='" + applicantAccount + "'" +
            ", applicantAccountCurrency='" + applicantAccountCurrency + "'" +
            ", applicantBankCode='" + applicantBankCode + "'" +
            ", applicantBranchCode='" + applicantBranchCode + "'" +
            ", applicantCif='" + applicantCif + "'" +
            ", applicantName='" + applicantName + "'" +
            ", countryCd='" + countryCd + "'" +
            ", derviedChargingParty='" + derviedChargingParty + "'" +
            ", payhubTxnRef='" + payhubTxnRef + "'" +
            ", paymentProductCode='" + paymentProductCode + "'" +
            ", payoutDate='" + payoutDate + "'" +
            ", processingCenterCode='" + processingCenterCode + "'" +
            ", processingDate='" + processingDate + "'" +
            ", settlementAmount=" + settlementAmount +
            ", settlementAmountLocalCurrency=" + settlementAmountLocalCurrency +
            ", settlementAmountLocalCurrencyCode='" + settlementAmountLocalCurrencyCode + "'" +
            ", settlementDate='" + settlementDate + "'" +
            ", tenantId='" + tenantId + "'" +
            ", txnAmount=" + txnAmount +
            ", txnAmountLcyCode='" + txnAmountLcyCode + "'" +
            ", txnAmountLocalCurrency=" + txnAmountLocalCurrency +
            ", txnCurrency='" + txnCurrency + "'" +
            ", valueDate='" + valueDate + "'" +
            ", valueDateOffset=" + valueDateOffset +
            "}";
    }

    public TransactionDetails update() {
        return update(this);
    }

    public TransactionDetails persistOrUpdate() {
        return persistOrUpdate(this);
    }

    public static TransactionDetails update(TransactionDetails transactionDetails) {
        if (transactionDetails == null) {
            throw new IllegalArgumentException("transactionDetails can't be null");
        }
        var entity = TransactionDetails.<TransactionDetails>findById(transactionDetails.id);
        if (entity != null) {
            entity.outgoingChargingParty = transactionDetails.outgoingChargingParty;
            entity.applicantAccount = transactionDetails.applicantAccount;
            entity.applicantAccountCurrency = transactionDetails.applicantAccountCurrency;
            entity.applicantBankCode = transactionDetails.applicantBankCode;
            entity.applicantBranchCode = transactionDetails.applicantBranchCode;
            entity.applicantCif = transactionDetails.applicantCif;
            entity.applicantName = transactionDetails.applicantName;
            entity.countryCd = transactionDetails.countryCd;
            entity.derviedChargingParty = transactionDetails.derviedChargingParty;
            entity.payhubTxnRef = transactionDetails.payhubTxnRef;
            entity.paymentProductCode = transactionDetails.paymentProductCode;
            entity.payoutDate = transactionDetails.payoutDate;
            entity.processingCenterCode = transactionDetails.processingCenterCode;
            entity.processingDate = transactionDetails.processingDate;
            entity.settlementAmount = transactionDetails.settlementAmount;
            entity.settlementAmountLocalCurrency = transactionDetails.settlementAmountLocalCurrency;
            entity.settlementAmountLocalCurrencyCode = transactionDetails.settlementAmountLocalCurrencyCode;
            entity.settlementDate = transactionDetails.settlementDate;
            entity.tenantId = transactionDetails.tenantId;
            entity.txnAmount = transactionDetails.txnAmount;
            entity.txnAmountLcyCode = transactionDetails.txnAmountLcyCode;
            entity.txnAmountLocalCurrency = transactionDetails.txnAmountLocalCurrency;
            entity.txnCurrency = transactionDetails.txnCurrency;
            entity.valueDate = transactionDetails.valueDate;
            entity.valueDateOffset = transactionDetails.valueDateOffset;
        }
        return entity;
    }

    public static TransactionDetails persistOrUpdate(TransactionDetails transactionDetails) {
        if (transactionDetails == null) {
            throw new IllegalArgumentException("transactionDetails can't be null");
        }
        if (transactionDetails.id == null) {
            persist(transactionDetails);
            return transactionDetails;
        } else {
            return update(transactionDetails);
        }
    }



}
