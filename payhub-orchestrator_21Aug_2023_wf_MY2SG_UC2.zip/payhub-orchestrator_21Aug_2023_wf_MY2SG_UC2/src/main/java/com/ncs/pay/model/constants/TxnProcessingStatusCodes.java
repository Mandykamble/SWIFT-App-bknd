package com.ncs.pay.model.constants;

public enum TxnProcessingStatusCodes {
    CREATED ("00", "Created"),
    AUTH1 ("01", "Auth1"),
    AUTH2 ("02", "Auth2"),
    UNKNOWN ("05", "Unknown"),
    PROCESSING ("10", "Processing"),
//    PENDING_OVERRIDING ("10O", "Pending Override"),
    PENDING_ADHOC_APPROVAL ("11", "Pending Adhoc Approval"),
    WAREHOOUSED ("10W", "Warehoused"),
    PENDING_DISCARDED ("13", "Pending Discarded"),
    PENDING_REPAIR ("20A", "Pending Repair"),
    PENDING_OVERRIDE ("20B", "Pending Override"),
    COMPLETED ("30", "Completed"),
    REJECTED ("40", "Rejected"),

    SETTLED ("50", "SETTLED"),
//    PENDING_PRINT ("20", "Pending Print"),
    FORCE_COMPLETED ("34", "Force Completed"),
    DELETED ("40D", "Deleted"),
    KIV ("100", "KIV"),
    CLARIFY ("101", "Clarify"),
    DISCARDED ("99", "Discarded"),
    MANAGE_IMAGE ("102", "Manage Image"),
    MAKER ("103", "Maker"),
    CHECKER ("104", "Checker"),
    MERGED ("105", "Merged"),
    SPLITTED ("106", "Splitted"),
    ATTACHED ("107", "Attached");
    private String code;
    private String desc;

    private TxnProcessingStatusCodes(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return this.code;
    }
    public String getDesc() {return this.desc;}
}
