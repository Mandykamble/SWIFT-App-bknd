package com.ncs.pay.config.params;

import lombok.Data;


public interface RouteThreadPoolSetup {

     int DefaultInboundMessageProcessingRouteMin=1;
     int DefaultInboundMessageProcessingRouteMax=1;
     int DefaultExceptionRouteMin=1;
     int DefaultExceptionRouteMax=1;
     int TxnProcessLogCollectorRouteMin=1;
     int TxnProcessLogCollectorRouteMax=1;
     int SGBKTXRPreProcessorMin=1;
     int SGBKTXRPreProcessorMax=1;
     int PaymentRequestProcessorMin=1;
     int PaymentRequestProcessorMax=1;
     int NonStpCurrencyCheckMin=1;
     int NonStpCurrencyCheckMax=1;
     int StpAmountLimitCheckMin=1;
     int StpAmountLimitCheckMax=1;
     int CutoffTimeCheckMin=1;
     int CutoffTimeCheckMax=1;
     int SpecialWordsCheckMin=1;
     int SpecialWordsCheckMax=1;
     int IndustryCutoffTimeCheckMin=1;
     int IndustryCutoffTimeCheckMax=1;

     int FinalPostingMin=1;

     int FinalPostingMax=1;
     int AccountPostingMin=1;
     int AccountPostingMax=1;
     int ComplianceCheckMin=1;
     int ComplianceCheckMax=1;
     int DuplicateTxnCheckMin=1;
     int DuplicateTxnCheckMax=1;

     int AccountBalanceCheckMin=1;

     int AccountBalanceCheckMax=1;


     int FxConvertMin=1;
     int FxConvertMax=1;
     int DeriveChargesMin=1;
     int DeriveChargesMax=1;
     int DebitCreditAccountValidationMin=1;
     int DebitCreditAccountValidationMax=1;

     int AMLCheckMin=1;

     int AMLCheckMax=1;
}
