package com.ncs.pay.common;

import com.ncs.pay.model.integration.request.PaymentRequest;
import com.ncs.pay.model.modelinterface.IPaymentRequest;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * @Author Pranab Sankar Nayak
 */

public class PaymentHubUtil {

    public static Sort constructSortObject(String sortColumnAndOrderByHolder) {
        Sort sort = null;
        String commaStr = ",";
        try {
            if (sortColumnAndOrderByHolder == null || sortColumnAndOrderByHolder.isEmpty()) {
                //do nothing
            } else {
                if (sortColumnAndOrderByHolder.contains(commaStr)) {
                    String[] strArray = sortColumnAndOrderByHolder.split(commaStr);
                    Sort.by(strArray[0]).direction(getOrderByDirection(strArray[1]));

                } else {
                    // Only column available
                    sort = Sort.by(sortColumnAndOrderByHolder);
                }
            }
        } catch (Exception exp) {
            // do nothing
        }

        return sort;
    }

    public static Sort.Direction getOrderByDirection(String s) {
        if (s != null && "asc".equalsIgnoreCase(s.trim())) {
            return Sort.Direction.Ascending;
        } else {
            return Sort.Direction.Descending;
        }
    }

    public static Page constructPageObject(Integer size, Integer index) {
        if (size == null) {
            size = 20;
            index = 0;
        } else {
            if (index == null) {
                index = 0;
            }
        }

        return Page.of(index, size);
    }

    public static boolean isValidJSON(String json) {
        try {
            new JSONObject(json);
        } catch (JSONException e) {
            return false;
        }
        return true;
    }

    public static String getProductCode(IPaymentRequest paymentRequest){
        if(paymentRequest instanceof PaymentRequest){
            return ((PaymentRequest)paymentRequest).getBody().getTrnRequest().getPmtProduct();
        }else{
            return ((com.ncs.pay.model.payloads.PaymentRequest.PaymentRequest)paymentRequest).getBody().getTrnRequest().getPmtProduct();
        }

    }
}
