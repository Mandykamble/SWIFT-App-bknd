package com.ncs.pay.model.constants;

import java.util.Arrays;

public enum TxnProcessingStageCodes {



    // Stage Codes
    // General Code Naming Convention
    // First 2 digits before hyphen represent status cd
    // Codes ending in 0 indicate Informational or Decision Status
    // Codes ending in 1 indicate success
    // Codes ending in 5 indicate failure

    // RECEIVED Stage Codes
    UNKNOWN_UNDETERMINED ( "99-000", "Undetermined"),
    CREATED_000_TXN_ROUTED ( "00-000", "Txn Routed"),
    CREATED_005_TXN_ROUTING_FAILED ( "00-005", "Txn Routing Failed"),


    // PROCESSING Stage Codes

    //Pre Processing Stages
    PROCESSING_100_INITIATED ( "10-100", "Initiated"),
    PROCESSING_101_TXN_MASTER_CREATED ( "10-101", "Txn Master Created"),
    PROCESSING_105_TXN_MASTER_CREATION_FAILED ( "10-105", "Txn Master creation Failed"),
    PROCESSING_111_TXN_INITIAL_ACK_SUCCESS ( "10-111",  "Txn Initial Ack Success"),
    PROCESSING_115_TXN_INITIAL_ACK_FAILED ( "10-115",  "Txn Initial Ack Failed"),
    PROCESSING_120_PROCESSING_DATE_DERVIED ( "10-120",  "Processing Date Derived"),
    PROCESSING_140_DEBIT_CREDIT_ACCOUNT_VALIDATION_INITIATED ( "10-140", "Debit Credit Account Validation Initiated"),
    PROCESSING_141_DEBIT_CREDIT_ACCOUNT_VALIDATION_SUCCESS ( "10-141", "Debit Credit Account Validation Success"),
    PROCESSING_145_DEBIT_CREDIT_ACCOUNT_VALIDATION_FAILED ( "10-145", "Debit Credit Account Validation Failed"),
    PROCESSING_150_ACCOUNT_BALANCE_INQUIRY_INITIATED("10-150","Account Balance Inquiry Initiated"),
    PROCESSING_151_ACCOUNT_BALANCE_INQUIRY_SUCCESS ( "10-151", "Account Balance Inquiry Success"),
    PROCESSING_155_ACCOUNT_BALANCE_INQUIRY_FAILED ( "10-155", "Account Balance Inquiry Failed"),


    //Processing Non Financial Stages
    PROCESSING_200_NON_STP_CURRENCY_CHECK_INITIATED ( "10-200", "Non STP Currency Check Initiated"),
    PROCESSING_201_NON_STP_CURRENCY_CHECK_SUCCESS ( "10-201",  "Non STP Currency Check Success"),
    PROCESSING_205_NON_STP_CURRENCY_CHECK_FAILED ( "10-205",  "Non STP Currency Check Failed"),
    PROCESSING_210_SPECIAL_WORDS_CHECK_INITIATED ( "10-210", "Special words Check Initiated"),
    PROCESSING_211_SPECIAL_WORDS_CHECK_SUCCESS ( "10-211", "Special Words Check Success"),
    PROCESSING_215_SPECIAL_WORDS_CHECK_FAILED ( "10-215",  "Special Words Check Failed"),
    PROCESSING_220_INDUSTRY_CUTOFF_TIME_CHECK_INITIATED ( "10-220", "Industry Cutoff Time Check Initiated"),
    PROCESSING_221_INDUSTRY_CUTOFF_TIME_CHECK_SUCCESS ( "10-221", "Industry Cutoff Time Check Success"),
    PROCESSING_225_INDUSTRY_CUTOFF_TIME_CHECK_FAILED ( "10-225",  "Industry Cutoff Time Check Failed"),
    PROCESSING_230_DUPLICATE_TXN_CHECK_INITIATED ( "10-230", "Duplicate Transaction Check Initiated"),
    PROCESSING_231_DUPLICATE_TXN_CHECK_SUCCESS ( "10-231", "Duplicate Transaction Check Success"),
    PROCESSING_235_DUPLICATE_TXN_CHECK_FAILED ( "10-235",  "Duplicate Transaction Check Failed"),
    PROCESSING_240_DERIVE_CHARGES_INITIATED ( "10-240", "Derive Charges Initiated"),
    PROCESSING_241_DERIVE_CHARGES_SUCCESS ( "10-241", "Derive Charges Success"),
    PROCESSING_245_DERIVE_CHARGES_FAILED ( "10-245",  "Derive Charges Failed"),
    PROCESSING_250_ROUND_TRIP_CHECK_INITIATED ( "10-250", "Round trip check Initiated"),
    PROCESSING_251_ROUND_TRIP_CHECK_SUCCESS ( "10-251", "Round trip check Success"),
    PROCESSING_255_ROUND_TRIP_CHECK_FAILED ( "10-255",  "Round trip check Failed"),
    PROCESSING_260_WAREHOUSE_CHECK_INITIATED ( "10-260", "Warehouse check Initiated"),
    PROCESSING_261_WAREHOUSE_CHECK_SUCCESS ( "10-261", "Warehouse check Success"),
    PROCESSING_265_WAREHOUSE_CHECK_FAILED ( "10-265",  "Warehouse check Failed"),
    PROCESSING_270_COVER_MATCH_INITIATED ( "10-270", "Cover match Initiated"),
    PROCESSING_271_COVER_MATCH_SUCCESS ( "10-271", "Cover match Success"),
    PROCESSING_275_COVER_MATCH_FAILED ( "10-275",  "Cover match Failed"),
    PROCESSING_280_SETTLEMENT_POSTING_INITIATED ( "10-280", "Settlement Posting Initiated"),
    PROCESSING_281_SETTLEMENT_POSTING_SUCCESS ( "10-281", "Settlement Posting Success"),
    PROCESSING_285_SETTLEMENT_POSTING_FAILED ( "10-285",  "Settlement Posting Failed"),
    PROCESSING_290_GENERATE_OUTGOING_MESSAGE_INITIATED ( "10-290", "Genere outgoing message Initiated"),
    PROCESSING_291_GENERATE_OUTGOING_MESSAGE_SUCCESS ( "10-291", "Genere outgoing message Success"),
    PROCESSING_295_GENERATE_OUTGOING_MESSAGE_FAILED ( "10-295",  "Genere outgoing message Failed"),
    PROCESSING_300_AML_CHECK_INITIATED ( "10-300", "AML Check Initiated"),
    PROCESSING_301_AML_CHECK_SUCCESS ( "10-301", "AML Check Success"),
    PROCESSING_302_AML_CHECK_OVERRIDE_AUTHORIZED ( "10-302", "AML Check Override Authorized"),
    PROCESSING_305_AML_CHECK_FAILED ( "10-305",  "AML Check Failed"),
    PROCESSING_310_STP_AMOUNT_LIMIT_CHECK_INITIATED ( "10-310", "STP Amount Limit Check Initiated"),
    PROCESSING_311_STP_AMOUNT_LIMIT_CHECK_SUCCESS ( "10-311", "STP Amount Limit Check Success"),
    PROCESSING_315_STP_AMOUNT_LIMIT_CHECK_FAILED ( "10-315",  "STP Amount Limit Check Failed"),

    // Processing Financial Stages
    PROCESSING_1310_FINAL_POSTING_INITIATED ( "10-1310", "Final Posting Initiated"),
    PROCESSING_1311_FINAL_POSTING_SUCCESS ( "10-1311", "Final Posting Success"),
    PROCESSING_1315_FINAL_POSTING_FAILED ( "10-1315",  "Final Posting Failed"),
    PROCESSING_820_NOSTRO_POSTING_INITIATED ( "10-330", "Nostro Posting Initiated"),
    PROCESSING_821_NOSTRO_POSTING_SUCCESS ( "10-331", "Nostro Posting Success"),
    PROCESSING_825_NOSTRO_POSTING_FAILED ( "10-335",  "Nostro Posting Failed"),
    PROCESSING_830_DERIVE_FX_INITIATED ( "10-340", "Derive FX Initiated"),
    PROCESSING_831_DERIVE_FX_SUCCESS ( "10-341", "Derive FX Success"),
    PROCESSING_835_DERIVE_FX_FAILED ( "10-345",  "Derive FXFailed"),
    PROCESSING_840_FX_POSTING_INITIATED ( "10-340", "FX Posting Initiated"),
    PROCESSING_841_FX_POSTING_SUCCESS ( "10-341", "FX Posting Success"),
    PROCESSING_845_FX_POSTING_FAILED ( "10-345",  "FX Posting Failed"),
    PROCESSING_350_ACCOUNT_POSTING_INITIATED("10-350", "Account Posting Initiated"),
    PROCESSING_351_ACCOUNT_POSTING_SUCCESS( "10-351", "Account Posting Success"),
    PROCESSING_355_ACCOUNT_POSTING_FAILED( "10-355", "Account Posting Failed"),
    PROCESSING_360_COMPLIANCE_CHECK_INITIATED("10-360", "Compliance Check Initiated"),
    PROCESSING_361_COMPLIANCE_CHECK_SUCCESS("10-361", "Compliance Check Success"),
    PROCESSING_365_COMPLIANCE_CHECK_FAILED("10-365", "Compliance Check Failed"),
    PROCESSING_200_CHARACTER_CHECK_INITIATED("20-200", "Character Check Initiated"),
    PROCESSING_201_CHARACTER_CHECK_SUCCESS("20-201", "Character Check Success"),
    PROCESSING_205_CHARACTER_CHECK_FAILED("20-205", "Character Check Failed"),

    // Manual Recovery Stages
    REPAIR_100_MANUAL_REPAIR_QUEUE_RECEIVED ( "20A-100","Manual Repair Queue - Received"),
    REPAIR_101_MANUAL_REPAIR_QUEUE_QUEUED ( "20A-201","Manual Repair Queue - Queued"),
    REPAIR_101_MANUAL_REPAIR_QUEUEING_FAILED ( "20A-205","Manual Repair Queue -  Queueing Failed"),
    REPAIR_110_MANUAL_REPAIR_QUEUE_ASSIGNED ( "20A-110","Manual Repair Queue - Assigned"),
    REPAIR_111_MANUAL_REPAIR_QUEUE_AUTHORIZED ( "20A-111","Manual Repair Queue - Authorized"),
    REPAIR_115_MANUAL_REPAIR_QUEUE_DISCARDED ( "20A-115","Manual Repair Queue - Discarded"),

    // Manual Recovery Stages
    REPAIR_200_OVERRIDE_QUEUE_RECEIVED ( "20B-200","Override Queue - Received"),
    REPAIR_201_OVERRIDE_QUEUE_QUEUED ( "20B-201","Override Queue - Queued"),
    REPAIR_205_OVERRIDE_QUEUEING_FAILED( "20B-205","Override Queue - Queueing Failed"),
    REPAIR_210_OVERRIDE_QUEUE_ASSIGNED( "20B-210","Override Queue - Assigned"),
    REPAIR_211_OVERRIDE_QUEUE_AUTHORIZED ( "20B-211","Override Queue - Authorized"),
    REPAIR_212_OVERRIDE_QUEUE_DISCARDED ( "20B-212","Override Queue - Discarded"),
    REPAIR_215_OVERRIDE_QUEUE_OVERRIDE_FAILED ( "20B-212","Override Queue - Override Action Failed"),

    //  Auto Recovery Stages
    REPAIR_1100_AUTO_REPAIR_CORRECTION_INITIATED ( "20-1100", "Auto Repair Initiated"),
    REPAIR_1101_AUTO_REPAIR_CORRECTION_SUCCESS ( "20-1101", "Auto Repair Success"),
    REPAIR_1105_AUTO_REPAIR_CORRECTION_FAILED ( "20-1105",  "Auto Repair Failed"),
    REPAIR_1110_AUTO_REPAIR_NAME_VARIANCE_INITIATED ( "20-1110", "Auto Repair Name Variance Initiated"),
    REPAIR_1111_AUTO_REPAIR_NAME_VARIANCE_SUCCESS ( "20-1111", "Auto Repair Name Variance Success"),
    REPAIR_1115_AUTO_REPAIR_NAME_VARIANCE_FAILED ( "20-1115",  "Auto Repair Name Variance Failed"),

    //Post Successful Processing Stages
    COMPLETED_101_PROCESSING_SUCCESS ( "30-101", "Transaction entry successfully validated"),
    COMPLETED_110_SEND_OUTGOING_MESSAGE_INITIATED ( "30-110", "Send Outgoing Message Initiated"),
    COMPLETED_111_SEND_OUTGOING_MESSAGE_SUCCESS ( "30-111", "Send Outgoing Message Success"),
    COMPLETED_115_SEND_OUTGOING_MESSAGE_FAILED ( "30-115",  "Send Outgoing Message Failed"),
    COMPLETED_120_CONFIRM_CHARGES_INITIATED ( "30-120", "Confirm Charges Initiated"),
    COMPLETED_121_CONFIRM_CHARGES_SUCCESS ( "30-121", "Confirm Charges Success"),
    COMPLETED_125_CONFIRM_CHARGES_FAILED ( "30-125",  "Confirm Charges Failed"),
    COMPLETED_130_SEND_GENERATE_ADVICE_INITIATED ( "30-130", "Send for Advice Generation Initiated"),
    COMPLETED_131_SEND_GENERATE_ADVICE_SUCCESS ( "30-131", "Send for Advice Generation Success"),
    COMPLETED_135_SEND_GENERATE_ADVICE_FAILED ( "30-135",  "Send for Advice Generation Failed"),
    COMPLETED_140_DERIVE_GL_POSTING_INITIATED ( "30-140", "Derive GL Posting Initiated"),
    COMPLETED_141_DERIVE_GL_POSTING_SUCCESS ( "30-141", "Derive GL Posting Success"),
    COMPLETED_145_DERIVE_GL_POSTING_FAILED ( "30-145",  "Derive GL Posting Failed"),
    // Post Failed Processing Stages
    REJECTED_102_REJECTED ( "40-102", "Transaction REJECTED"),
    REJECTED_103_DISCARDED ( "40-103", "Transaction DISCARDED"),
    REJECTED_110_SEND_OUTGOING_MESSAGE_INITIATED ( "40-110" ,"Send Outgoing Message Initiated"),
    REJECTED_101_SEND_OUTGOING_MESSAGE_SUCCESS ( "40-111", "Send Outgoing Message Success"),
    REJECTED_115_SEND_OUTGOING_MESSAGE_FAILED ( "40-115",  "Send Outgoing Message Failed"),

    PACS8_GENERATED ("75-000","PACS8 Successfully generated"),
    PACS8_SENT ("75-005","PACS8 successfully sent"),
    PACS2_GENERATED ("76-000","PACS2 successfully generated"),
    PACS2_RECIEVED ("76-005","PACS2 successfully sent"),


    //MAYBANK USECASE 2 TT

    //MYBANK MY

    MAY_BANK_MY_PACS8_GENERATED ("80-000","PACS8 Successfully generated "),
    MAY_BANK_MY_PACS8_SENT ("80-005","PACS8 successfully sent to MBBESG "),
    MAY_BANK_MY_PACS9_COV_GENERATED ("81-000","PACS9Cov Successfully generated"),
    MAY_BANK_MY_PACS9_COV_SENT ("81-005","PACS9Cov successfully sent to MBBEUS"),

    MAY_BANK_MY_PACS2_FOR_PACS9COV_RECIEVED ("82-000","PACS2 for PACS9Cov successfully recieved from MBBEUS"),
    MAY_BANK_MY_CAMT54_RECIEVED ("83-000"," CAMT54 successfully received from MBBEUS"),
    MAY_BANK_PACS2_FOR_PACS8_RECIEVED ("84-000","PACS2 for PACS8 successfully received from MBBESG"),

    MAY_BANK_MY_CAMT53_RECIEVED ("85-000"," CAMT53 successfully received from MBBEUS"),


    //MYBANK SG


    MAY_BANK_SG_PACS9_RECIEVED ("86-000","PACS9COV Successfully received from MBBEUS"),
    MAY_BANK_SG_PACS2_SENT ("87-000","PACS2 Successfully Sent to MBBEUS"),

    MAY_BANK_SG_CAMT54_RECIEVED ("88-000","CAMT54 successfully received from MBBEUS"),

    MAY_BANK_SG_PACS2_MY_SENT ("89-000","PACS2 for PACS8 Successfully Sent to MBBEMY"),

    MAY_BANK_SG_CAMT53_RECIEVED ("90-000","CAMT53 successfully received from MBBEUS"),



    //MYBANK US IN


    MAY_BANK_US_PACS2_SENT ("91-000","PACS2 Successfully sent to MBBEMY"),

    MAY_BANK_US_CAMT54_SENT ("92-000","CAMT54 successfully sent to MBBEMY"),

    MAY_BANK_US_CAMT53_SENT ("93-000","CAMT53 successfully sent to MBBEMY"),



    //MYBANK US IN


    MAY_BANK_US_SG_PACS9_SENT ("94-000","PACS9 Successfully sent to MBBESG"),

    MAY_BANK_US_SG_PACS2_RECIEVE ("95-000","PACS2 successfully recieve from MBBESG"),

    MAY_BANK_US_SG_CAMT54_SENT ("96-000","CAMT54 successfully sent to MBBESG"),

    MAY_BANK_US_SG_CAMT53_SENT ("97-000","CAMT53 successfully sent to MBBESG");

    private String code;
    private String desc;

    private TxnProcessingStageCodes(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return this.code;
    }
    public String getDesc() {return this.desc;}

    public static TxnProcessingStageCodes getTxnProcessingStageCodes(String code) {
       return Arrays.stream(TxnProcessingStageCodes.values())
               .filter(txnProcessingStageCode -> txnProcessingStageCode.getCode().equals(code)).
               findFirst()
               .orElse(null);
    }
}
