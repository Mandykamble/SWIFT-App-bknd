package com.ncs.pay.domain;

import com.ncs.pay.constants.MessageStatus;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "message") // Note: Table name is "message", not "messages" as in your SQL
@Data
public class MessageEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(name = "order_ref", unique = true, nullable = false)
    public String orderRef;  // Unique reference to track updates

    @Column(name = "message_type", nullable = false)
    public String messageType;  // e.g., MT103

    @Column(columnDefinition = "TEXT", nullable = false)
    public String data;  // JSON data for dynamic fields

    @Column(columnDefinition = "TEXT")
    public String transformedData;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    public MessageStatus status = MessageStatus.DRAFT;  // Status tracking

    @Column(name = "created_at", nullable = false, updatable = false)
    public LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    public LocalDateTime updatedAt = LocalDateTime.now();

    @Column(name = "remarks")  // Add this field to map to the remarks column
    public String remarks;     // Store remarks for REVIEW status

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
